"""
Compare three super-efficiency SBM models on the same CSV (v2):

  1. LYHS  — Lin, Yang & Huang (2019)   [36_lin2019_super_sbm_ram.py]
  2. HSLS  — Lee (2021)                 [33_lee2021_nonpositive_sbm_v2.py]
  3. IBP   — Paramanik et al. (2023)    [34_paramanik2023_ibp_sbm_v2.py]

Each model is a class. Shared input: data.csv (x* = inputs, y* = outputs).
Runs under four RTS conditions: CRS, VRS, NIRS, NDRS.

Scores used in the comparison table:
  LYHS : theta*      Eq. (12)
  HSLS : ddot_sigma  Eq. (12)
  IBP  : ddot_gamma  Eq. (14)
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pulp


# ===========================================================================
# Shared I/O
# ===========================================================================

def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")
    if dmu_col not in fields:
        raise ValueError(f"DMU column '{dmu_col}' not found.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def rank_by_score(scores: Sequence[float]) -> List[int]:
    order = sorted(range(len(scores)), key=lambda i: -scores[i])
    ranks = [0] * len(scores)
    for rk, i in enumerate(order, start=1):
        ranks[i] = rk
    return ranks


def score_metrics(scores: Sequence[float]) -> Dict[str, float]:
    """
    Discrimination / reliability indices used in Paramanik et al. (2023):
      SDS     — standard deviation of scores
      DS      — domain of scores (max - min)
      Entropy — normalized Shannon entropy (lower => more reliable)
    """
    finite = [x for x in scores if x is not None and math.isfinite(x)]
    n = len(finite)
    if n == 0:
        return {"SDS": float("nan"), "DS": float("nan"), "Entropy": float("nan")}
    mean = sum(finite) / n
    sds = math.sqrt(sum((x - mean) ** 2 for x in finite) / n)
    ds = max(finite) - min(finite)
    total = sum(finite)
    if total <= 0:
        entropy = float("nan")
    else:
        probs = [x / total for x in finite]
        entropy = -sum(p * math.log(p) for p in probs if p > 0) / math.log(n)
    return {"SDS": sds, "DS": ds, "Entropy": entropy}


RTS_LIST = ("CRS", "VRS", "NIRS", "NDRS")


def add_rts(prob, Lam, idxs, t, rts: str) -> None:
    """
    Intensity-sum RTS constraint (Charnes / Banker style):
      CRS : no constraint
      VRS : sum == t
      NDRS: sum >= t
      NIRS: sum <= t
    """
    rts = rts.upper()
    total = pulp.lpSum(Lam[j] for j in idxs)
    if rts == "CRS":
        return
    if rts == "VRS":
        prob += total == t
    elif rts == "NDRS":
        prob += total >= t
    elif rts == "NIRS":
        prob += total <= t
    else:
        raise ValueError(f"Unknown RTS: {rts}")


def _fmt_score(v) -> str:
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return "Infeasible"
    return f"{v:12.6f}"


def _fmt_rank(v) -> str:
    if v is None:
        return "  -"
    return f"{v:4d}"


# ===========================================================================
# LYHS — Lin, Yang & Huang (2019)
# ===========================================================================

class LYHSModel:
    """Modified Super-SBM with RAM (Lin et al., 2019). Score = theta* Eq. (12)."""

    name = "LYHS"

    def __init__(
        self,
        inputs: Sequence[Sequence[float]],
        outputs: Sequence[Sequence[float]],
        dmu_names: Optional[Sequence[str]] = None,
        rts: str = "VRS",
        tol: float = 1e-8,
    ):
        self.inputs = [list(row) for row in inputs]
        self.outputs = [list(row) for row in outputs]
        self.n = len(self.inputs)
        self.m = len(self.inputs[0])
        self.s = len(self.outputs[0])
        self.names = (
            list(dmu_names) if dmu_names is not None
            else [str(i + 1) for i in range(self.n)]
        )
        self.rts = rts.upper()
        self.tol = tol
        self.p_in, self.p_out, self.I, self.O = self._compute_ranges()
        self.mu = [1.0 / self.m] * self.m
        self.nu = [1.0 / self.s] * self.s

    def _compute_ranges(self):
        p_in, p_out = [], []
        for i in range(self.m):
            col = [self.inputs[j][i] for j in range(self.n)]
            p_in.append(max(col) - min(col))
        for r in range(self.s):
            col = [self.outputs[j][r] for j in range(self.n)]
            p_out.append(max(col) - min(col))
        I = [i for i in range(self.m) if p_in[i] > 0]
        O = [r for r in range(self.s) if p_out[r] > 0]
        return p_in, p_out, I, O

    def _super_score(self, w_minus, w_plus) -> float:
        numer = 1.0 + sum(
            self.mu[i] * w_minus[i] / self.p_in[i] for i in self.I
        )
        denom = 1.0 - sum(
            self.nu[r] * w_plus[r] / self.p_out[r] for r in self.O
        )
        if denom <= 1e-12:
            raise RuntimeError("LYHS Super-SBM denominator nonpositive.")
        return numer / denom

    def _solve_super_sbm(self, k: int) -> Dict:
        others = [j for j in range(self.n) if j != k]
        prob = pulp.LpProblem(f"LYHS_Super_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Wm = [pulp.LpVariable(f"Wm_{i}", lowBound=0) for i in range(self.m)]
        Wp = [pulp.LpVariable(f"Wp_{r}", lowBound=0) for r in range(self.s)]

        prob += t + pulp.lpSum(
            self.mu[i] * Wm[i] / self.p_in[i] for i in self.I
        )
        prob += t - pulp.lpSum(
            self.nu[r] * Wp[r] / self.p_out[r] for r in self.O
        ) == 1

        for i in range(self.m):
            if i in self.I:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others) - Wm[i]
                    <= t * self.inputs[k][i]
                )
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others)
                    == t * self.inputs[k][i]
                )
                prob += Wm[i] == 0

        for r in range(self.s):
            if r in self.O:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others) + Wp[r]
                    >= t * self.outputs[k][r]
                )
                prob += Wp[r] <= t * self.p_out[r]
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others)
                    == t * self.outputs[k][r]
                )
                prob += Wp[r] == 0

        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"LYHS Super-SBM failed for DMU {k}: {pulp.LpStatus[st]}"
            )

        t_star = pulp.value(t)
        lam = [0.0] * self.n
        for j in others:
            lam[j] = pulp.value(Lam[j]) / t_star

        w_minus = [0.0] * self.m
        for i in self.I:
            ref = sum(lam[j] * self.inputs[j][i] for j in others)
            w_minus[i] = max(0.0, ref - self.inputs[k][i])
        w_plus = [0.0] * self.s
        for r in self.O:
            ref = sum(lam[j] * self.outputs[j][r] for j in others)
            w_plus[r] = min(max(0.0, self.outputs[k][r] - ref), self.p_out[r])

        return {
            "sigma": self._super_score(w_minus, w_plus),
            "w_minus": w_minus,
            "w_plus": w_plus,
        }

    def _solve_modified_sbm(self, k: int, w_minus, w_plus) -> Dict:
        others = [j for j in range(self.n) if j != k]
        prob = pulp.LpProblem(f"LYHS_SBM_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(self.m)]
        Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(self.s)]

        prob += t - pulp.lpSum(
            self.mu[i] * Sm[i] / self.p_in[i] for i in self.I
        )
        prob += t + pulp.lpSum(
            self.nu[r] * Sp[r] / self.p_out[r] for r in self.O
        ) == 1

        for i in range(self.m):
            if i in self.I:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others) + Sm[i]
                    == t * (self.inputs[k][i] + w_minus[i])
                )
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others)
                    == t * self.inputs[k][i]
                )
                prob += Sm[i] == 0

        for r in range(self.s):
            if r in self.O:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others) - Sp[r]
                    == t * (self.outputs[k][r] - w_plus[r])
                )
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others)
                    == t * self.outputs[k][r]
                )
                prob += Sp[r] == 0

        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"LYHS Modified SBM failed for DMU {k}: {pulp.LpStatus[st]}"
            )
        return {"rho": pulp.value(prob.objective)}

    def evaluate_dmu(self, k: int) -> Dict:
        s1 = self._solve_super_sbm(k)
        s2 = self._solve_modified_sbm(k, s1["w_minus"], s1["w_plus"])
        sigma, rho = s1["sigma"], s2["rho"]
        theta = sigma if sigma > 1.0 + self.tol else rho
        return {
            "dmu": self.names[k],
            "sigma": sigma,
            "rho": rho,
            "score": theta,
            "feasible": True,
        }

    def evaluate_all(self) -> List[Dict]:
        results = []
        for k in range(self.n):
            try:
                results.append(self.evaluate_dmu(k))
            except Exception:
                results.append({
                    "dmu": self.names[k],
                    "sigma": None,
                    "rho": None,
                    "score": None,
                    "feasible": False,
                })
        ranks = rank_by_score([
            r["score"] if r["score"] is not None else float("-inf")
            for r in results
        ])
        for r, rk in zip(results, ranks):
            r["rank"] = rk if r["feasible"] else None
        return results


# ===========================================================================
# HSLS — Lee (2021)
# ===========================================================================

class HSLSModel:
    """Nonpositive Super-SBM two-stage (Lee, 2021). Score = ddot_sigma Eq. (12)."""

    name = "HSLS"

    def __init__(
        self,
        inputs: Sequence[Sequence[float]],
        outputs: Sequence[Sequence[float]],
        dmu_names: Optional[Sequence[str]] = None,
        rts: str = "VRS",
        tol: float = 1e-8,
    ):
        self.inputs = [list(row) for row in inputs]
        self.outputs = [list(row) for row in outputs]
        self.n = len(self.inputs)
        self.m = len(self.inputs[0])
        self.s = len(self.outputs[0])
        self.names = (
            list(dmu_names) if dmu_names is not None
            else [str(i + 1) for i in range(self.n)]
        )
        self.rts = rts.upper()
        self.tol = tol
        self.sets = self._classify_io()

    def _classify_io(self) -> Dict[str, List[int]]:
        I_plus = [
            i for i in range(self.m)
            if all(self.inputs[j][i] > 0 for j in range(self.n))
        ]
        I_minus = [
            i for i in range(self.m)
            if all(self.inputs[j][i] < 0 for j in range(self.n))
        ]
        R_minus = [
            r for r in range(self.s)
            if all(self.outputs[j][r] < 0 for j in range(self.n))
        ]
        R_plus = [
            r for r in range(self.s)
            if all(self.outputs[j][r] > 0 for j in range(self.n))
        ]
        I = list(range(self.m))
        R = list(range(self.s))
        return {
            "I": I,
            "R": R,
            "I+": I_plus,
            "I-": I_minus,
            "I''": [i for i in I if i not in I_plus],
            "I'": [i for i in I if i not in I_minus],
            "R-": R_minus,
            "R+": R_plus,
            "R''": [r for r in R if r not in R_minus],
            "R'": [r for r in R if r not in R_plus],
        }

    @staticmethod
    def _zero_proxy(values: Sequence[float], k: int) -> float:
        if values[k] != 0:
            return abs(values[k])
        nonzero = [abs(v) for v in values if v != 0]
        if not nonzero:
            raise ValueError("All values are zero; cannot form proxy denominator.")
        return min(nonzero)

    def _proxies(self, k: int) -> Tuple[List[float], List[float]]:
        x_proxy = [
            self._zero_proxy([self.inputs[j][i] for j in range(self.n)], k)
            for i in range(self.m)
        ]
        y_proxy = [
            self._zero_proxy([self.outputs[j][r] for j in range(self.n)], k)
            for r in range(self.s)
        ]
        return x_proxy, y_proxy

    def _super_sbm_score(self, w_plus, w_minus, x_proxy, y_proxy) -> float:
        sets = self.sets
        n_e = len(sets["I'"]) + len(sets["R'"])
        n_c = len(sets["I-"]) + len(sets["R+"])
        numer = 1.0
        if n_e > 0:
            for i in sets["I'"]:
                numer += w_plus[i] / (n_e * x_proxy[i])
            for r in sets["R'"]:
                numer += w_minus[r] / (n_e * y_proxy[r])
        denom = 1.0
        if n_c > 0:
            for i in sets["I-"]:
                denom -= w_plus[i] / (n_c * x_proxy[i])
            for r in sets["R+"]:
                denom -= w_minus[r] / (n_c * y_proxy[r])
        if denom <= 1e-12:
            raise RuntimeError("HSLS Super-SBM denominator is nonpositive.")
        return numer / denom

    def _solve_super_sbm(self, k: int) -> Dict:
        sets = self.sets
        x_proxy, y_proxy = self._proxies(k)
        n_e = len(sets["I'"]) + len(sets["R'"])
        n_c = len(sets["I-"]) + len(sets["R+"])
        others = [j for j in range(self.n) if j != k]

        prob = pulp.LpProblem(f"HSLS_Super_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=0)
        Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
        Wp = [pulp.LpVariable(f"Wp_{i}", lowBound=0) for i in range(self.m)]
        Wm = [pulp.LpVariable(f"Wm_{r}", lowBound=0) for r in range(self.s)]

        obj = t
        if n_e > 0:
            for i in sets["I'"]:
                obj += Wp[i] / (n_e * x_proxy[i])
            for r in sets["R'"]:
                obj += Wm[r] / (n_e * y_proxy[r])
        prob += obj

        norm = t
        if n_c > 0:
            for i in sets["I-"]:
                norm -= Wp[i] / (n_c * x_proxy[i])
            for r in sets["R+"]:
                norm -= Wm[r] / (n_c * y_proxy[r])
        prob += norm == 1

        for i in range(self.m):
            prob += (
                t * self.inputs[k][i]
                >= pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others) - Wp[i]
            )
        for r in range(self.s):
            prob += (
                t * self.outputs[k][r]
                <= pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others) + Wm[r]
            )
        add_rts(prob, Lam, others, t, self.rts)

        for r in sets["R+"]:
            prob += t * y_proxy[r] >= Wm[r]
        for i in sets["I-"]:
            prob += t * x_proxy[i] >= Wp[i]

        status = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[status] != "Optimal":
            raise RuntimeError(
                f"HSLS Super-SBM failed for DMU {k}: {pulp.LpStatus[status]}"
            )

        t_star = pulp.value(t)
        if t_star is None or t_star <= 1e-12:
            raise RuntimeError(f"Invalid t* for HSLS Super-SBM DMU {k}")

        lam = [0.0] * self.n
        for j in others:
            lam[j] = pulp.value(Lam[j]) / t_star

        w_plus = [
            max(0.0, sum(lam[j] * self.inputs[j][i] for j in range(self.n))
                - self.inputs[k][i])
            for i in range(self.m)
        ]
        w_minus = [
            max(0.0, self.outputs[k][r]
                - sum(lam[j] * self.outputs[j][r] for j in range(self.n)))
            for r in range(self.s)
        ]
        return {
            "sigma": self._super_sbm_score(w_plus, w_minus, x_proxy, y_proxy),
            "w_plus": w_plus,
            "w_minus": w_minus,
        }

    def _solve_modified_sbm(self, k: int, w_plus, w_minus) -> Dict:
        sets = self.sets
        x_proxy, y_proxy = self._proxies(k)
        n_c = len(sets["I+"]) + len(sets["R-"])
        n_e = len(sets["I''"]) + len(sets["R''"])
        others = [j for j in range(self.n) if j != k]

        prob = pulp.LpProblem(f"HSLS_Mod_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=0)
        Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
        Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(self.m)]
        Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(self.s)]

        obj = t
        if n_c > 0:
            for i in sets["I+"]:
                obj -= Sm[i] / (n_c * x_proxy[i])
            for r in sets["R-"]:
                obj -= Sp[r] / (n_c * y_proxy[r])
        prob += obj

        norm = t
        if n_e > 0:
            for i in sets["I''"]:
                norm += Sm[i] / (n_e * x_proxy[i])
            for r in sets["R''"]:
                norm += Sp[r] / (n_e * y_proxy[r])
        prob += norm == 1

        for i in range(self.m):
            prob += (
                t * self.inputs[k][i] - Sm[i] + t * w_plus[i]
                == pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others)
            )
        for r in range(self.s):
            prob += (
                t * self.outputs[k][r] + Sp[r] - t * w_minus[r]
                == pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others)
            )
        add_rts(prob, Lam, others, t, self.rts)

        status = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[status] != "Optimal":
            raise RuntimeError(
                f"HSLS Modified SBM failed for DMU {k}: {pulp.LpStatus[status]}"
            )
        t_star = pulp.value(t)
        if t_star is None or t_star <= 1e-12:
            raise RuntimeError(f"Invalid t* for HSLS Modified SBM DMU {k}")
        return {"gamma": pulp.value(prob.objective)}

    def evaluate_dmu(self, k: int) -> Dict:
        s1 = self._solve_super_sbm(k)
        s2 = self._solve_modified_sbm(k, s1["w_plus"], s1["w_minus"])
        sigma, gamma = s1["sigma"], s2["gamma"]
        if sigma > 1 + self.tol:
            ddot = (sigma - 1.0) * gamma + 1.0
        else:
            ddot = gamma
        return {
            "dmu": self.names[k],
            "sigma": sigma,
            "gamma": gamma,
            "score": ddot,
            "feasible": True,
        }

    def evaluate_all(self) -> List[Dict]:
        results = []
        for k in range(self.n):
            try:
                results.append(self.evaluate_dmu(k))
            except Exception:
                results.append({
                    "dmu": self.names[k],
                    "sigma": None,
                    "gamma": None,
                    "score": None,
                    "feasible": False,
                })
        ranks = rank_by_score([
            r["score"] if r["score"] is not None else float("-inf")
            for r in results
        ])
        for r, rk in zip(results, ranks):
            r["rank"] = rk if r["feasible"] else None
        return results


# ===========================================================================
# IBP — Paramanik et al. (2023)
# ===========================================================================

class IBPModel:
    """Two-stage IBP-SuperSBM (Paramanik et al., 2023). Score = ddot_gamma Eq. (14)."""

    name = "IBP"

    def __init__(
        self,
        inputs: Sequence[Sequence[float]],
        outputs: Sequence[Sequence[float]],
        dmu_names: Optional[Sequence[str]] = None,
        rts: str = "VRS",
        tol: float = 1e-8,
    ):
        self.inputs = [list(row) for row in inputs]
        self.outputs = [list(row) for row in outputs]
        self.n = len(self.inputs)
        self.m = len(self.inputs[0])
        self.s = len(self.outputs[0])
        self.names = (
            list(dmu_names) if dmu_names is not None
            else [str(i + 1) for i in range(self.n)]
        )
        self.rts = rts.upper()
        self.tol = tol
        self.x_bar, self.y_bar, self.x_min, self.y_min = self._translate()

    @staticmethod
    def _second_smallest_nonzero(values: Sequence[float]) -> float:
        delta = min(values)
        nonzero = sorted({v for v in values if v != 0.0})
        if not nonzero:
            raise ValueError("No nonzero values for base point.")
        if delta == 0.0:
            return nonzero[0]
        if len(nonzero) < 2:
            raise ValueError("Need two distinct nonzero values for base point.")
        return nonzero[1]

    def _translate(self):
        x_min, y_min = [], []
        for i in range(self.m):
            col = [self.inputs[j][i] for j in range(self.n)]
            x_min.append(2.0 * min(col) - self._second_smallest_nonzero(col))
        for r in range(self.s):
            col = [self.outputs[j][r] for j in range(self.n)]
            y_min.append(2.0 * min(col) - self._second_smallest_nonzero(col))

        x_bar = [
            [self.inputs[j][i] - x_min[i] for i in range(self.m)]
            for j in range(self.n)
        ]
        y_bar = [
            [self.outputs[j][r] - y_min[r] for r in range(self.s)]
            for j in range(self.n)
        ]
        for j in range(self.n):
            if any(v <= 0 for v in x_bar[j]) or any(v <= 0 for v in y_bar[j]):
                raise ValueError(f"Nonpositive translated data at DMU index {j}")
        return x_bar, y_bar, x_min, y_min

    @staticmethod
    def _super_score(v_minus, v_plus, x_p, y_p) -> float:
        m, s = len(x_p), len(y_p)
        numer = 1.0 + (1.0 / m) * sum(v_minus[i] / x_p[i] for i in range(m))
        denom = 1.0 - (1.0 / s) * sum(v_plus[r] / y_p[r] for r in range(s))
        if denom <= 1e-12:
            raise RuntimeError("IBP-SuperSBM denominator nonpositive.")
        return numer / denom

    def _ibp_super_sbm(self, p: int) -> Dict:
        others = [j for j in range(self.n) if j != p]
        prob = pulp.LpProblem(f"IBP_Super_{p}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Vm = [pulp.LpVariable(f"Vm_{i}", lowBound=0) for i in range(self.m)]
        Vp = [pulp.LpVariable(f"Vp_{r}", lowBound=0) for r in range(self.s)]

        prob += t + (1.0 / self.m) * pulp.lpSum(
            Vm[i] / self.x_bar[p][i] for i in range(self.m)
        )
        prob += t - (1.0 / self.s) * pulp.lpSum(
            Vp[r] / self.y_bar[p][r] for r in range(self.s)
        ) == 1
        for i in range(self.m):
            prob += (
                pulp.lpSum(Lam[j] * self.x_bar[j][i] for j in others) - Vm[i]
                <= t * self.x_bar[p][i]
            )
        for r in range(self.s):
            prob += (
                pulp.lpSum(Lam[j] * self.y_bar[j][r] for j in others) + Vp[r]
                >= t * self.y_bar[p][r]
            )
            prob += Vp[r] <= t * self.y_bar[p][r]
        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"IBP-SuperSBM failed for DMU {p}: {pulp.LpStatus[st]}"
            )

        t_star = pulp.value(t)
        lam = [0.0] * self.n
        for j in others:
            lam[j] = pulp.value(Lam[j]) / t_star

        v_minus = [
            max(0.0, sum(lam[j] * self.x_bar[j][i] for j in others) - self.x_bar[p][i])
            for i in range(self.m)
        ]
        v_plus = []
        for r in range(self.s):
            vp = max(
                0.0,
                self.y_bar[p][r] - sum(lam[j] * self.y_bar[j][r] for j in others),
            )
            v_plus.append(min(vp, self.y_bar[p][r]))

        return {
            "gamma": self._super_score(
                v_minus, v_plus, self.x_bar[p], self.y_bar[p]
            ),
            "v_minus": v_minus,
            "v_plus": v_plus,
        }

    def _revised_ibp_sbm(self, p: int, v_minus, v_plus) -> Dict:
        others = [j for j in range(self.n) if j != p]
        prob = pulp.LpProblem(f"IBP_Rev_{p}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(self.m)]
        Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(self.s)]

        prob += t - (1.0 / self.m) * pulp.lpSum(
            Sm[i] / self.x_bar[p][i] for i in range(self.m)
        )
        prob += t + (1.0 / self.s) * pulp.lpSum(
            Sp[r] / self.y_bar[p][r] for r in range(self.s)
        ) == 1
        for i in range(self.m):
            prob += (
                pulp.lpSum(Lam[j] * self.x_bar[j][i] for j in others) + Sm[i]
                == t * (self.x_bar[p][i] + v_minus[i])
            )
        for r in range(self.s):
            prob += (
                pulp.lpSum(Lam[j] * self.y_bar[j][r] for j in others) - Sp[r]
                == t * (self.y_bar[p][r] - v_plus[r])
            )
        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"Revised IBP-SBM failed for DMU {p}: {pulp.LpStatus[st]}"
            )
        return {"eta_bar": pulp.value(prob.objective)}

    def evaluate_dmu(self, p: int) -> Dict:
        s1 = self._ibp_super_sbm(p)
        s2 = self._revised_ibp_sbm(p, s1["v_minus"], s1["v_plus"])
        gamma, eta_bar = s1["gamma"], s2["eta_bar"]
        if gamma > 1.0 + self.tol:
            ddot = (gamma - 1.0) * eta_bar + 1.0
        else:
            ddot = eta_bar
        return {
            "dmu": self.names[p],
            "gamma": gamma,
            "eta_bar": eta_bar,
            "score": ddot,
            "feasible": True,
        }

    def evaluate_all(self) -> List[Dict]:
        results = []
        for k in range(self.n):
            try:
                results.append(self.evaluate_dmu(k))
            except Exception:
                results.append({
                    "dmu": self.names[k],
                    "gamma": None,
                    "eta_bar": None,
                    "score": None,
                    "feasible": False,
                })
        ranks = rank_by_score([
            r["score"] if r["score"] is not None else float("-inf")
            for r in results
        ])
        for r, rk in zip(results, ranks):
            r["rank"] = rk if r["feasible"] else None
        return results


# ===========================================================================
# Comparison
# ===========================================================================

def compare_models_one_rts(
    names: Sequence[str],
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    rts: str,
) -> Tuple[List[Dict], Dict[str, Dict[str, float]]]:
    lyhs = LYHSModel(inputs, outputs, dmu_names=names, rts=rts).evaluate_all()
    hsls = HSLSModel(inputs, outputs, dmu_names=names, rts=rts).evaluate_all()
    ibp = IBPModel(inputs, outputs, dmu_names=names, rts=rts).evaluate_all()

    rows = []
    for i, name in enumerate(names):
        rows.append({
            "DMU": name,
            "RTS": rts,
            "LYHS_score": lyhs[i]["score"],
            "LYHS_rank": lyhs[i]["rank"],
            "HSLS_score": hsls[i]["score"],
            "HSLS_rank": hsls[i]["rank"],
            "IBP_score": ibp[i]["score"],
            "IBP_rank": ibp[i]["rank"],
        })

    metrics = {
        "LYHS": score_metrics([r["LYHS_score"] for r in rows]),
        "HSLS": score_metrics([r["HSLS_score"] for r in rows]),
        "IBP": score_metrics([r["IBP_score"] for r in rows]),
    }
    return rows, metrics


def _print_score_table(rows: List[Dict], rts: str) -> None:
    print("=" * 96)
    print(f"Comparison under {rts}: LYHS | HSLS | IBP")
    print("=" * 96)
    print(
        f"{'DMU':>6} "
        f"{'LYHS':>14} {'Rk':>4} "
        f"{'HSLS':>14} {'Rk':>4} "
        f"{'IBP':>14} {'Rk':>4}"
    )
    print("-" * 96)
    for row in rows:
        print(
            f"{row['DMU']:>6} "
            f"{_fmt_score(row['LYHS_score']):>14} {_fmt_rank(row['LYHS_rank'])} "
            f"{_fmt_score(row['HSLS_score']):>14} {_fmt_rank(row['HSLS_rank'])} "
            f"{_fmt_score(row['IBP_score']):>14} {_fmt_rank(row['IBP_rank'])}"
        )
    print("-" * 96)


def _print_metrics(metrics: Dict[str, Dict[str, float]], rts: str) -> None:
    print(f"SDS / DS / Entropy under {rts}")
    print(f"{'Measure':<10} {'LYHS':>12} {'HSLS':>12} {'IBP':>12}")
    print("-" * 56)
    for key in ("SDS", "DS", "Entropy"):
        print(
            f"{key:<10} "
            f"{metrics['LYHS'][key]:12.6f} "
            f"{metrics['HSLS'][key]:12.6f} "
            f"{metrics['IBP'][key]:12.6f}"
        )
    print("-" * 56)


def compare_models(
    names: Sequence[str],
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    out_dir: Optional[Path] = None,
    rts_list: Sequence[str] = RTS_LIST,
) -> Dict[str, List[Dict]]:
    all_rows: Dict[str, List[Dict]] = {}
    all_metrics: Dict[str, Dict[str, Dict[str, float]]] = {}

    print("Scores: LYHS=theta*(Eq.12)  HSLS=ddot_sigma(Eq.12)  IBP=ddot_gamma(Eq.14)")
    print(f"RTS conditions: {', '.join(rts_list)}")
    print()

    for rts in rts_list:
        rows, metrics = compare_models_one_rts(names, inputs, outputs, rts)
        all_rows[rts] = rows
        all_metrics[rts] = metrics
        _print_score_table(rows, rts)
        _print_metrics(metrics, rts)
        print()

    # Summary metrics across RTS
    print("=" * 72)
    print("SDS / DS / Entropy summary across RTS")
    print("=" * 72)
    print(
        f"{'RTS':<6} {'Measure':<10} "
        f"{'LYHS':>12} {'HSLS':>12} {'IBP':>12}"
    )
    print("-" * 72)
    for rts in rts_list:
        for key in ("SDS", "DS", "Entropy"):
            print(
                f"{rts:<6} {key:<10} "
                f"{all_metrics[rts]['LYHS'][key]:12.6f} "
                f"{all_metrics[rts]['HSLS'][key]:12.6f} "
                f"{all_metrics[rts]['IBP'][key]:12.6f}"
            )
        print("-" * 72)
    print("Higher SDS/DS => more discrimination; lower Entropy => more reliable")

    if out_dir is not None:
        out_dir = Path(out_dir)
        scores_csv = out_dir / "results_compare_lyhs_hsls_ibp_v2.csv"
        metrics_csv = out_dir / "results_compare_lyhs_hsls_ibp_v2_metrics.csv"

        with scores_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "RTS", "DMU",
                    "LYHS_score", "LYHS_rank",
                    "HSLS_score", "HSLS_rank",
                    "IBP_score", "IBP_rank",
                ],
            )
            writer.writeheader()
            for rts in rts_list:
                for row in all_rows[rts]:
                    writer.writerow({
                        "RTS": rts,
                        "DMU": row["DMU"],
                        "LYHS_score": (
                            f"{row['LYHS_score']:.8f}"
                            if row["LYHS_score"] is not None else "Infeasible"
                        ),
                        "LYHS_rank": row["LYHS_rank"] if row["LYHS_rank"] is not None else "",
                        "HSLS_score": (
                            f"{row['HSLS_score']:.8f}"
                            if row["HSLS_score"] is not None else "Infeasible"
                        ),
                        "HSLS_rank": row["HSLS_rank"] if row["HSLS_rank"] is not None else "",
                        "IBP_score": (
                            f"{row['IBP_score']:.8f}"
                            if row["IBP_score"] is not None else "Infeasible"
                        ),
                        "IBP_rank": row["IBP_rank"] if row["IBP_rank"] is not None else "",
                    })

        with metrics_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["RTS", "Measure", "LYHS", "HSLS", "IBP"])
            for rts in rts_list:
                for key in ("SDS", "DS", "Entropy"):
                    writer.writerow([
                        rts,
                        key,
                        f"{all_metrics[rts]['LYHS'][key]:.8f}",
                        f"{all_metrics[rts]['HSLS'][key]:.8f}",
                        f"{all_metrics[rts]['IBP'][key]:.8f}",
                    ])

        print(f"\nCSV written: {scores_csv}")
        print(f"Metrics CSV written: {metrics_csv}")

    return all_rows


def main():
    out_dir = Path(__file__).resolve().parent
    data_path = out_dir / "data.csv"
    if not data_path.exists():
        raise FileNotFoundError(f"Missing input file: {data_path}")

    names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
    print(f"Data: {data_path}")
    print(f"DMUs: {len(names)} | inputs: {in_cols} | outputs: {out_cols}")
    print()

    compare_models(names, inputs, outputs, out_dir=out_dir)


if __name__ == "__main__":
    main()
