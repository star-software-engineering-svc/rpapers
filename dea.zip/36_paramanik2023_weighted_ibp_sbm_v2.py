"""
Paramanik et al. (2023) — Weighted IBP-SBM & IBP-SuperSBM  [v2]

Paper: Computers & Operations Research 150 (2023) 106057

Combines:
  - Weighted IBP-SBM          (efficiency; input- or output-oriented)
  - Weighted IBP-SuperSBM     (ISBP-SBM stage 1)
  - Weighted Revised IBP-SBM  (stage 2)
  - Composite score           Eq. (14)

Orientations (Charnes–Cooper linearization of the fractional SBM):
  - input  : minimize numerator, fix denominator = 1  -> rho  (typically <= 1)
  - output : maximize denominator, fix numerator = 1  -> phi  (typically >= 1)

Weights wx (inputs) and wy (outputs) are normalized to sum to 1.
Default: uniform wx_i = 1/m, wy_r = 1/s (recovers unweighted paper models).

Default input: data.csv (x* = inputs, y* = outputs).
Falls back to Table D.10 if data.csv is missing.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pulp


# ---------------------------------------------------------------------------
# Table D.10  (fallback)
# ---------------------------------------------------------------------------

TABLE_D10 = [
    # DMU, x1, x2, y1, y2, y3
    ("A", 1.03, -0.05, 0.56, -0.09, -0.44),
    ("B", 1.75, -0.17, 0.74, -0.24, -0.31),
    ("C", 1.44, -0.56, 1.37, -0.35, -0.21),
    ("D", 10.80, -0.22, 5.61, -0.98, -3.79),
    ("E", 1.30, -0.07, 0.49, -1.08, -0.34),
    ("F", 1.98, -0.10, 1.61, -0.44, -0.34),
    ("G", 0.97, -0.17, 0.82, -0.08, -0.43),
    ("H", 9.82, -2.32, 5.61, -1.42, -1.94),
    ("I", 1.59, 0.00, 0.52, 0.00, -0.37),
    ("J", 5.96, -0.15, 2.14, -0.52, -0.18),
    ("K", 1.29, -0.11, 0.57, 0.00, -0.24),
    ("L", 2.38, -0.25, 0.57, -0.67, -0.43),
    ("M", 10.30, -0.16, 9.56, -0.58, 0.00),
]

# Table 2 — proposed approach under VRS (uniform weights, input-oriented)
TABLE2 = {
    "A": {"score": 0.3933, "rank": 11},
    "B": {"score": 0.4528, "rank": 9},
    "C": {"score": 1.1076, "rank": 4},
    "D": {"score": 0.3938, "rank": 10},
    "E": {"score": 0.1019, "rank": 13},
    "F": {"score": 0.7893, "rank": 6},
    "G": {"score": 2.0027, "rank": 1},
    "H": {"score": 1.2097, "rank": 3},
    "I": {"score": 0.5956, "rank": 7},
    "J": {"score": 0.5670, "rank": 8},
    "K": {"score": 1.0144, "rank": 5},
    "L": {"score": 0.1566, "rank": 12},
    "M": {"score": 1.2990, "rank": 2},
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def normalize_weights(
    w: Optional[Sequence[float]], n: int, name: str = "w"
) -> List[float]:
    if w is None:
        return [1.0 / n] * n
    ww = [float(v) for v in w]
    if len(ww) != n:
        raise ValueError(f"{name} length must be {n}, got {len(ww)}")
    if any(v < 0 for v in ww):
        raise ValueError(f"{name} must be nonnegative.")
    s = sum(ww)
    if s <= 0:
        raise ValueError(f"{name} must sum to > 0.")
    return [v / s for v in ww]


def _safe_inv(v: float, eps: float = 1e-12) -> float:
    return 1.0 / v if v > eps else 1.0 / eps


def _second_smallest_nonzero(values: Sequence[float]) -> float:
    delta = min(values)
    nonzero = sorted({v for v in values if v != 0.0})
    if not nonzero:
        raise ValueError("No nonzero values for base point.")
    if delta == 0.0:
        return nonzero[0]
    if len(nonzero) < 2:
        raise ValueError("Need two distinct nonzero values for base point.")
    return nonzero[1]


def translate(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Tuple[List[List[float]], List[List[float]], List[float], List[float]]:
    """IBP base-point translation (Eq. 8)."""
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])
    x_min, y_min = [], []
    for i in range(m):
        col = [inputs[j][i] for j in range(n)]
        x_min.append(2.0 * min(col) - _second_smallest_nonzero(col))
    for r in range(s):
        col = [outputs[j][r] for j in range(n)]
        y_min.append(2.0 * min(col) - _second_smallest_nonzero(col))

    x_bar = [[inputs[j][i] - x_min[i] for i in range(m)] for j in range(n)]
    y_bar = [[outputs[j][r] - y_min[r] for r in range(s)] for j in range(n)]
    for j in range(n):
        if any(v <= 0 for v in x_bar[j]) or any(v <= 0 for v in y_bar[j]):
            raise ValueError(f"Nonpositive translated data at DMU index {j}")
    return x_bar, y_bar, x_min, y_min


def _add_rts(prob, Lam, idxs, t, rts: str) -> None:
    total = pulp.lpSum(Lam[j] for j in idxs)
    rts = rts.upper()
    if rts == "CRS":
        return
    if rts == "VRS":
        prob += total == t
    elif rts == "NDRS":
        prob += total >= t
    elif rts == "NIRS":
        prob += total <= t
    else:
        raise ValueError(rts)


# ---------------------------------------------------------------------------
# Weighted IBP-SBM  (efficiency)
# ---------------------------------------------------------------------------

def ibp_sbm(
    x_bar,
    y_bar,
    p: int,
    rts: str = "VRS",
    orientation: str = "input",
    wx: Optional[Sequence[float]] = None,
    wy: Optional[Sequence[float]] = None,
    msg: bool = False,
) -> Dict:
    """
    Weighted IBP-SBM efficiency for DMU p.

    orientation='input'  -> rho = objective (min form)
    orientation='output' -> phi = objective (max form); also returns rho=1/phi
    """
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    wx = normalize_weights(wx, m, "wx")
    wy = normalize_weights(wy, s, "wy")
    orient = orientation.lower()

    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = [pulp.LpVariable(f"L_{j}", lowBound=0) for j in range(n)]
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    num = t - pulp.lpSum(wx[i] * Sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
    den = t + pulp.lpSum(wy[r] * Sp[r] * _safe_inv(y_bar[p][r]) for r in range(s))

    if orient == "input":
        prob = pulp.LpProblem(f"IBP_SBM_IN_{p}", pulp.LpMinimize)
        prob += num
        prob += den == 1
    elif orient == "output":
        prob = pulp.LpProblem(f"IBP_SBM_OUT_{p}", pulp.LpMaximize)
        prob += den
        prob += num == 1
    else:
        raise ValueError("orientation must be 'input' or 'output'")

    for i in range(m):
        prob += pulp.lpSum(Lam[j] * x_bar[j][i] for j in range(n)) + Sm[i] == t * x_bar[p][i]
    for r in range(s):
        prob += pulp.lpSum(Lam[j] * y_bar[j][r] for j in range(n)) - Sp[r] == t * y_bar[p][r]
    _add_rts(prob, Lam, range(n), t, rts)

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"IBP-SBM failed for DMU {p}: {pulp.LpStatus[st]}")

    t_star = pulp.value(t)
    obj = pulp.value(prob.objective)
    out = {
        "s_minus": [pulp.value(Sm[i]) / t_star for i in range(m)],
        "s_plus": [pulp.value(Sp[r]) / t_star for r in range(s)],
        "lambda": [pulp.value(Lam[j]) / t_star for j in range(n)],
        "orientation": orient,
    }
    if orient == "input":
        out["eta"] = obj
        out["rho"] = obj
        out["phi"] = 1.0 / max(obj, 1e-12)
    else:
        out["eta"] = obj
        out["phi"] = obj
        out["rho"] = 1.0 / max(obj, 1e-12)
    return out


# ---------------------------------------------------------------------------
# Weighted IBP-SuperSBM  (stage 1)
# ---------------------------------------------------------------------------

def _super_score_weighted(v_minus, v_plus, x_p, y_p, wx, wy) -> float:
    numer = 1.0 + sum(wx[i] * v_minus[i] * _safe_inv(x_p[i]) for i in range(len(x_p)))
    denom = 1.0 - sum(wy[r] * v_plus[r] * _safe_inv(y_p[r]) for r in range(len(y_p)))
    if denom <= 1e-12:
        raise RuntimeError("IBP-SuperSBM denominator nonpositive.")
    return numer / denom


def ibp_super_sbm(
    x_bar,
    y_bar,
    p: int,
    rts: str = "VRS",
    orientation: str = "input",
    wx: Optional[Sequence[float]] = None,
    wy: Optional[Sequence[float]] = None,
    msg: bool = False,
) -> Dict:
    """Weighted IBP-SuperSBM / ISBP-SBM for DMU p."""
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    others = [j for j in range(n) if j != p]
    wx = normalize_weights(wx, m, "wx")
    wy = normalize_weights(wy, s, "wy")
    orient = orientation.lower()

    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
    Vm = [pulp.LpVariable(f"Vm_{i}", lowBound=0) for i in range(m)]
    Vp = [pulp.LpVariable(f"Vp_{r}", lowBound=0) for r in range(s)]

    num = t + pulp.lpSum(wx[i] * Vm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
    den = t - pulp.lpSum(wy[r] * Vp[r] * _safe_inv(y_bar[p][r]) for r in range(s))

    if orient == "input":
        prob = pulp.LpProblem(f"IBP_SuperSBM_IN_{p}", pulp.LpMinimize)
        prob += num
        prob += den == 1
    elif orient == "output":
        # Maximize super-efficiency denominator form; score recovered from slacks
        prob = pulp.LpProblem(f"IBP_SuperSBM_OUT_{p}", pulp.LpMaximize)
        prob += den
        prob += num == 1
    else:
        raise ValueError("orientation must be 'input' or 'output'")

    for i in range(m):
        prob += pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) - Vm[i] <= t * x_bar[p][i]
    for r in range(s):
        prob += pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) + Vp[r] >= t * y_bar[p][r]
        prob += Vp[r] <= t * y_bar[p][r]
    _add_rts(prob, Lam, others, t, rts)

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"IBP-SuperSBM failed for DMU {p}: {pulp.LpStatus[st]}")

    t_star = pulp.value(t)
    lam = [0.0] * n
    for j in others:
        lam[j] = pulp.value(Lam[j]) / t_star

    # Recompute slacks from lambda (numerical consistency for stage 2)
    v_minus = [
        max(0.0, sum(lam[j] * x_bar[j][i] for j in others) - x_bar[p][i]) for i in range(m)
    ]
    v_plus = []
    for r in range(s):
        vp = max(0.0, y_bar[p][r] - sum(lam[j] * y_bar[j][r] for j in others))
        v_plus.append(min(vp, y_bar[p][r]))

    gamma = _super_score_weighted(v_minus, v_plus, x_bar[p], y_bar[p], wx, wy)
    return {
        "gamma": gamma,
        "v_minus": v_minus,
        "v_plus": v_plus,
        "lambda": lam,
        "orientation": orient,
        "phi_gamma": 1.0 / max(gamma, 1e-12) if orient == "output" else None,
    }


# ---------------------------------------------------------------------------
# Weighted Revised IBP-SBM  (stage 2)  +  composite Eq. (14)
# ---------------------------------------------------------------------------

def revised_ibp_sbm(
    x_bar,
    y_bar,
    p: int,
    v_minus,
    v_plus,
    rts: str = "VRS",
    orientation: str = "input",
    wx: Optional[Sequence[float]] = None,
    wy: Optional[Sequence[float]] = None,
    msg: bool = False,
) -> Dict:
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    others = [j for j in range(n) if j != p]
    wx = normalize_weights(wx, m, "wx")
    wy = normalize_weights(wy, s, "wy")
    orient = orientation.lower()

    # Objective uses original translated values (paper Eq. 13);
    # constraints use the stage-1 projection.
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    num = t - pulp.lpSum(wx[i] * Sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
    den = t + pulp.lpSum(wy[r] * Sp[r] * _safe_inv(y_bar[p][r]) for r in range(s))

    if orient == "input":
        prob = pulp.LpProblem(f"Revised_IBP_IN_{p}", pulp.LpMinimize)
        prob += num
        prob += den == 1
    elif orient == "output":
        prob = pulp.LpProblem(f"Revised_IBP_OUT_{p}", pulp.LpMaximize)
        prob += den
        prob += num == 1
    else:
        raise ValueError("orientation must be 'input' or 'output'")

    for i in range(m):
        prob += (
            pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) + Sm[i]
            == t * (x_bar[p][i] + v_minus[i])
        )
    for r in range(s):
        prob += (
            pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) - Sp[r]
            == t * (y_bar[p][r] - v_plus[r])
        )
    _add_rts(prob, Lam, others, t, rts)

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"Revised IBP-SBM failed for DMU {p}: {pulp.LpStatus[st]}")

    t_star = pulp.value(t)
    obj = pulp.value(prob.objective)
    out = {
        "s_minus": [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(m)],
        "s_plus": [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(s)],
        "lambda": [0.0 if j == p else pulp.value(Lam[j]) / t_star for j in range(n)],
        "orientation": orient,
    }
    if orient == "input":
        out["eta_bar"] = obj
        out["rho"] = obj
        out["phi"] = 1.0 / max(obj, 1e-12)
    else:
        out["eta_bar"] = obj
        out["phi"] = obj
        out["rho"] = 1.0 / max(obj, 1e-12)
    return out


def two_stage(
    inputs,
    outputs,
    x_bar,
    y_bar,
    p: int,
    rts: str = "VRS",
    orientation: str = "input",
    wx: Optional[Sequence[float]] = None,
    wy: Optional[Sequence[float]] = None,
    tol: float = 1e-8,
) -> Dict:
    """
    Stage 1: Weighted IBP-SuperSBM -> Gamma*, v-, v+
    Stage 2: Weighted Revised IBP-SBM -> eta_bar*, s-, s+
    Eq. (14): ddot_Gamma*  (input: rho-style; output: phi-style then rho=1/phi)
    """
    orient = orientation.lower()
    s1 = ibp_super_sbm(x_bar, y_bar, p, rts=rts, orientation=orient, wx=wx, wy=wy)
    s2 = revised_ibp_sbm(
        x_bar, y_bar, p, s1["v_minus"], s1["v_plus"],
        rts=rts, orientation=orient, wx=wx, wy=wy,
    )

    gamma, eta_bar = s1["gamma"], s2["eta_bar"]

    if orient == "input":
        # gamma, eta_bar are rho-style
        ddot = (gamma - 1.0) * eta_bar + 1.0 if gamma > 1.0 + tol else eta_bar
        score_rho, score_phi = ddot, 1.0 / max(ddot, 1e-12)
    else:
        # stage-1 gamma is always numer/denom (>=1 when super);
        # stage-2 eta_bar is phi (>=1). Convert gamma to phi form for Eq.(14).
        phi_g = 1.0 / max(gamma, 1e-12)  # if gamma is rho-style from slack formula
        # Slack formula returns numer/denom which is rho-style for super (>=1 when super).
        # For output orientation, use phi_stage1 = gamma (if we redefined) —
        # Keep consistent: gamma from _super_score is always (1+..)/(1-..) >= 1 when super.
        # Output-oriented composite on the reciprocal scale (phi):
        #   If inefficient: gamma ~ eta < 1 in rho form.
        # Use rho-form composite then invert for phi display.
        ddot_rho = (gamma - 1.0) * s2["rho"] + 1.0 if gamma > 1.0 + tol else s2["rho"]
        ddot = 1.0 / max(ddot_rho, 1e-12)  # phi-style proposed score
        score_phi, score_rho = ddot, ddot_rho

    m, s = len(inputs[0]), len(outputs[0])
    vm, vp = s1["v_minus"], s1["v_plus"]
    sm, sp = s2["s_minus"], s2["s_plus"]

    return {
        "gamma": gamma,
        "eta_bar": eta_bar,
        "ddot_gamma": ddot if orient == "input" else score_rho,  # always rho-style for ranking
        "ddot_phi": score_phi,
        "ddot_rho": score_rho if orient == "output" else ddot,
        "v_minus": vm,
        "v_plus": vp,
        "s_minus": sm,
        "s_plus": sp,
        "proj1_x": [inputs[p][i] + vm[i] for i in range(m)],
        "proj1_y": [outputs[p][r] - vp[r] for r in range(s)],
        "proj_x": [inputs[p][i] + vm[i] - sm[i] for i in range(m)],
        "proj_y": [outputs[p][r] - vp[r] + sp[r] for r in range(s)],
        "orientation": orient,
    }


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def load_d10():
    names = [r[0] for r in TABLE_D10]
    inputs = [[r[1], r[2]] for r in TABLE_D10]
    outputs = [[r[3], r[4], r[5]] for r in TABLE_D10]
    return names, inputs, outputs, ["x1", "x2"], ["y1", "y2", "y3"]


def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")
    if dmu_col not in fields:
        raise ValueError(f"DMU column '{dmu_col}' not found.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def _clean(v: float, tol: float = 1e-8) -> float:
    return 0.0 if abs(v) < tol else v


def write_results_csv(
    path: Path,
    rows: List[Dict],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    orientation: str,
) -> None:
    header = [
        "DMU",
        "orientation",
        "IBP_SBM_eta",
        "IBP_SBM_rho",
        "IBP_SBM_phi",
        "IBP_SuperSBM_Gamma",
        "Revised_IBP_eta_bar",
        "Proposed_ddot_rho",
        "Proposed_ddot_phi",
        "Rank",
    ]
    for c in in_cols:
        header += [f"v_minus_{c}", f"s_minus_{c}", f"proj1_{c}", f"proj_{c}"]
    for c in out_cols:
        header += [f"v_plus_{c}", f"s_plus_{c}", f"proj1_{c}", f"proj_{c}"]

    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for row in rows:
            line = [
                row["dmu"],
                orientation,
                f"{row['eta']:.8f}",
                f"{row['eta_rho']:.8f}",
                f"{row['eta_phi']:.8f}",
                f"{row['gamma']:.8f}",
                f"{row['eta_bar']:.8f}",
                f"{row['ddot_rho']:.8f}",
                f"{row['ddot_phi']:.8f}",
                row["rank"],
            ]
            for i in range(len(in_cols)):
                line += [
                    f"{_clean(row['v_minus'][i]):.8f}",
                    f"{_clean(row['s_minus'][i]):.8f}",
                    f"{row['proj1_x'][i]:.8f}",
                    f"{row['proj_x'][i]:.8f}",
                ]
            for r in range(len(out_cols)):
                line += [
                    f"{_clean(row['v_plus'][r]):.8f}",
                    f"{_clean(row['s_plus'][r]):.8f}",
                    f"{row['proj1_y'][r]:.8f}",
                    f"{row['proj_y'][r]:.8f}",
                ]
            w.writerow(line)


def run_orientation(
    names,
    inputs,
    outputs,
    x_bar,
    y_bar,
    in_cols,
    out_cols,
    orientation: str,
    wx,
    wy,
    rts: str = "VRS",
) -> List[Dict]:
    results = []
    for p, name in enumerate(names):
        eff = ibp_sbm(
            x_bar, y_bar, p, rts=rts, orientation=orientation, wx=wx, wy=wy
        )
        res = two_stage(
            inputs, outputs, x_bar, y_bar, p,
            rts=rts, orientation=orientation, wx=wx, wy=wy,
        )
        res["dmu"] = name
        res["eta"] = eff["eta"]
        res["eta_rho"] = eff["rho"]
        res["eta_phi"] = eff["phi"]
        if orientation == "input":
            res["ddot_rho"] = res["ddot_gamma"]
            res["ddot_phi"] = 1.0 / max(res["ddot_gamma"], 1e-12)
        else:
            res["ddot_rho"] = res["ddot_rho"]
            res["ddot_phi"] = res["ddot_phi"]
        results.append(res)

    # Rank by proposed rho (higher better)
    order = sorted(range(len(results)), key=lambda i: -results[i]["ddot_rho"])
    for rk, i in enumerate(order, start=1):
        results[i]["rank"] = rk
    return results


def main():
    # ---- Config ----
    # Orientation: "input" or "output"
    ORIENTATION = "input"
    # Weights: None = uniform (paper default). Example gold/silver/bronze:
    #   WX = [3, 1]           # two inputs
    #   WY = [3, 2, 1, 1, 1, 1, 1, 1]  # eight outputs
    WX = None
    WY = None
    RTS = "VRS"

    out_dir = Path(__file__).resolve().parent
    data_path = out_dir / "data.csv"

    if data_path.exists():
        names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
        data_label = str(data_path)
        csv_path = out_dir / f"results_data_weighted_ibp_{ORIENTATION}.csv"
    else:
        names, inputs, outputs, in_cols, out_cols = load_d10()
        data_label = "Table D.10 (fallback)"
        csv_path = out_dir / f"results_table_weighted_ibp_{ORIENTATION}.csv"

    m, s = len(in_cols), len(out_cols)
    wx = normalize_weights(WX, m, "wx")
    wy = normalize_weights(WY, s, "wy")
    x_bar, y_bar, x_min, y_min = translate(inputs, outputs)

    print("Paramanik et al. (2023) — Weighted IBP-SBM & IBP-SuperSBM [v2]")
    print(f"Data: {data_label}")
    print(f"DMUs: {len(names)} | inputs: {in_cols} | outputs: {out_cols}")
    print(f"Base point x_min = {[round(v, 6) for v in x_min]}")
    print(f"Base point y_min = {[round(v, 6) for v in y_min]}")
    print(f"RTS: {RTS} | orientation: {ORIENTATION}")
    print(f"wx (inputs)  = {dict(zip(in_cols, [round(v, 6) for v in wx]))}")
    print(f"wy (outputs) = {dict(zip(out_cols, [round(v, 6) for v in wy]))}")
    print()

    results = run_orientation(
        names, inputs, outputs, x_bar, y_bar, in_cols, out_cols,
        ORIENTATION, wx, wy, rts=RTS,
    )

    print("=" * 88)
    print(f"Weighted IBP-SBM + two-stage IBP-SuperSBM ({ORIENTATION}-oriented, {RTS})")
    print("=" * 88)
    print(
        f"{'DMU':>5} {'eta':>10} {'rho':>10} {'phi':>10} "
        f"{'Gamma*':>10} {'eta_bar':>10} {'ddot_rho':>10} {'ddot_phi':>10} {'Rk':>4}"
    )
    print("-" * 88)

    for res in results:
        print(
            f"{res['dmu']:>5} {res['eta']:10.6f} {res['eta_rho']:10.6f} {res['eta_phi']:10.6f} "
            f"{res['gamma']:10.6f} {res['eta_bar']:10.6f} "
            f"{res['ddot_rho']:10.6f} {res['ddot_phi']:10.6f} {res['rank']:4d}"
        )

    scores = [r["ddot_rho"] for r in results]
    mean = sum(scores) / len(scores)
    sds = math.sqrt(sum((x - mean) ** 2 for x in scores) / len(scores))
    ned = sum(1 for x in scores if x >= 1.0 - 1e-8)
    ds = max(scores) - min(scores)
    probs = [x / sum(scores) for x in scores]
    entropy = -sum(p * math.log(p) for p in probs if p > 0) / math.log(len(scores))

    print("-" * 88)
    print(f"SDS={sds:.4f}  NED={ned}  DS={ds:.4f}  Entropy={entropy:.4f}")

    # Table 2 check (uniform weights + input orientation + D.10 DMUs)
    if (
        ORIENTATION == "input"
        and WX is None
        and WY is None
        and all(name in TABLE2 for name in names)
        and len(names) == len(TABLE2)
    ):
        max_err = max(abs(r["ddot_rho"] - TABLE2[r["dmu"]]["score"]) for r in results)
        print(f"Max |Proposed - Table2| = {max_err:.6e}")
        print("MATCH Table 2:", max_err < 5e-4)

    print()
    print("=" * 88)
    print("Slacks and projections")
    print("  v-/v+ : IBP-SuperSBM (11)   s-/s+ : Revised IBP-SBM (13)")
    print("  proj  : Pareto projection (x+v--s-, y-v++s+)")
    print("=" * 88)
    for res in results:
        print(f"\nDMU {res['dmu']}  ddot_rho*={res['ddot_rho']:.6f}")
        print(f"  inputs  {list(in_cols)}")
        print(f"    v-    {[round(_clean(v), 4) for v in res['v_minus']]}")
        print(f"    s-    {[round(_clean(v), 4) for v in res['s_minus']]}")
        print(f"    proj  {[round(v, 4) for v in res['proj_x']]}")
        print(f"  outputs {list(out_cols)}")
        print(f"    v+    {[round(_clean(v), 4) for v in res['v_plus']]}")
        print(f"    s+    {[round(_clean(v), 4) for v in res['s_plus']]}")
        print(f"    proj  {[round(v, 4) for v in res['proj_y']]}")

    write_results_csv(csv_path, results, in_cols, out_cols, ORIENTATION)
    print()
    print(f"CSV written: {csv_path}")
    print()
    print("Tip: set ORIENTATION='output' and/or WX/WY in main() for weighted OO runs.")


if __name__ == "__main__":
    main()
