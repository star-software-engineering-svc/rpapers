"""
Two-stage Improved Base-Point SBM (Paramanik, Sarkar & Sarkar, 2023)
Computers & Operations Research 150 (2023) 106057

Implements:
  - IBP-SBM          (Eq. 9 / linearized Eq. 10)
  - ISBP-SBM         (Eq. 11)
  - Revised IBP-SBM  (Eq. 13)
  - Composite score  (Eq. 14)

Default input: data.csv (x* = inputs, y* = outputs).
Falls back to Table D.10 if data.csv is missing.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import pulp


# ---------------------------------------------------------------------------
# Table D.10 (Sharp et al., 2007) — columns: x1, x2, y1, y2, y3
# ---------------------------------------------------------------------------

TABLE_D10 = [
    # name, x1, x2, y1, y2, y3
    ("A", 1.03, -0.05, 0.56, -0.09, -0.44),
    ("B", 1.75, -0.17, 0.74, -0.24, -0.31),
    ("C", 1.44, -0.56, 1.37, -0.35, -0.21),
    ("D", 10.80, -0.22, 5.61, -0.98, -3.79),
    ("E", 1.30, -0.07, 0.49, -1.08, -0.34),
    ("F", 1.98, -0.10, 1.61, -0.44, -0.34),
    ("G", 0.97, -0.17, 0.82, -0.08, -0.43),
    ("H", 9.82, -2.32, 5.61, -1.42, -1.94),
    ("I", 1.59, 0.00, 0.52, 0.00, -0.37),
    ("J", 5.96, -0.15, 2.14, -0.52, -0.18),
    ("K", 1.29, -0.11, 0.57, 0.00, -0.24),
    ("L", 2.38, -0.25, 0.57, -0.67, -0.43),
    ("M", 10.30, -0.16, 9.56, -0.58, 0.00),
]

# Table 1 — IBP-SBM efficiencies
TABLE1_IBP = {
    "VRS": {
        "A": 0.3933, "B": 0.4528, "C": 1.0000, "D": 0.3938, "E": 0.1019,
        "F": 0.7893, "G": 1.0000, "H": 1.0000, "I": 0.5956, "J": 0.5670,
        "K": 1.0000, "L": 0.1566, "M": 1.0000,
    },
    "CRS": {
        "A": 0.3933, "B": 0.4420, "C": 1.0000, "D": 0.3899, "E": 0.1018,
        "F": 0.7513, "G": 1.0000, "H": 1.0000, "I": 0.2231, "J": 0.5646,
        "K": 1.0000, "L": 0.1556, "M": 1.0000,
    },
    "NDRS": {
        "A": 0.3933, "B": 0.4420, "C": 1.0000, "D": 0.3899, "E": 0.1019,
        "F": 0.7513, "G": 1.0000, "H": 1.0000, "I": 0.2231, "J": 0.5646,
        "K": 1.0000, "L": 0.1566, "M": 1.0000,
    },
    "NIRS": {
        "A": 0.3933, "B": 0.4528, "C": 1.0000, "D": 0.3938, "E": 0.1018,
        "F": 0.7893, "G": 1.0000, "H": 1.0000, "I": 0.5956, "J": 0.5670,
        "K": 1.0000, "L": 0.1556, "M": 1.0000,
    },
}

# Table 2 — two-stage composite under VRS
TABLE2_COMPOSITE_VRS = {
    "A": 0.3933, "B": 0.4528, "C": 1.1076, "D": 0.3938, "E": 0.1019,
    "F": 0.7893, "G": 2.0027, "H": 1.2097, "I": 0.5956, "J": 0.5670,
    "K": 1.0144, "L": 0.1566, "M": 1.2990,
}


# ---------------------------------------------------------------------------
# Data translation (Eq. 7–8)
# ---------------------------------------------------------------------------

def _second_smallest_nonzero(values: Sequence[float]) -> float:
    """
    Second-smallest distinct value among nonzero observations.
    If the column minimum is 0, use the smallest nonzero value.
    """
    delta = min(values)
    nonzero_distinct = sorted({v for v in values if v != 0.0})
    if not nonzero_distinct:
        raise ValueError("Column has no nonzero values; cannot form base point.")
    if delta == 0.0:
        return nonzero_distinct[0]
    # delta should be the smallest nonzero
    if len(nonzero_distinct) < 2:
        raise ValueError("Need at least two distinct nonzero values for base point.")
    return nonzero_distinct[1]


def theoretical_base_point(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Tuple[List[float], List[float]]:
    """Eq. (8): x_min = 2*delta - bar_delta, y_min = 2*omega - bar_omega."""
    m = len(inputs[0])
    s = len(outputs[0])
    n = len(inputs)
    x_min = []
    for i in range(m):
        col = [inputs[j][i] for j in range(n)]
        delta = min(col)
        bar = _second_smallest_nonzero(col)
        x_min.append(2.0 * delta - bar)
    y_min = []
    for r in range(s):
        col = [outputs[j][r] for j in range(n)]
        omega = min(col)
        bar = _second_smallest_nonzero(col)
        y_min.append(2.0 * omega - bar)
    return x_min, y_min


def translate_data(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Tuple[List[List[float]], List[List[float]], List[float], List[float]]:
    x_min, y_min = theoretical_base_point(inputs, outputs)
    n = len(inputs)
    m = len(inputs[0])
    s = len(outputs[0])
    x_bar = [[inputs[j][i] - x_min[i] for i in range(m)] for j in range(n)]
    y_bar = [[outputs[j][r] - y_min[r] for r in range(s)] for j in range(n)]
    # All translated values must be strictly positive
    for j in range(n):
        for i in range(m):
            if x_bar[j][i] <= 0:
                raise ValueError(f"Nonpositive translated input at DMU {j}, i={i}")
        for r in range(s):
            if y_bar[j][r] <= 0:
                raise ValueError(f"Nonpositive translated output at DMU {j}, r={r}")
    return x_bar, y_bar, x_min, y_min


def _add_rts_constraint(prob, Lam, indices, t, rts: str, name: str = "rts"):
    """
    Linearized RTS on sum(Lambda):
      CRS : 0 <= sum <= inf  (no constraint)
      VRS : sum = t
      NDRS: sum >= t
      NIRS: sum <= t
    """
    rts = rts.upper()
    total = pulp.lpSum(Lam[j] for j in indices)
    if rts == "CRS":
        return
    if rts == "VRS":
        prob += total == t, name
    elif rts == "NDRS":
        prob += total >= t, name
    elif rts == "NIRS":
        prob += total <= t, name
    else:
        raise ValueError(f"Unknown RTS: {rts}")


# ---------------------------------------------------------------------------
# IBP-SBM (Eq. 9 / 10)
# ---------------------------------------------------------------------------

def solve_ibp_sbm(
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
    p: int,
    rts: str = "VRS",
    msg: bool = False,
) -> Dict:
    n = len(x_bar)
    m = len(x_bar[0])
    s = len(y_bar[0])

    prob = pulp.LpProblem(f"IBP_SBM_{p}_{rts}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = [pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in range(n)]
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    prob += t - (1.0 / m) * pulp.lpSum(Sm[i] / x_bar[p][i] for i in range(m))
    prob += t + (1.0 / s) * pulp.lpSum(Sp[r] / y_bar[p][r] for r in range(s)) == 1

    for i in range(m):
        prob += (
            pulp.lpSum(Lam[j] * x_bar[j][i] for j in range(n)) + Sm[i]
            == t * x_bar[p][i],
            f"xin_{i}",
        )
    for r in range(s):
        prob += (
            pulp.lpSum(Lam[j] * y_bar[j][r] for j in range(n)) - Sp[r]
            == t * y_bar[p][r],
            f"yout_{r}",
        )
    _add_rts_constraint(prob, Lam, range(n), t, rts)

    status = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(f"IBP-SBM nonoptimal for DMU {p}: {pulp.LpStatus[status]}")

    t_star = pulp.value(t)
    s_minus = [pulp.value(Sm[i]) / t_star for i in range(m)]
    s_plus = [pulp.value(Sp[r]) / t_star for r in range(s)]
    lam = [pulp.value(Lam[j]) / t_star for j in range(n)]
    eta = pulp.value(prob.objective)

    # Projection in translated space, then caller maps back if needed
    proj_x_bar = [x_bar[p][i] - s_minus[i] for i in range(m)]
    proj_y_bar = [y_bar[p][r] + s_plus[r] for r in range(s)]

    return {
        "eta": eta,
        "s_minus": s_minus,
        "s_plus": s_plus,
        "lambda": lam,
        "proj_x_bar": proj_x_bar,
        "proj_y_bar": proj_y_bar,
        "t": t_star,
    }


# ---------------------------------------------------------------------------
# ISBP-SBM (Eq. 11)
# ---------------------------------------------------------------------------

def solve_isbp_sbm(
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
    p: int,
    rts: str = "VRS",
    msg: bool = False,
) -> Dict:
    n = len(x_bar)
    m = len(x_bar[0])
    s = len(y_bar[0])
    others = [j for j in range(n) if j != p]

    prob = pulp.LpProblem(f"ISBP_SBM_{p}_{rts}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
    Vm = [pulp.LpVariable(f"Vm_{i}", lowBound=0) for i in range(m)]  # v-
    Vp = [pulp.LpVariable(f"Vp_{r}", lowBound=0) for r in range(s)]  # v+

    # min (1 + avg v-/x) / (1 - avg v+/y)
    prob += t + (1.0 / m) * pulp.lpSum(Vm[i] / x_bar[p][i] for i in range(m))
    prob += t - (1.0 / s) * pulp.lpSum(Vp[r] / y_bar[p][r] for r in range(s)) == 1

    for i in range(m):
        prob += (
            pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) - Vm[i]
            <= t * x_bar[p][i],
            f"xin_{i}",
        )
    for r in range(s):
        prob += (
            pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) + Vp[r]
            >= t * y_bar[p][r],
            f"yout_{r}",
        )
        prob += Vp[r] <= t * y_bar[p][r], f"vbound_{r}"

    _add_rts_constraint(prob, Lam, others, t, rts)

    status = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(f"ISBP-SBM nonoptimal for DMU {p}: {pulp.LpStatus[status]}")

    t_star = pulp.value(t)
    lam = [0.0] * n
    for j in others:
        lam[j] = pulp.value(Lam[j]) / t_star

    # Recompute slacks from lambda for numerical consistency with stage 2
    v_minus = []
    for i in range(m):
        ref = sum(lam[j] * x_bar[j][i] for j in others)
        v_minus.append(max(0.0, ref - x_bar[p][i]))
    v_plus = []
    for r in range(s):
        ref = sum(lam[j] * y_bar[j][r] for j in others)
        vp = max(0.0, y_bar[p][r] - ref)
        v_plus.append(min(vp, y_bar[p][r]))  # respect v+ <= y_bar

    gamma = _isbp_score(v_minus, v_plus, x_bar[p], y_bar[p])

    return {
        "gamma": gamma,  # Gamma* (stage-1 super-efficiency)
        "v_minus": v_minus,
        "v_plus": v_plus,
        "lambda": lam,
        "t": t_star,
    }


def _isbp_score(
    v_minus: Sequence[float],
    v_plus: Sequence[float],
    x_p: Sequence[float],
    y_p: Sequence[float],
) -> float:
    m = len(x_p)
    s = len(y_p)
    numer = 1.0 + (1.0 / m) * sum(v_minus[i] / x_p[i] for i in range(m))
    denom = 1.0 - (1.0 / s) * sum(v_plus[r] / y_p[r] for r in range(s))
    if denom <= 1e-12:
        raise RuntimeError("ISBP-SBM denominator nonpositive.")
    return numer / denom


def _ibp_score(
    s_minus: Sequence[float],
    s_plus: Sequence[float],
    x_p: Sequence[float],
    y_p: Sequence[float],
) -> float:
    m = len(x_p)
    s = len(y_p)
    numer = 1.0 - (1.0 / m) * sum(s_minus[i] / x_p[i] for i in range(m))
    denom = 1.0 + (1.0 / s) * sum(s_plus[r] / y_p[r] for r in range(s))
    return numer / denom


# ---------------------------------------------------------------------------
# Revised IBP-SBM (Eq. 13)
# ---------------------------------------------------------------------------

def solve_revised_ibp_sbm(
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
    p: int,
    v_minus: Sequence[float],
    v_plus: Sequence[float],
    rts: str = "VRS",
    msg: bool = False,
) -> Dict:
    n = len(x_bar)
    m = len(x_bar[0])
    s = len(y_bar[0])
    others = [j for j in range(n) if j != p]

    prob = pulp.LpProblem(f"Revised_IBP_SBM_{p}_{rts}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    prob += t - (1.0 / m) * pulp.lpSum(Sm[i] / x_bar[p][i] for i in range(m))
    prob += t + (1.0 / s) * pulp.lpSum(Sp[r] / y_bar[p][r] for r in range(s)) == 1

    for i in range(m):
        # sum λ x - v-* + s- = x_p  =>  sum λ x + s- = t*(x_p + v-*) after scaling
        prob += (
            pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) + Sm[i]
            == t * (x_bar[p][i] + v_minus[i]),
            f"xin_{i}",
        )
    for r in range(s):
        # sum λ y + v+* - s+ = y_p  =>  sum λ y - s+ = t*(y_p - v+*)
        prob += (
            pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) - Sp[r]
            == t * (y_bar[p][r] - v_plus[r]),
            f"yout_{r}",
        )
    _add_rts_constraint(prob, Lam, others, t, rts)

    status = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(
            f"Revised IBP-SBM nonoptimal for DMU {p}: {pulp.LpStatus[status]}"
        )

    t_star = pulp.value(t)
    s_minus = [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(m)]
    s_plus = [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(s)]
    lam = [0.0] * n
    for j in others:
        lam[j] = pulp.value(Lam[j]) / t_star
    eta_bar = pulp.value(prob.objective)

    return {
        "eta_bar": eta_bar,
        "s_minus": s_minus,
        "s_plus": s_plus,
        "lambda": lam,
        "t": t_star,
    }


# ---------------------------------------------------------------------------
# Two-stage approach (Eq. 14)
# ---------------------------------------------------------------------------

def evaluate_dmu_two_stage(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
    p: int,
    rts: str = "VRS",
    tol: float = 1e-8,
    msg: bool = False,
) -> Dict:
    stage1 = solve_isbp_sbm(x_bar, y_bar, p, rts=rts, msg=msg)
    stage2 = solve_revised_ibp_sbm(
        x_bar,
        y_bar,
        p,
        v_minus=stage1["v_minus"],
        v_plus=stage1["v_plus"],
        rts=rts,
        msg=msg,
    )

    gamma = stage1["gamma"]
    eta_bar = stage2["eta_bar"]
    if gamma > 1.0 + tol:
        ddot_gamma = (gamma - 1.0) * eta_bar + 1.0
    else:
        ddot_gamma = eta_bar

    m = len(inputs[0])
    s = len(outputs[0])
    v_m = stage1["v_minus"]
    v_p = stage1["v_plus"]
    s_m = stage2["s_minus"]
    s_p = stage2["s_plus"]

    # Original-space Pareto projection (after Eq. 13 discussion)
    proj_x = [inputs[p][i] + v_m[i] - s_m[i] for i in range(m)]
    proj_y = [outputs[p][r] - v_p[r] + s_p[r] for r in range(s)]
    # Stage-1 projection in original space
    proj1_x = [inputs[p][i] + v_m[i] for i in range(m)]
    proj1_y = [outputs[p][r] - v_p[r] for r in range(s)]

    return {
        "gamma": gamma,
        "eta_bar": eta_bar,
        "ddot_gamma": ddot_gamma,
        "v_minus": v_m,
        "v_plus": v_p,
        "s_minus": s_m,
        "s_plus": s_p,
        "projection_x": proj_x,
        "projection_y": proj_y,
        "stage1_projection_x": proj1_x,
        "stage1_projection_y": proj1_y,
    }


def load_table_d10():
    names = [row[0] for row in TABLE_D10]
    inputs = [[row[1], row[2]] for row in TABLE_D10]
    outputs = [[row[3], row[4], row[5]] for row in TABLE_D10]
    return names, inputs, outputs, ["x1", "x2"], ["y1", "y2", "y3"]


def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    """Load DEA data. Default: columns starting with x/X = inputs, y/Y = outputs."""
    import csv
    from pathlib import Path

    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")
    if dmu_col not in fields:
        raise ValueError(f"DMU column '{dmu_col}' not found.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def _fmt(vals: Sequence[float], nd: int = 4) -> str:
    cleaned = [0.0 if abs(v) < 1e-8 else v for v in vals]
    return "[" + ", ".join(f"{v:.{nd}f}" for v in cleaned) + "]"


def _clean(v: float, tol: float = 1e-8) -> float:
    return 0.0 if abs(v) < tol else v


def write_ibp_csv(
    path: str,
    names: Sequence[str],
    ibp_by_rts: Dict[str, Dict[str, float]],
    compare_table1: bool = False,
) -> None:
    import csv
    from pathlib import Path

    path = Path(path)
    rts_list = ["VRS", "CRS", "NDRS", "NIRS"]
    header = ["DMU"] + [f"IBP_SBM_{rts}" for rts in rts_list]
    if compare_table1:
        header += [f"Table1_{rts}" for rts in rts_list]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for name in names:
            row = [name]
            for rts in rts_list:
                row.append(f"{ibp_by_rts[rts][name]:.8f}")
            if compare_table1:
                for rts in rts_list:
                    row.append(f"{TABLE1_IBP[rts][name]:.4f}")
            writer.writerow(row)


def write_two_stage_csv(
    path: str,
    results: Sequence[Dict],
    ranks: Sequence[int],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    compare_table2: bool = False,
) -> None:
    import csv
    from pathlib import Path

    path = Path(path)
    header = [
        "DMU",
        "Gamma_star",
        "eta_bar_star",
        "ddot_Gamma_star",
        "rank",
    ]
    if compare_table2:
        header.insert(4, "Table2_ref")
    for c in in_cols:
        header += [f"v_minus_{c}", f"s_minus_{c}", f"proj1_{c}", f"proj_{c}"]
    for c in out_cols:
        header += [f"v_plus_{c}", f"s_plus_{c}", f"proj1_{c}", f"proj_{c}"]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for res, rank in zip(results, ranks):
            row = [
                res["dmu"],
                f"{res['gamma']:.8f}",
                f"{res['eta_bar']:.8f}",
                f"{res['ddot_gamma']:.8f}",
            ]
            if compare_table2:
                row.append(f"{TABLE2_COMPOSITE_VRS[res['dmu']]:.4f}")
            row.append(rank)
            m = len(in_cols)
            s = len(out_cols)
            for i in range(m):
                row += [
                    f"{_clean(res['v_minus'][i]):.8f}",
                    f"{_clean(res['s_minus'][i]):.8f}",
                    f"{res['stage1_projection_x'][i]:.8f}",
                    f"{res['projection_x'][i]:.8f}",
                ]
            for r in range(s):
                row += [
                    f"{_clean(res['v_plus'][r]):.8f}",
                    f"{_clean(res['s_plus'][r]):.8f}",
                    f"{res['stage1_projection_y'][r]:.8f}",
                    f"{res['projection_y'][r]:.8f}",
                ]
            writer.writerow(row)


def main():
    from pathlib import Path

    out_dir = Path(__file__).resolve().parent
    data_path = out_dir / "data.csv"

    if data_path.exists():
        names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
        data_label = str(data_path)
        compare_paper = False
        ibp_csv = out_dir / "results_data_ibp_sbm.csv"
        two_stage_csv = out_dir / "results_data_two_stage.csv"
    else:
        names, inputs, outputs, in_cols, out_cols = load_table_d10()
        data_label = "Table D.10 (fallback)"
        compare_paper = True
        ibp_csv = out_dir / "results_table1_ibp_sbm.csv"
        two_stage_csv = out_dir / "results_table_d10_two_stage.csv"

    x_bar, y_bar, x_min, y_min = translate_data(inputs, outputs)

    print("Paramanik et al. (2023) — Improved Base-Point SBM")
    print(f"Data: {data_label}")
    print(f"DMUs: {len(names)} | inputs: {in_cols} | outputs: {out_cols}")
    print(f"Theoretical base point x_min = {[round(v, 6) for v in x_min]}")
    print(f"Theoretical base point y_min = {[round(v, 6) for v in y_min]}")
    print()

    # ----- IBP-SBM under four RTS -----
    print("=" * 100)
    print("IBP-SBM efficiency scores")
    print("=" * 100)
    max_err = 0.0
    ibp_by_rts: Dict[str, Dict[str, float]] = {}
    for rts in ["VRS", "CRS", "NDRS", "NIRS"]:
        print(f"\n[{rts}]")
        if compare_paper:
            print(f"{'DMU':>5} {'IBP-SBM':>10} {'Table1':>10} {'|diff|':>12}")
        else:
            print(f"{'DMU':>5} {'IBP-SBM':>12}")
        print("-" * 40)
        ibp_by_rts[rts] = {}
        for p, name in enumerate(names):
            res = solve_ibp_sbm(x_bar, y_bar, p, rts=rts)
            ibp_by_rts[rts][name] = res["eta"]
            if compare_paper:
                ref = TABLE1_IBP[rts][name]
                diff = abs(res["eta"] - ref)
                max_err = max(max_err, diff)
                print(f"{name:>5} {res['eta']:10.4f} {ref:10.4f} {diff:12.2e}")
            else:
                print(f"{name:>5} {res['eta']:12.6f}")
    print("-" * 40)
    if compare_paper:
        print(f"Max |IBP-SBM - Table1| over all RTS = {max_err:.6e}")
        print("MATCH Table 1:", max_err < 5e-4)
    write_ibp_csv(str(ibp_csv), names, ibp_by_rts, compare_table1=compare_paper)
    print(f"CSV written: {ibp_csv}")

    # ----- Two-stage under VRS -----
    print()
    print("=" * 100)
    print("Two-stage approach under VRS (Eq. 14)")
    print("=" * 100)
    if compare_paper:
        print(
            f"{'DMU':>5} {'Gamma*':>10} {'eta_bar*':>10} {'ddot_G*':>10} "
            f"{'Table2':>10} {'|diff|':>10} {'Rank':>5}"
        )
    else:
        print(
            f"{'DMU':>5} {'Gamma*':>12} {'eta_bar*':>12} {'ddot_G*':>12} {'Rank':>5}"
        )
    print("-" * 70)

    results = []
    for p, name in enumerate(names):
        res = evaluate_dmu_two_stage(inputs, outputs, x_bar, y_bar, p, rts="VRS")
        res["dmu"] = name
        results.append(res)

    order = sorted(range(len(results)), key=lambda i: -results[i]["ddot_gamma"])
    ranks = [0] * len(results)
    for rank, i in enumerate(order, start=1):
        ranks[i] = rank

    max_err2 = 0.0
    for res, rank in zip(results, ranks):
        if compare_paper:
            ref = TABLE2_COMPOSITE_VRS[res["dmu"]]
            diff = abs(res["ddot_gamma"] - ref)
            max_err2 = max(max_err2, diff)
            print(
                f"{res['dmu']:>5} {res['gamma']:10.4f} {res['eta_bar']:10.4f} "
                f"{res['ddot_gamma']:10.4f} {ref:10.4f} {diff:10.2e} {rank:5d}"
            )
        else:
            print(
                f"{res['dmu']:>5} {res['gamma']:12.6f} {res['eta_bar']:12.6f} "
                f"{res['ddot_gamma']:12.6f} {rank:5d}"
            )
    print("-" * 70)
    if compare_paper:
        print(f"Max |Eq.14 - Table2| = {max_err2:.6e}")
        print("MATCH Table 2:", max_err2 < 5e-4)

    print()
    print("=" * 100)
    print("Slacks and projections (VRS two-stage)")
    print("  v- / v+ : ISBP-SBM (11) input savings / output surpluses")
    print("  s- / s+ : Revised IBP-SBM (13) input / output slacks")
    print("  proj1   : stage-1 projection (x+v-, y-v+)")
    print("  proj    : Pareto projection (x+v--s-, y-v++s+)")
    print("=" * 100)
    for res in results:
        print(f"\nDMU {res['dmu']} | Gamma*={res['gamma']:.6f}  "
              f"eta_bar*={res['eta_bar']:.6f}  ddot_G*={res['ddot_gamma']:.6f}")
        print(f"  inputs  {list(in_cols)}")
        print(f"    v-     {_fmt(res['v_minus'])}")
        print(f"    s-     {_fmt(res['s_minus'])}")
        print(f"    proj1  {_fmt(res['stage1_projection_x'])}")
        print(f"    proj   {_fmt(res['projection_x'])}")
        print(f"  outputs {list(out_cols)}")
        print(f"    v+     {_fmt(res['v_plus'])}")
        print(f"    s+     {_fmt(res['s_plus'])}")
        print(f"    proj1  {_fmt(res['stage1_projection_y'])}")
        print(f"    proj   {_fmt(res['projection_y'])}")
    print("=" * 100)

    write_two_stage_csv(
        str(two_stage_csv),
        results,
        ranks,
        in_cols,
        out_cols,
        compare_table2=compare_paper,
    )
    print(f"CSV written: {two_stage_csv}")


if __name__ == "__main__":
    main()
