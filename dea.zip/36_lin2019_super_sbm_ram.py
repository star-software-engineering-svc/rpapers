"""
Lin, Yang & Huang (2019) — Modified Super-SBM with negative data (LYHS)
Computers & Industrial Engineering 135 (2019) 39–52

Implements:
  - Modified Super-SBM  Eq. (6) / LP Eq. (13)
  - Modified SBM        Eq. (10)
  - Super-efficiency    Eq. (12)

Default input: data.csv (x* = inputs, y* = outputs).
Falls back to Table 2 if data.csv is missing.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pulp


# ---------------------------------------------------------------------------
# Table 2 data: Cost, Effluent | Saleable, CO2, Methane
# ---------------------------------------------------------------------------

TABLE2 = [
    # DMU, x1, x2, y1, y2, y3
    (1, 1.03, -0.05, 0.56, -0.09, -0.44),
    (2, 1.75, -0.17, 0.74, -0.24, -0.31),
    (3, 1.44, -0.56, 1.37, -0.35, -0.21),
    (4, 10.8, -0.22, 5.61, -0.98, -3.79),
    (5, 1.3, -0.07, 0.49, -1.08, -0.34),
    (6, 1.98, -0.1, 1.61, -0.44, -0.34),
    (7, 0.97, -0.17, 0.82, -0.08, -0.43),
    (8, 9.82, -2.32, 5.61, -1.42, -1.94),
    (9, 1.59, 0.0, 0.52, 0.0, -0.37),
    (10, 5.96, -0.15, 2.14, -0.52, -0.18),
    (11, 1.29, -0.11, 0.57, 0.0, -0.24),
    (12, 2.38, -0.25, 0.57, -0.67, -0.43),
    (13, 10.3, -0.16, 9.56, -0.58, 0.0),
]

# Table 3 — proposed approach score and rank
TABLE3 = {
    1: {"score": 0.9568, "rank": 6},
    2: {"score": 0.9084, "rank": 8},
    3: {"score": 1.0966, "rank": 3},
    4: {"score": 0.4884, "rank": 13},
    5: {"score": 0.7523, "rank": 11},
    6: {"score": 0.8620, "rank": 9},
    7: {"score": 1.0188, "rank": 5},
    8: {"score": 1.4239, "rank": 1},
    9: {"score": 0.9484, "rank": 7},
    10: {"score": 0.7245, "rank": 12},
    11: {"score": 1.0271, "rank": 4},
    12: {"score": 0.7878, "rank": 10},
    13: {"score": 1.4058, "rank": 2},
}


# ---------------------------------------------------------------------------
# Ranges & weights
# ---------------------------------------------------------------------------

def compute_ranges(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Tuple[List[float], List[float], List[int], List[int]]:
    """P_i^- = max x - min x, P_r^+ = max y - min y; I, O = positive-range sets."""
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])
    p_in, p_out = [], []
    for i in range(m):
        col = [inputs[j][i] for j in range(n)]
        p_in.append(max(col) - min(col))
    for r in range(s):
        col = [outputs[j][r] for j in range(n)]
        p_out.append(max(col) - min(col))
    I = [i for i in range(m) if p_in[i] > 0]
    O = [r for r in range(s) if p_out[r] > 0]
    return p_in, p_out, I, O


def default_weights(m: int, s: int) -> Tuple[List[float], List[float]]:
    """Paper: mu_i = 1/m, nu_r = 1/s (here m=2, s=3)."""
    return [1.0 / m] * m, [1.0 / s] * s


# ---------------------------------------------------------------------------
# Stage 1: Modified Super-SBM  Eq. (6) / (13)
# ---------------------------------------------------------------------------

def solve_super_sbm(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
    p_in: Sequence[float],
    p_out: Sequence[float],
    I: Sequence[int],
    O: Sequence[int],
    mu: Sequence[float],
    nu: Sequence[float],
    msg: bool = False,
) -> Dict:
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])
    others = [j for j in range(n) if j != k]

    prob = pulp.LpProblem(f"SuperSBM_RAM_{k}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
    Wm = [pulp.LpVariable(f"Wm_{i}", lowBound=0) for i in range(m)]  # w-
    Wp = [pulp.LpVariable(f"Wp_{r}", lowBound=0) for r in range(s)]  # w+

    # min t + Σ μ W-/P   s.t.  t - Σ ν W+/P = 1
    prob += t + pulp.lpSum(mu[i] * Wm[i] / p_in[i] for i in I)
    prob += t - pulp.lpSum(nu[r] * Wp[r] / p_out[r] for r in O) == 1

    for i in range(m):
        if i in I:
            prob += (
                pulp.lpSum(Lam[j] * inputs[j][i] for j in others) - Wm[i]
                <= t * inputs[k][i]
            )
        else:
            # identical inputs across DMUs under VRS
            prob += pulp.lpSum(Lam[j] * inputs[j][i] for j in others) == t * inputs[k][i]
            prob += Wm[i] == 0

    for r in range(s):
        if r in O:
            prob += (
                pulp.lpSum(Lam[j] * outputs[j][r] for j in others) + Wp[r]
                >= t * outputs[k][r]
            )
            prob += Wp[r] <= t * p_out[r]
        else:
            prob += pulp.lpSum(Lam[j] * outputs[j][r] for j in others) == t * outputs[k][r]
            prob += Wp[r] == 0

    prob += pulp.lpSum(Lam[j] for j in others) == t  # VRS

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"Super-SBM failed for DMU {k}: {pulp.LpStatus[st]}")

    t_star = pulp.value(t)
    lam = [0.0] * n
    for j in others:
        lam[j] = pulp.value(Lam[j]) / t_star

    # Recompute w from lambda for numerical consistency
    w_minus = [0.0] * m
    for i in I:
        ref = sum(lam[j] * inputs[j][i] for j in others)
        w_minus[i] = max(0.0, ref - inputs[k][i])
    w_plus = [0.0] * s
    for r in O:
        ref = sum(lam[j] * outputs[j][r] for j in others)
        w_plus[r] = min(max(0.0, outputs[k][r] - ref), p_out[r])

    sigma = _super_score(w_minus, w_plus, p_in, p_out, I, O, mu, nu)
    return {
        "sigma": sigma,
        "w_minus": w_minus,
        "w_plus": w_plus,
        "lambda": lam,
    }


def _super_score(w_minus, w_plus, p_in, p_out, I, O, mu, nu) -> float:
    numer = 1.0 + sum(mu[i] * w_minus[i] / p_in[i] for i in I)
    denom = 1.0 - sum(nu[r] * w_plus[r] / p_out[r] for r in O)
    if denom <= 1e-12:
        raise RuntimeError("Super-SBM denominator nonpositive.")
    return numer / denom


def _sbm_score(s_minus, s_plus, p_in, p_out, I, O, mu, nu) -> float:
    numer = 1.0 - sum(mu[i] * s_minus[i] / p_in[i] for i in I)
    denom = 1.0 + sum(nu[r] * s_plus[r] / p_out[r] for r in O)
    return numer / denom


# ---------------------------------------------------------------------------
# Stage 2: Modified SBM  Eq. (10)
# ---------------------------------------------------------------------------

def solve_modified_sbm(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
    w_minus: Sequence[float],
    w_plus: Sequence[float],
    p_in: Sequence[float],
    p_out: Sequence[float],
    I: Sequence[int],
    O: Sequence[int],
    mu: Sequence[float],
    nu: Sequence[float],
    msg: bool = False,
) -> Dict:
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])
    others = [j for j in range(n) if j != k]

    prob = pulp.LpProblem(f"Modified_SBM_RAM_{k}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    # min t - Σ μ S-/P   s.t.  t + Σ ν S+/P = 1
    prob += t - pulp.lpSum(mu[i] * Sm[i] / p_in[i] for i in I)
    prob += t + pulp.lpSum(nu[r] * Sp[r] / p_out[r] for r in O) == 1

    for i in range(m):
        # Σ λ x - w* + s- = x_k  =>  Σ Λ x + S- = t (x_k + w*)
        if i in I:
            prob += (
                pulp.lpSum(Lam[j] * inputs[j][i] for j in others) + Sm[i]
                == t * (inputs[k][i] + w_minus[i])
            )
        else:
            prob += (
                pulp.lpSum(Lam[j] * inputs[j][i] for j in others)
                == t * inputs[k][i]
            )
            prob += Sm[i] == 0

    for r in range(s):
        # Σ λ y + w* - s+ = y_k  =>  Σ Λ y - S+ = t (y_k - w*)
        if r in O:
            prob += (
                pulp.lpSum(Lam[j] * outputs[j][r] for j in others) - Sp[r]
                == t * (outputs[k][r] - w_plus[r])
            )
        else:
            prob += (
                pulp.lpSum(Lam[j] * outputs[j][r] for j in others)
                == t * outputs[k][r]
            )
            prob += Sp[r] == 0

    prob += pulp.lpSum(Lam[j] for j in others) == t

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"Modified SBM failed for DMU {k}: {pulp.LpStatus[st]}")

    t_star = pulp.value(t)
    s_minus = [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(m)]
    s_plus = [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(s)]
    rho = pulp.value(prob.objective)
    return {
        "rho": rho,
        "s_minus": s_minus,
        "s_plus": s_plus,
    }


# ---------------------------------------------------------------------------
# Two-stage + Eq. (12)
# ---------------------------------------------------------------------------

def evaluate_dmu(
    inputs, outputs, k, p_in, p_out, I, O, mu, nu, tol: float = 1e-8
) -> Dict:
    s1 = solve_super_sbm(inputs, outputs, k, p_in, p_out, I, O, mu, nu)
    s2 = solve_modified_sbm(
        inputs, outputs, k, s1["w_minus"], s1["w_plus"], p_in, p_out, I, O, mu, nu
    )

    sigma, rho = s1["sigma"], s2["rho"]
    # Eq. (12): if sigma > 1 use sigma, else use rho
    theta = sigma if sigma > 1.0 + tol else rho

    m, s = len(inputs[0]), len(outputs[0])
    wm, wp = s1["w_minus"], s1["w_plus"]
    sm, sp = s2["s_minus"], s2["s_plus"]

    # Projection Eqs. (14)–(15): for i in I use x+w-s, else x; similarly outputs
    proj_x = []
    for i in range(m):
        if i in I:
            proj_x.append(inputs[k][i] + wm[i] - sm[i])
        else:
            proj_x.append(inputs[k][i])
    proj_y = []
    for r in range(s):
        if r in O:
            proj_y.append(outputs[k][r] - wp[r] + sp[r])
        else:
            proj_y.append(outputs[k][r])

    return {
        "sigma": sigma,
        "rho": rho,
        "theta": theta,
        "w_minus": wm,
        "w_plus": wp,
        "s_minus": sm,
        "s_plus": sp,
        "proj_x": proj_x,
        "proj_y": proj_y,
        "proj1_x": [inputs[k][i] + wm[i] for i in range(m)],
        "proj1_y": [outputs[k][r] - wp[r] for r in range(s)],
    }


def load_table2():
    names = [str(r[0]) for r in TABLE2]
    inputs = [[r[1], r[2]] for r in TABLE2]
    outputs = [[r[3], r[4], r[5]] for r in TABLE2]
    return names, inputs, outputs, ["Cost", "Effluent"], ["Saleable", "CO2", "Methane"]


def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    """Load DEA data. Default: columns starting with x/X = inputs, y/Y = outputs."""
    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")
    if dmu_col not in fields:
        raise ValueError(f"DMU column '{dmu_col}' not found.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def _clean(v: float, tol: float = 1e-8) -> float:
    return 0.0 if abs(v) < tol else v


def write_results_csv(
    path: Path,
    rows: List[Dict],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    compare_table3: bool = False,
) -> None:
    header = [
        "DMU",
        "sigma_star",
        "rho_star",
        "theta_Eq12",
        "Rank",
    ]
    if compare_table3:
        header = [
            "DMU",
            "sigma_star",
            "rho_star",
            "theta_Eq12",
            "Table3_score",
            "Rank",
            "Table3_rank",
            "abs_diff",
        ]
    for c in in_cols:
        header += [f"w_minus_{c}", f"s_minus_{c}", f"proj1_{c}", f"proj_{c}"]
    for c in out_cols:
        header += [f"w_plus_{c}", f"s_plus_{c}", f"proj1_{c}", f"proj_{c}"]

    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for row in rows:
            if compare_table3:
                dmu = int(row["dmu"])
                ref = TABLE3[dmu]
                line = [
                    row["dmu"],
                    f"{row['sigma']:.8f}",
                    f"{row['rho']:.8f}",
                    f"{row['theta']:.8f}",
                    f"{ref['score']:.4f}",
                    row["rank"],
                    ref["rank"],
                    f"{row['abs_diff']:.8e}",
                ]
            else:
                line = [
                    row["dmu"],
                    f"{row['sigma']:.8f}",
                    f"{row['rho']:.8f}",
                    f"{row['theta']:.8f}",
                    row["rank"],
                ]
            for i in range(len(in_cols)):
                line += [
                    f"{_clean(row['w_minus'][i]):.8f}",
                    f"{_clean(row['s_minus'][i]):.8f}",
                    f"{row['proj1_x'][i]:.8f}",
                    f"{row['proj_x'][i]:.8f}",
                ]
            for r in range(len(out_cols)):
                line += [
                    f"{_clean(row['w_plus'][r]):.8f}",
                    f"{_clean(row['s_plus'][r]):.8f}",
                    f"{row['proj1_y'][r]:.8f}",
                    f"{row['proj_y'][r]:.8f}",
                ]
            w.writerow(line)


def main():
    out_dir = Path(__file__).resolve().parent
    data_path = out_dir / "data.csv"

    if data_path.exists():
        names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
        data_label = str(data_path)
        compare_table3 = False
        csv_path = out_dir / "results_data_lin2019.csv"
    else:
        names, inputs, outputs, in_cols, out_cols = load_table2()
        data_label = "Table 2 (fallback)"
        compare_table3 = True
        csv_path = out_dir / "results_table3_lin2019.csv"

    m, s = len(in_cols), len(out_cols)
    p_in, p_out, I, O = compute_ranges(inputs, outputs)
    mu, nu = default_weights(m, s)

    print("Lin, Yang & Huang (2019) — Modified Super-SBM (RAM)")
    print(f"Data: {data_label}")
    print(f"DMUs: {len(names)} | inputs: {in_cols} | outputs: {out_cols}")
    print(f"P- (inputs)  = {[round(v, 4) for v in p_in]}  I={list(I)}")
    print(f"P+ (outputs) = {[round(v, 4) for v in p_out]}  O={list(O)}")
    print(f"Weights mu={[round(v, 6) for v in mu]}, nu={[round(v, 6) for v in nu]}")
    print()

    results = []
    for k, name in enumerate(names):
        res = evaluate_dmu(inputs, outputs, k, p_in, p_out, I, O, mu, nu)
        res["dmu"] = name
        results.append(res)

    order = sorted(range(len(results)), key=lambda i: -results[i]["theta"])
    ranks = [0] * len(results)
    for rk, i in enumerate(order, start=1):
        ranks[i] = rk

    print("=" * 88)
    print("Proposed super-efficiency (Eq. 12)")
    print("=" * 88)
    if compare_table3:
        print(
            f"{'DMU':>5} {'sigma*':>10} {'rho*':>10} {'theta*':>10} "
            f"{'Table3':>10} {'|diff|':>10} {'Rank':>5} {'T3Rk':>5}"
        )
    else:
        print(
            f"{'DMU':>5} {'sigma*':>12} {'rho*':>12} {'theta*':>12} {'Rank':>5}"
        )
    print("-" * 88)

    max_err = 0.0
    rows_out = []
    for res, rk in zip(results, ranks):
        if compare_table3:
            dmu = int(res["dmu"])
            ref = TABLE3[dmu]
            diff = abs(res["theta"] - ref["score"])
            max_err = max(max_err, diff)
            rows_out.append({**res, "rank": rk, "abs_diff": diff})
            print(
                f"{dmu:5d} {res['sigma']:10.4f} {res['rho']:10.4f} {res['theta']:10.4f} "
                f"{ref['score']:10.4f} {diff:10.2e} {rk:5d} {ref['rank']:5d}"
            )
        else:
            rows_out.append({**res, "rank": rk})
            print(
                f"{res['dmu']:>5} {res['sigma']:12.6f} {res['rho']:12.6f} "
                f"{res['theta']:12.6f} {rk:5d}"
            )

    print("-" * 88)
    if compare_table3:
        print(f"Max |theta* - Table3| = {max_err:.6e}")
        print("MATCH Table 3:", max_err < 5e-4)

    print()
    print("=" * 88)
    print("Slacks and projections")
    print("  w-/w+ : Super-SBM (6)   s-/s+ : Modified SBM (10)")
    print("  proj  : Pareto projection (x+w--s-, y-w++s+)")
    print("=" * 88)
    for res in results:
        print(f"\nDMU {res['dmu']}  theta*={res['theta']:.6f}")
        print(f"  inputs  {list(in_cols)}")
        print(f"    w-    {[round(_clean(v), 4) for v in res['w_minus']]}")
        print(f"    s-    {[round(_clean(v), 4) for v in res['s_minus']]}")
        print(f"    proj  {[round(v, 4) for v in res['proj_x']]}")
        print(f"  outputs {list(out_cols)}")
        print(f"    w+    {[round(_clean(v), 4) for v in res['w_plus']]}")
        print(f"    s+    {[round(_clean(v), 4) for v in res['s_plus']]}")
        print(f"    proj  {[round(v, 4) for v in res['proj_y']]}")

    write_results_csv(csv_path, rows_out, in_cols, out_cols, compare_table3=compare_table3)
    print()
    print(f"CSV written: {csv_path}")


if __name__ == "__main__":
    main()
