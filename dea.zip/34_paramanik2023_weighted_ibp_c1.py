"""
Paramanik et al. (2023) — Weighted IO/OO IBP-SBM (Appendix C.1)
+ full two-stage proposed approach

Paper: Computers & Operations Research 150 (2023) 106057

  C.1  Weighted input- or output-oriented IBP-SBM
       eta = (1 - WI/m * sum w_i- s_i-/x_bar) / (1 + WO/s * sum w_r+ s_r+/y_bar)
       sum_i w_i- = m,  sum_r w_r+ = s
       input-oriented  : WI=1, WO=0
       output-oriented : WI=0, WO=1
       non-oriented    : WI=1, WO=1  (recovers Eq. 9 when weights are uniform)

  Stage 1  Weighted IBP-SuperSBM (ISBP-SBM), same WI/WO & weights
  Stage 2  Weighted Revised IBP-SBM (Pareto projection)
  Eq. (14) Composite final score

Data: data1.csv + weights.csv
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pulp


TABLE2 = {
    "A": 0.3933, "B": 0.4528, "C": 1.1076, "D": 0.3938, "E": 0.1019,
    "F": 0.7893, "G": 2.0027, "H": 1.2097, "I": 0.5956, "J": 0.5670,
    "K": 1.0144, "L": 0.1566, "M": 1.2990,
}


# ---------------------------------------------------------------------------
# Weights / orientation  (paper C.1)
# ---------------------------------------------------------------------------

def normalize_paper_weights(
    w: Optional[Sequence[float]], n: int, name: str = "w"
) -> List[float]:
    """
    Paper: sum w = n (m or s). Accept any nonnegative scale; renormalize to sum n.
    Uniform default: w_i = 1 for all i.
    """
    if w is None:
        return [1.0] * n
    ww = [float(v) for v in w]
    if len(ww) != n:
        raise ValueError(f"{name} length must be {n}, got {len(ww)}")
    if any(v < 0 for v in ww):
        raise ValueError(f"{name} must be nonnegative.")
    s = sum(ww)
    if s <= 0:
        raise ValueError(f"{name} must sum to > 0.")
    return [v * n / s for v in ww]


def orientation_flags(orientation: str) -> Tuple[float, float]:
    o = orientation.lower().strip()
    if o in ("input", "in", "io"):
        return 1.0, 0.0
    if o in ("output", "out", "oo"):
        return 0.0, 1.0
    if o in ("nonoriented", "non-oriented", "both", "no"):
        return 1.0, 1.0
    raise ValueError(f"Unknown orientation: {orientation}")


def load_weights(
    path: str,
    in_cols: Sequence[str],
    out_cols: Sequence[str],
) -> Tuple[str, List[float], List[float]]:
    """
    weights.csv formats supported:
      variable,weight
      orientation,input          # optional; default input
      x1,3
      x2,1
      y1,3
      ...
    Missing variables default to weight 1.
    """
    path = Path(path)
    raw: Dict[str, float] = {}
    orientation = "input"

    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = [c.strip() for c in reader.fieldnames]
        # allow either variable/weight or key/value
        var_key = next(
            (c for c in fields if c.lower() in ("variable", "key", "name", "col")),
            fields[0],
        )
        w_key = next(
            (c for c in fields if c.lower() in ("weight", "value", "w")),
            fields[1] if len(fields) > 1 else fields[0],
        )
        for row in reader:
            k = str(row[var_key]).strip()
            v = str(row[w_key]).strip()
            if not k:
                continue
            if k.lower() == "orientation":
                orientation = v
                continue
            if k.lower() in ("wi", "wo"):
                continue  # derived from orientation
            raw[k] = float(v)

    wx = [raw.get(c, 1.0) for c in in_cols]
    wy = [raw.get(c, 1.0) for c in out_cols]
    return orientation, wx, wy


# ---------------------------------------------------------------------------
# Base-point translation (Eq. 8)
# ---------------------------------------------------------------------------

def _second_smallest_nonzero(values: Sequence[float]) -> float:
    delta = min(values)
    nonzero = sorted({v for v in values if v != 0.0})
    if not nonzero:
        raise ValueError("No nonzero values for base point.")
    if delta == 0.0:
        return nonzero[0]
    if len(nonzero) < 2:
        raise ValueError("Need two distinct nonzero values for base point.")
    return nonzero[1]


def translate(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Tuple[List[List[float]], List[List[float]], List[float], List[float]]:
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])
    x_min, y_min = [], []
    for i in range(m):
        col = [inputs[j][i] for j in range(n)]
        x_min.append(2.0 * min(col) - _second_smallest_nonzero(col))
    for r in range(s):
        col = [outputs[j][r] for j in range(n)]
        y_min.append(2.0 * min(col) - _second_smallest_nonzero(col))

    x_bar = [[inputs[j][i] - x_min[i] for i in range(m)] for j in range(n)]
    y_bar = [[outputs[j][r] - y_min[r] for r in range(s)] for j in range(n)]
    for j in range(n):
        if any(v <= 0 for v in x_bar[j]) or any(v <= 0 for v in y_bar[j]):
            raise ValueError(f"Nonpositive translated data at DMU index {j}")
    return x_bar, y_bar, x_min, y_min


def _add_rts(prob, Lam, idxs, t, rts: str) -> None:
    total = pulp.lpSum(Lam[j] for j in idxs)
    rts = rts.upper()
    if rts == "CRS":
        return
    if rts == "VRS":
        prob += total == t
    elif rts == "NDRS":
        prob += total >= t
    elif rts == "NIRS":
        prob += total <= t
    else:
        raise ValueError(rts)


def _safe_inv(v: float, eps: float = 1e-12) -> float:
    return 1.0 / v if v > eps else 1.0 / eps


# ---------------------------------------------------------------------------
# C.1 Weighted IBP-SBM
# ---------------------------------------------------------------------------

def ibp_sbm_c1(
    x_bar,
    y_bar,
    p: int,
    wx: Sequence[float],
    wy: Sequence[float],
    WI: float = 1.0,
    WO: float = 0.0,
    rts: str = "VRS",
    msg: bool = False,
) -> Dict:
    """
    Eq. (C.1). LP via Charnes–Cooper.
    WI/WO switch input / output / non-oriented.
    """
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    wx = normalize_paper_weights(wx, m, "wx")
    wy = normalize_paper_weights(wy, s, "wy")

    # Coefficients in objective: (WI/m)*w_i  and  (WO/s)*w_r
    cx = [(WI / m) * wx[i] for i in range(m)]
    cy = [(WO / s) * wy[r] for r in range(s)]

    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = [pulp.LpVariable(f"L_{j}", lowBound=0) for j in range(n)]
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    # Fractional: (1 - sum cx s-/x) / (1 + sum cy s+/y)
    # CC: min t - sum cx Sm/x   s.t.  t + sum cy Sp/y = 1
    # When WO=0, den constraint forces t=1 (input-oriented).
    # When WI=0, num is t; we still minimize eta = t / den with den=1 via CC,
    # but for pure OO (WI=0) eta = 1/(1+avg) so we maximize den with num=1.
    if WI > 0 and WO == 0:
        # input-oriented: eta = 1 - sum cx s-/x  (linear)
        prob = pulp.LpProblem(f"IBP_SBM_C1_IN_{p}", pulp.LpMinimize)
        prob += 1.0 - pulp.lpSum(cx[i] * Sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
        # use t=1 scaling for RTS / constraints consistency
        t_fixed = True
    elif WI == 0 and WO > 0:
        # output-oriented: eta = 1 / (1 + sum cy s+/y)
        # maximize phi = 1 + sum cy s+/y, return eta = 1/phi
        prob = pulp.LpProblem(f"IBP_SBM_C1_OUT_{p}", pulp.LpMaximize)
        prob += 1.0 + pulp.lpSum(cy[r] * Sp[r] * _safe_inv(y_bar[p][r]) for r in range(s))
        t_fixed = True
    else:
        # non-oriented (WI=WO=1) or mixed
        prob = pulp.LpProblem(f"IBP_SBM_C1_NO_{p}", pulp.LpMinimize)
        prob += t - pulp.lpSum(cx[i] * Sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
        prob += t + pulp.lpSum(cy[r] * Sp[r] * _safe_inv(y_bar[p][r]) for r in range(s)) == 1
        t_fixed = False

    if t_fixed:
        # constraints without CC t-scaling (t ≡ 1)
        for i in range(m):
            prob += pulp.lpSum(Lam[j] * x_bar[j][i] for j in range(n)) + Sm[i] == x_bar[p][i]
        for r in range(s):
            prob += pulp.lpSum(Lam[j] * y_bar[j][r] for j in range(n)) - Sp[r] == y_bar[p][r]
        _add_rts(prob, Lam, range(n), 1.0, rts)
    else:
        for i in range(m):
            prob += pulp.lpSum(Lam[j] * x_bar[j][i] for j in range(n)) + Sm[i] == t * x_bar[p][i]
        for r in range(s):
            prob += pulp.lpSum(Lam[j] * y_bar[j][r] for j in range(n)) - Sp[r] == t * y_bar[p][r]
        _add_rts(prob, Lam, range(n), t, rts)

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"C.1 IBP-SBM failed for DMU {p}: {pulp.LpStatus[st]}")

    if t_fixed:
        t_star = 1.0
        sm = [pulp.value(Sm[i]) for i in range(m)]
        sp = [pulp.value(Sp[r]) for r in range(s)]
        lam = [pulp.value(Lam[j]) for j in range(n)]
    else:
        t_star = pulp.value(t)
        sm = [pulp.value(Sm[i]) / t_star for i in range(m)]
        sp = [pulp.value(Sp[r]) / t_star for r in range(s)]
        lam = [pulp.value(Lam[j]) / t_star for j in range(n)]

    if WI == 0 and WO > 0:
        phi = pulp.value(prob.objective)
        eta = 1.0 / max(phi, 1e-12)
    else:
        eta = pulp.value(prob.objective)
        # recompute from slacks for numerical consistency
        num = 1.0 - sum(cx[i] * sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
        den = 1.0 + sum(cy[r] * sp[r] * _safe_inv(y_bar[p][r]) for r in range(s))
        eta = num / max(den, 1e-12)
        phi = 1.0 / max(eta, 1e-12)

    return {
        "eta": eta,
        "rho": eta,
        "phi": phi,
        "s_minus": sm,
        "s_plus": sp,
        "lambda": lam,
    }


# ---------------------------------------------------------------------------
# Weighted IBP-SuperSBM  (stage 1, same WI/WO)
# ---------------------------------------------------------------------------

def _super_score(v_minus, v_plus, x_p, y_p, cx, cy) -> float:
    numer = 1.0 + sum(cx[i] * v_minus[i] * _safe_inv(x_p[i]) for i in range(len(x_p)))
    denom = 1.0 - sum(cy[r] * v_plus[r] * _safe_inv(y_p[r]) for r in range(len(y_p)))
    if denom <= 1e-12:
        raise RuntimeError("IBP-SuperSBM denominator nonpositive.")
    return numer / denom


def _build_super_constraints(prob, Lam, Vm, Vp, x_bar, y_bar, p, others, t_or_one):
    m, s = len(x_bar[0]), len(y_bar[0])
    scale = t_or_one
    for i in range(m):
        prob += (
            pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) - Vm[i]
            <= scale * x_bar[p][i]
        )
    for r in range(s):
        prob += (
            pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) + Vp[r]
            >= scale * y_bar[p][r]
        )
        prob += Vp[r] <= scale * y_bar[p][r]


def ibp_super_sbm(
    x_bar,
    y_bar,
    p: int,
    wx: Sequence[float],
    wy: Sequence[float],
    WI: float = 1.0,
    WO: float = 0.0,
    rts: str = "VRS",
    msg: bool = False,
) -> Dict:
    """
    Weighted ISBP-SBM with C.1 WI/WO.
    When one side is dropped from the objective (WI=0 or WO=0), a second
    lexicographic pass minimizes the unused surpluses/savings so stage-2
    projections stay unique and consistent with C.1 efficiency.
    """
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    others = [j for j in range(n) if j != p]
    wx = normalize_paper_weights(wx, m, "wx")
    wy = normalize_paper_weights(wy, s, "wy")
    cx = [(WI / m) * wx[i] for i in range(m)]
    cy = [(WO / s) * wy[r] for r in range(s)]
    # full weights for lexico cleanup / score when a side is inactive
    cx_full = [(1.0 / m) * wx[i] for i in range(m)]
    cy_full = [(1.0 / s) * wy[r] for r in range(s)]

    def _solve_phase(primary: bool, primary_obj_val: Optional[float] = None):
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Vm = [pulp.LpVariable(f"Vm_{i}", lowBound=0) for i in range(m)]
        Vp = [pulp.LpVariable(f"Vp_{r}", lowBound=0) for r in range(s)]

        if WI > 0 and WO == 0:
            prob = pulp.LpProblem(f"IBP_Super_IN_{p}_{int(primary)}", pulp.LpMinimize)
            primary_expr = 1.0 + pulp.lpSum(
                cx[i] * Vm[i] * _safe_inv(x_bar[p][i]) for i in range(m)
            )
            if primary:
                prob += primary_expr
            else:
                # minimize unused output surpluses (and residual input if tied)
                prob += pulp.lpSum(
                    cy_full[r] * Vp[r] * _safe_inv(y_bar[p][r]) for r in range(s)
                ) + 1e-6 * pulp.lpSum(
                    cx_full[i] * Vm[i] * _safe_inv(x_bar[p][i]) for i in range(m)
                )
                prob += primary_expr <= primary_obj_val + 1e-8
            t_fixed = True
        elif WI == 0 and WO > 0:
            if primary:
                prob = pulp.LpProblem(f"IBP_Super_OUT_{p}_1", pulp.LpMaximize)
                primary_expr = 1.0 - pulp.lpSum(
                    cy[r] * Vp[r] * _safe_inv(y_bar[p][r]) for r in range(s)
                )
                prob += primary_expr
            else:
                prob = pulp.LpProblem(f"IBP_Super_OUT_{p}_2", pulp.LpMinimize)
                # maximize den already done; now minimize unused input savings
                primary_expr = 1.0 - pulp.lpSum(
                    cy[r] * Vp[r] * _safe_inv(y_bar[p][r]) for r in range(s)
                )
                prob += pulp.lpSum(
                    cx_full[i] * Vm[i] * _safe_inv(x_bar[p][i]) for i in range(m)
                )
                prob += primary_expr >= primary_obj_val - 1e-8
            t_fixed = True
        else:
            prob = pulp.LpProblem(f"IBP_Super_NO_{p}", pulp.LpMinimize)
            prob += t + pulp.lpSum(cx[i] * Vm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
            prob += (
                t - pulp.lpSum(cy[r] * Vp[r] * _safe_inv(y_bar[p][r]) for r in range(s))
                == 1
            )
            t_fixed = False

        scale = 1.0 if t_fixed else t
        _build_super_constraints(prob, Lam, Vm, Vp, x_bar, y_bar, p, others, scale)
        _add_rts(prob, Lam, others, scale if not t_fixed else 1.0, rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(f"IBP-SuperSBM failed for DMU {p}: {pulp.LpStatus[st]}")

        if t_fixed:
            lam = [0.0] * n
            for j in others:
                lam[j] = pulp.value(Lam[j])
            obj = pulp.value(primary_expr) if primary else None
        else:
            t_star = pulp.value(t)
            lam = [0.0] * n
            for j in others:
                lam[j] = pulp.value(Lam[j]) / t_star
            obj = pulp.value(prob.objective)

        v_minus = [
            max(0.0, sum(lam[j] * x_bar[j][i] for j in others) - x_bar[p][i])
            for i in range(m)
        ]
        v_plus = []
        for r in range(s):
            vp = max(0.0, y_bar[p][r] - sum(lam[j] * y_bar[j][r] for j in others))
            v_plus.append(min(vp, y_bar[p][r]))
        return obj, lam, v_minus, v_plus

    if (WI > 0 and WO == 0) or (WI == 0 and WO > 0):
        obj1, _, _, _ = _solve_phase(primary=True)
        _, lam, v_minus, v_plus = _solve_phase(primary=False, primary_obj_val=obj1)
        if WI == 0 and WO > 0:
            gamma = 1.0 / max(obj1, 1e-12)
        else:
            gamma = _super_score(v_minus, v_plus, x_bar[p], y_bar[p], cx, cy)
    else:
        _, lam, v_minus, v_plus = _solve_phase(primary=True)
        gamma = _super_score(v_minus, v_plus, x_bar[p], y_bar[p], cx, cy)

    # Wipe solver noise so Eq. (14) does not treat ~1 as super-efficient
    v_minus = [0.0 if abs(v) < 1e-8 else v for v in v_minus]
    v_plus = [0.0 if abs(v) < 1e-8 else v for v in v_plus]
    if WI == 0 and WO > 0:
        pass  # gamma already from primary obj
    else:
        gamma = _super_score(v_minus, v_plus, x_bar[p], y_bar[p], cx, cy)
    if abs(gamma - 1.0) < 1e-6:
        gamma = 1.0

    return {"gamma": gamma, "v_minus": v_minus, "v_plus": v_plus, "lambda": lam}


# ---------------------------------------------------------------------------
# Weighted Revised IBP-SBM  (stage 2)
# ---------------------------------------------------------------------------

def revised_ibp_sbm(
    x_bar,
    y_bar,
    p: int,
    v_minus,
    v_plus,
    wx: Sequence[float],
    wy: Sequence[float],
    WI: float = 1.0,
    WO: float = 0.0,
    rts: str = "VRS",
    msg: bool = False,
) -> Dict:
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    others = [j for j in range(n) if j != p]
    wx = normalize_paper_weights(wx, m, "wx")
    wy = normalize_paper_weights(wy, s, "wy")
    cx = [(WI / m) * wx[i] for i in range(m)]
    cy = [(WO / s) * wy[r] for r in range(s)]

    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    # Objective denominators use original translated values (Eq. 13)
    if WI > 0 and WO == 0:
        prob = pulp.LpProblem(f"Revised_IN_{p}", pulp.LpMinimize)
        prob += 1.0 - pulp.lpSum(cx[i] * Sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
        t_fixed = True
    elif WI == 0 and WO > 0:
        prob = pulp.LpProblem(f"Revised_OUT_{p}", pulp.LpMaximize)
        prob += 1.0 + pulp.lpSum(cy[r] * Sp[r] * _safe_inv(y_bar[p][r]) for r in range(s))
        t_fixed = True
    else:
        prob = pulp.LpProblem(f"Revised_NO_{p}", pulp.LpMinimize)
        prob += t - pulp.lpSum(cx[i] * Sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
        prob += t + pulp.lpSum(cy[r] * Sp[r] * _safe_inv(y_bar[p][r]) for r in range(s)) == 1
        t_fixed = False

    x_rhs = [x_bar[p][i] + v_minus[i] for i in range(m)]
    y_rhs = [y_bar[p][r] - v_plus[r] for r in range(s)]

    if t_fixed:
        for i in range(m):
            prob += pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) + Sm[i] == x_rhs[i]
        for r in range(s):
            prob += pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) - Sp[r] == y_rhs[r]
        _add_rts(prob, Lam, others, 1.0, rts)
    else:
        for i in range(m):
            prob += pulp.lpSum(Lam[j] * x_bar[j][i] for j in others) + Sm[i] == t * x_rhs[i]
        for r in range(s):
            prob += pulp.lpSum(Lam[j] * y_bar[j][r] for j in others) - Sp[r] == t * y_rhs[r]
        _add_rts(prob, Lam, others, t, rts)

    st = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(f"Revised IBP-SBM failed for DMU {p}: {pulp.LpStatus[st]}")

    if t_fixed:
        sm = [max(0.0, pulp.value(Sm[i])) for i in range(m)]
        sp = [max(0.0, pulp.value(Sp[r])) for r in range(s)]
        lam = [0.0 if j == p else pulp.value(Lam[j]) for j in range(n)]
    else:
        t_star = pulp.value(t)
        sm = [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(m)]
        sp = [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(s)]
        lam = [0.0 if j == p else pulp.value(Lam[j]) / t_star for j in range(n)]

    if WI == 0 and WO > 0:
        phi = pulp.value(prob.objective)
        eta_bar = 1.0 / max(phi, 1e-12)
    else:
        num = 1.0 - sum(cx[i] * sm[i] * _safe_inv(x_bar[p][i]) for i in range(m))
        den = 1.0 + sum(cy[r] * sp[r] * _safe_inv(y_bar[p][r]) for r in range(s))
        eta_bar = num / max(den, 1e-12)

    return {"eta_bar": eta_bar, "s_minus": sm, "s_plus": sp, "lambda": lam}


def two_stage(
    inputs,
    outputs,
    x_bar,
    y_bar,
    p: int,
    wx,
    wy,
    WI: float,
    WO: float,
    rts: str = "VRS",
    tol: float = 1e-8,
) -> Dict:
    s1 = ibp_super_sbm(x_bar, y_bar, p, wx, wy, WI=WI, WO=WO, rts=rts)
    s2 = revised_ibp_sbm(
        x_bar, y_bar, p, s1["v_minus"], s1["v_plus"], wx, wy, WI=WI, WO=WO, rts=rts
    )
    gamma, eta_bar = s1["gamma"], s2["eta_bar"]
    # Eq. (14) on rho-scale (tol guards CBC numerical noise around 1)
    ddot = (gamma - 1.0) * eta_bar + 1.0 if gamma > 1.0 + max(tol, 1e-6) else eta_bar

    m, s = len(inputs[0]), len(outputs[0])
    vm, vp = s1["v_minus"], s1["v_plus"]
    sm, sp = s2["s_minus"], s2["s_plus"]
    return {
        "gamma": gamma,
        "eta_bar": eta_bar,
        "ddot_gamma": ddot,
        "v_minus": vm,
        "v_plus": vp,
        "s_minus": sm,
        "s_plus": sp,
        "proj1_x": [inputs[p][i] + vm[i] for i in range(m)],
        "proj1_y": [outputs[p][r] - vp[r] for r in range(s)],
        "proj_x": [inputs[p][i] + vm[i] - sm[i] for i in range(m)],
        "proj_y": [outputs[p][r] - vp[r] + sp[r] for r in range(s)],
    }


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")
    if dmu_col not in fields:
        raise ValueError(f"DMU column '{dmu_col}' not found.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def _clean(v: float, tol: float = 1e-8) -> float:
    return 0.0 if abs(v) < tol else v


def write_results_csv(
    path: Path,
    rows: List[Dict],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    orientation: str,
) -> None:
    header = [
        "DMU",
        "orientation",
        "Weighted_IBP_SBM_eta",
        "IBP_SuperSBM_Gamma",
        "Revised_IBP_eta_bar",
        "Proposed_ddot_Gamma",
        "Rank",
    ]
    for c in in_cols:
        header += [f"v_minus_{c}", f"s_minus_{c}", f"proj1_{c}", f"proj_{c}"]
    for c in out_cols:
        header += [f"v_plus_{c}", f"s_plus_{c}", f"proj1_{c}", f"proj_{c}"]

    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for row in rows:
            line = [
                row["dmu"],
                orientation,
                f"{row['eta']:.8f}",
                f"{row['gamma']:.8f}",
                f"{row['eta_bar']:.8f}",
                f"{row['ddot_gamma']:.8f}",
                row["rank"],
            ]
            for i in range(len(in_cols)):
                line += [
                    f"{_clean(row['v_minus'][i]):.8f}",
                    f"{_clean(row['s_minus'][i]):.8f}",
                    f"{row['proj1_x'][i]:.8f}",
                    f"{row['proj_x'][i]:.8f}",
                ]
            for r in range(len(out_cols)):
                line += [
                    f"{_clean(row['v_plus'][r]):.8f}",
                    f"{_clean(row['s_plus'][r]):.8f}",
                    f"{row['proj1_y'][r]:.8f}",
                    f"{row['proj_y'][r]:.8f}",
                ]
            w.writerow(line)


def main():
    out_dir = Path(__file__).resolve().parent
    data_path = out_dir / "data1.csv"
    weights_path = out_dir / "weights.csv"
    RTS = "VRS"

    if not data_path.exists():
        raise FileNotFoundError(f"Missing {data_path}")
    if not weights_path.exists():
        raise FileNotFoundError(f"Missing {weights_path}")

    names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
    orientation, wx_raw, wy_raw = load_weights(str(weights_path), in_cols, out_cols)
    WI, WO = orientation_flags(orientation)
    wx = normalize_paper_weights(wx_raw, len(in_cols), "wx")
    wy = normalize_paper_weights(wy_raw, len(out_cols), "wy")
    x_bar, y_bar, x_min, y_min = translate(inputs, outputs)

    csv_path = out_dir / f"results_data1_weighted_ibp_c1_{orientation}.csv"

    print("Paramanik et al. (2023) — C.1 Weighted IBP-SBM + two-stage approach")
    print(f"Data:    {data_path}")
    print(f"Weights: {weights_path}")
    print(f"DMUs: {len(names)} | inputs: {in_cols} | outputs: {out_cols}")
    print(f"Base point x_min = {[round(v, 6) for v in x_min]}")
    print(f"Base point y_min = {[round(v, 6) for v in y_min]}")
    print(f"RTS: {RTS} | orientation: {orientation} (WI={WI:g}, WO={WO:g})")
    print(f"w- (paper scale, sum={sum(wx):.4g}) = {dict(zip(in_cols, [round(v, 4) for v in wx]))}")
    print(f"w+ (paper scale, sum={sum(wy):.4g}) = {dict(zip(out_cols, [round(v, 4) for v in wy]))}")
    print()

    results = []
    for p, name in enumerate(names):
        eff = ibp_sbm_c1(x_bar, y_bar, p, wx, wy, WI=WI, WO=WO, rts=RTS)
        res = two_stage(
            inputs, outputs, x_bar, y_bar, p, wx, wy, WI=WI, WO=WO, rts=RTS
        )
        res["dmu"] = name
        res["eta"] = eff["eta"]
        results.append(res)

    order = sorted(range(len(results)), key=lambda i: -results[i]["ddot_gamma"])
    for rk, i in enumerate(order, start=1):
        results[i]["rank"] = rk

    print("=" * 78)
    print(f"C.1 Weighted IBP-SBM + IBP-SuperSBM + Eq.(14)  [{orientation}-oriented, {RTS}]")
    print("=" * 78)
    print(
        f"{'DMU':>5} {'IBP-eta':>10} {'Gamma*':>10} {'eta_bar*':>10} "
        f"{'ddot_G*':>10} {'Rank':>5}"
    )
    print("-" * 78)
    for res in results:
        print(
            f"{res['dmu']:>5} {res['eta']:10.6f} {res['gamma']:10.6f} "
            f"{res['eta_bar']:10.6f} {res['ddot_gamma']:10.6f} {res['rank']:5d}"
        )

    scores = [r["ddot_gamma"] for r in results]
    mean = sum(scores) / len(scores)
    sds = math.sqrt(sum((x - mean) ** 2 for x in scores) / len(scores))
    ned = sum(1 for x in scores if x >= 1.0 - 1e-8)
    ds = max(scores) - min(scores)
    probs = [x / sum(scores) for x in scores]
    entropy = -sum(p * math.log(p) for p in probs if p > 0) / math.log(len(scores))
    print("-" * 78)
    print(f"SDS={sds:.4f}  NED={ned}  DS={ds:.4f}  Entropy={entropy:.4f}")

    print()
    print("=" * 78)
    print("Slacks and projections")
    print("  v-/v+ : IBP-SuperSBM (stage 1)   s-/s+ : Revised IBP-SBM (stage 2)")
    print("  proj  : Pareto projection (x+v--s-, y-v++s+)")
    print("=" * 78)
    for res in results:
        print(f"\nDMU {res['dmu']}  ddot_G*={res['ddot_gamma']:.6f}")
        print(f"  inputs  {list(in_cols)}")
        print(f"    v-    {[round(_clean(v), 4) for v in res['v_minus']]}")
        print(f"    s-    {[round(_clean(v), 4) for v in res['s_minus']]}")
        print(f"    proj  {[round(v, 4) for v in res['proj_x']]}")
        print(f"  outputs {list(out_cols)}")
        print(f"    v+    {[round(_clean(v), 4) for v in res['v_plus']]}")
        print(f"    s+    {[round(_clean(v), 4) for v in res['s_plus']]}")
        print(f"    proj  {[round(v, 4) for v in res['proj_y']]}")

    write_results_csv(csv_path, results, in_cols, out_cols, orientation)
    print()
    print(f"CSV written: {csv_path}")


if __name__ == "__main__":
    main()
