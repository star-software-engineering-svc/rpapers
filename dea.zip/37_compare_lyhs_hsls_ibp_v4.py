"""
Compare three super-efficiency SBM models on the same CSV (v4):

  1. LYHS  — Lin, Yang & Huang (2019)   [36_lin2019_super_sbm_ram.py]
  2. HSLS  — Lee (2021)                 [33_lee2021_nonpositive_sbm_v2.py]
  3. IBP   — Paramanik et al. (2023)    [34_paramanik2023_ibp_sbm_v2.py]

Each model is a class. Shared input: data1.csv (or data.csv).
Runs under four RTS conditions: CRS, VRS, NIRS, NDRS.

Also:
  - leave-one-out sensitivity (Table 4 style) + Fig. 1 charts
  - Fig. D.2 / Fig. D.3: AIRR / AOIR for IBP-SBM vs BP-SBM
    (PT = 0.001 and 0.999). MSBM is omitted.

Scores used in the comparison table:
  LYHS : theta*      Eq. (12)
  HSLS : ddot_sigma  Eq. (12)
  IBP  : ddot_gamma  Eq. (14)
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pulp


# ===========================================================================
# Shared I/O
# ===========================================================================

def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")
    if dmu_col not in fields:
        raise ValueError(f"DMU column '{dmu_col}' not found.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def rank_by_score(scores: Sequence[float]) -> List[int]:
    order = sorted(range(len(scores)), key=lambda i: -scores[i])
    ranks = [0] * len(scores)
    for rk, i in enumerate(order, start=1):
        ranks[i] = rk
    return ranks


def score_metrics(scores: Sequence[float]) -> Dict[str, float]:
    """
    Discrimination / reliability indices used in Paramanik et al. (2023):
      SDS     — standard deviation of scores
      DS      — domain of scores (max - min)
      Entropy — normalized Shannon entropy (lower => more reliable)
    """
    finite = [x for x in scores if x is not None and math.isfinite(x)]
    n = len(finite)
    if n == 0:
        return {"SDS": float("nan"), "DS": float("nan"), "Entropy": float("nan")}
    mean = sum(finite) / n
    sds = math.sqrt(sum((x - mean) ** 2 for x in finite) / n)
    ds = max(finite) - min(finite)
    total = sum(finite)
    if total <= 0:
        entropy = float("nan")
    else:
        probs = [x / total for x in finite]
        entropy = -sum(p * math.log(p) for p in probs if p > 0) / math.log(n)
    return {"SDS": sds, "DS": ds, "Entropy": entropy}


RTS_LIST = ("CRS", "VRS", "NIRS", "NDRS")

def add_rts(prob, Lam, idxs, t, rts: str) -> None:
    """
    Intensity-sum RTS constraint (Charnes / Banker style):
      CRS : no constraint
      VRS : sum == t
      NDRS: sum >= t
      NIRS: sum <= t
    """
    rts = rts.upper()
    total = pulp.lpSum(Lam[j] for j in idxs)
    if rts == "CRS":
        return
    if rts == "VRS":
        prob += total == t
    elif rts == "NDRS":
        prob += total >= t
    elif rts == "NIRS":
        prob += total <= t
    else:
        raise ValueError(f"Unknown RTS: {rts}")


def _fmt_score(v) -> str:
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return "Infeasible"
    return f"{v:12.6f}"


def _fmt_rank(v) -> str:
    if v is None:
        return "  -"
    return f"{v:4d}"


# ===========================================================================
# LYHS — Lin, Yang & Huang (2019)
# ===========================================================================

class LYHSModel:
    """Modified Super-SBM with RAM (Lin et al., 2019). Score = theta* Eq. (12)."""

    name = "LYHS"

    def __init__(
        self,
        inputs: Sequence[Sequence[float]],
        outputs: Sequence[Sequence[float]],
        dmu_names: Optional[Sequence[str]] = None,
        rts: str = "VRS",
        tol: float = 1e-8,
    ):
        self.inputs = [list(row) for row in inputs]
        self.outputs = [list(row) for row in outputs]
        self.n = len(self.inputs)
        self.m = len(self.inputs[0])
        self.s = len(self.outputs[0])
        self.names = (
            list(dmu_names) if dmu_names is not None
            else [str(i + 1) for i in range(self.n)]
        )
        self.rts = rts.upper()
        self.tol = tol
        self.p_in, self.p_out, self.I, self.O = self._compute_ranges()
        self.mu = [1.0 / self.m] * self.m
        self.nu = [1.0 / self.s] * self.s

    def _compute_ranges(self):
        p_in, p_out = [], []
        for i in range(self.m):
            col = [self.inputs[j][i] for j in range(self.n)]
            p_in.append(max(col) - min(col))
        for r in range(self.s):
            col = [self.outputs[j][r] for j in range(self.n)]
            p_out.append(max(col) - min(col))
        I = [i for i in range(self.m) if p_in[i] > 0]
        O = [r for r in range(self.s) if p_out[r] > 0]
        return p_in, p_out, I, O

    def _super_score(self, w_minus, w_plus) -> float:
        numer = 1.0 + sum(
            self.mu[i] * w_minus[i] / self.p_in[i] for i in self.I
        )
        denom = 1.0 - sum(
            self.nu[r] * w_plus[r] / self.p_out[r] for r in self.O
        )
        if denom <= 1e-12:
            raise RuntimeError("LYHS Super-SBM denominator nonpositive.")
        return numer / denom

    def _solve_super_sbm(self, k: int) -> Dict:
        others = [j for j in range(self.n) if j != k]
        prob = pulp.LpProblem(f"LYHS_Super_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Wm = [pulp.LpVariable(f"Wm_{i}", lowBound=0) for i in range(self.m)]
        Wp = [pulp.LpVariable(f"Wp_{r}", lowBound=0) for r in range(self.s)]

        prob += t + pulp.lpSum(
            self.mu[i] * Wm[i] / self.p_in[i] for i in self.I
        )
        prob += t - pulp.lpSum(
            self.nu[r] * Wp[r] / self.p_out[r] for r in self.O
        ) == 1

        for i in range(self.m):
            if i in self.I:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others) - Wm[i]
                    <= t * self.inputs[k][i]
                )
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others)
                    == t * self.inputs[k][i]
                )
                prob += Wm[i] == 0

        for r in range(self.s):
            if r in self.O:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others) + Wp[r]
                    >= t * self.outputs[k][r]
                )
                prob += Wp[r] <= t * self.p_out[r]
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others)
                    == t * self.outputs[k][r]
                )
                prob += Wp[r] == 0

        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"LYHS Super-SBM failed for DMU {k}: {pulp.LpStatus[st]}"
            )

        t_star = pulp.value(t)
        lam = [0.0] * self.n
        for j in others:
            lam[j] = pulp.value(Lam[j]) / t_star

        w_minus = [0.0] * self.m
        for i in self.I:
            ref = sum(lam[j] * self.inputs[j][i] for j in others)
            w_minus[i] = max(0.0, ref - self.inputs[k][i])
        w_plus = [0.0] * self.s
        for r in self.O:
            ref = sum(lam[j] * self.outputs[j][r] for j in others)
            w_plus[r] = min(max(0.0, self.outputs[k][r] - ref), self.p_out[r])

        return {
            "sigma": self._super_score(w_minus, w_plus),
            "w_minus": w_minus,
            "w_plus": w_plus,
        }

    def _solve_modified_sbm(self, k: int, w_minus, w_plus) -> Dict:
        others = [j for j in range(self.n) if j != k]
        prob = pulp.LpProblem(f"LYHS_SBM_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(self.m)]
        Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(self.s)]

        prob += t - pulp.lpSum(
            self.mu[i] * Sm[i] / self.p_in[i] for i in self.I
        )
        prob += t + pulp.lpSum(
            self.nu[r] * Sp[r] / self.p_out[r] for r in self.O
        ) == 1

        for i in range(self.m):
            if i in self.I:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others) + Sm[i]
                    == t * (self.inputs[k][i] + w_minus[i])
                )
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others)
                    == t * self.inputs[k][i]
                )
                prob += Sm[i] == 0

        for r in range(self.s):
            if r in self.O:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others) - Sp[r]
                    == t * (self.outputs[k][r] - w_plus[r])
                )
            else:
                prob += (
                    pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others)
                    == t * self.outputs[k][r]
                )
                prob += Sp[r] == 0

        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"LYHS Modified SBM failed for DMU {k}: {pulp.LpStatus[st]}"
            )
        t_star = pulp.value(t)
        return {
            "rho": pulp.value(prob.objective),
            "s_minus": [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(self.m)],
            "s_plus": [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(self.s)],
        }

    def evaluate_dmu(self, k: int) -> Dict:
        s1 = self._solve_super_sbm(k)
        s2 = self._solve_modified_sbm(k, s1["w_minus"], s1["w_plus"])
        sigma, rho = s1["sigma"], s2["rho"]
        theta = sigma if sigma > 1.0 + self.tol else rho
        return {
            "dmu": self.names[k],
            "sigma": sigma,
            "rho": rho,
            "score": theta,
            "s_minus": s2["s_minus"],
            "s_plus": s2["s_plus"],
            "feasible": True,
        }

    def evaluate_all(self) -> List[Dict]:
        results = []
        for k in range(self.n):
            try:
                results.append(self.evaluate_dmu(k))
            except Exception:
                results.append({
                    "dmu": self.names[k],
                    "sigma": None,
                    "rho": None,
                    "score": None,
                    "s_minus": None,
                    "s_plus": None,
                    "feasible": False,
                })
        ranks = rank_by_score([
            r["score"] if r["score"] is not None else float("-inf")
            for r in results
        ])
        for r, rk in zip(results, ranks):
            r["rank"] = rk if r["feasible"] else None
        return results


# ===========================================================================
# HSLS — Lee (2021)
# ===========================================================================

class HSLSModel:
    """Nonpositive Super-SBM two-stage (Lee, 2021). Score = ddot_sigma Eq. (12)."""

    name = "HSLS"

    def __init__(
        self,
        inputs: Sequence[Sequence[float]],
        outputs: Sequence[Sequence[float]],
        dmu_names: Optional[Sequence[str]] = None,
        rts: str = "VRS",
        tol: float = 1e-8,
    ):
        self.inputs = [list(row) for row in inputs]
        self.outputs = [list(row) for row in outputs]
        self.n = len(self.inputs)
        self.m = len(self.inputs[0])
        self.s = len(self.outputs[0])
        self.names = (
            list(dmu_names) if dmu_names is not None
            else [str(i + 1) for i in range(self.n)]
        )
        self.rts = rts.upper()
        self.tol = tol
        self.sets = self._classify_io()

    def _classify_io(self) -> Dict[str, List[int]]:
        I_plus = [
            i for i in range(self.m)
            if all(self.inputs[j][i] > 0 for j in range(self.n))
        ]
        I_minus = [
            i for i in range(self.m)
            if all(self.inputs[j][i] < 0 for j in range(self.n))
        ]
        R_minus = [
            r for r in range(self.s)
            if all(self.outputs[j][r] < 0 for j in range(self.n))
        ]
        R_plus = [
            r for r in range(self.s)
            if all(self.outputs[j][r] > 0 for j in range(self.n))
        ]
        I = list(range(self.m))
        R = list(range(self.s))
        return {
            "I": I,
            "R": R,
            "I+": I_plus,
            "I-": I_minus,
            "I''": [i for i in I if i not in I_plus],
            "I'": [i for i in I if i not in I_minus],
            "R-": R_minus,
            "R+": R_plus,
            "R''": [r for r in R if r not in R_minus],
            "R'": [r for r in R if r not in R_plus],
        }

    @staticmethod
    def _zero_proxy(values: Sequence[float], k: int) -> float:
        if values[k] != 0:
            return abs(values[k])
        nonzero = [abs(v) for v in values if v != 0]
        if not nonzero:
            raise ValueError("All values are zero; cannot form proxy denominator.")
        return min(nonzero)

    def _proxies(self, k: int) -> Tuple[List[float], List[float]]:
        x_proxy = [
            self._zero_proxy([self.inputs[j][i] for j in range(self.n)], k)
            for i in range(self.m)
        ]
        y_proxy = [
            self._zero_proxy([self.outputs[j][r] for j in range(self.n)], k)
            for r in range(self.s)
        ]
        return x_proxy, y_proxy

    def _super_sbm_score(self, w_plus, w_minus, x_proxy, y_proxy) -> float:
        sets = self.sets
        n_e = len(sets["I'"]) + len(sets["R'"])
        n_c = len(sets["I-"]) + len(sets["R+"])
        numer = 1.0
        if n_e > 0:
            for i in sets["I'"]:
                numer += w_plus[i] / (n_e * x_proxy[i])
            for r in sets["R'"]:
                numer += w_minus[r] / (n_e * y_proxy[r])
        denom = 1.0
        if n_c > 0:
            for i in sets["I-"]:
                denom -= w_plus[i] / (n_c * x_proxy[i])
            for r in sets["R+"]:
                denom -= w_minus[r] / (n_c * y_proxy[r])
        if denom <= 1e-12:
            raise RuntimeError("HSLS Super-SBM denominator is nonpositive.")
        return numer / denom

    def _solve_super_sbm(self, k: int) -> Dict:
        sets = self.sets
        x_proxy, y_proxy = self._proxies(k)
        n_e = len(sets["I'"]) + len(sets["R'"])
        n_c = len(sets["I-"]) + len(sets["R+"])
        others = [j for j in range(self.n) if j != k]

        prob = pulp.LpProblem(f"HSLS_Super_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=0)
        Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
        Wp = [pulp.LpVariable(f"Wp_{i}", lowBound=0) for i in range(self.m)]
        Wm = [pulp.LpVariable(f"Wm_{r}", lowBound=0) for r in range(self.s)]

        obj = t
        if n_e > 0:
            for i in sets["I'"]:
                obj += Wp[i] / (n_e * x_proxy[i])
            for r in sets["R'"]:
                obj += Wm[r] / (n_e * y_proxy[r])
        prob += obj

        norm = t
        if n_c > 0:
            for i in sets["I-"]:
                norm -= Wp[i] / (n_c * x_proxy[i])
            for r in sets["R+"]:
                norm -= Wm[r] / (n_c * y_proxy[r])
        prob += norm == 1

        for i in range(self.m):
            prob += (
                t * self.inputs[k][i]
                >= pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others) - Wp[i]
            )
        for r in range(self.s):
            prob += (
                t * self.outputs[k][r]
                <= pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others) + Wm[r]
            )
        add_rts(prob, Lam, others, t, self.rts)

        for r in sets["R+"]:
            prob += t * y_proxy[r] >= Wm[r]
        for i in sets["I-"]:
            prob += t * x_proxy[i] >= Wp[i]

        status = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[status] != "Optimal":
            raise RuntimeError(
                f"HSLS Super-SBM failed for DMU {k}: {pulp.LpStatus[status]}"
            )

        t_star = pulp.value(t)
        if t_star is None or t_star <= 1e-12:
            raise RuntimeError(f"Invalid t* for HSLS Super-SBM DMU {k}")

        lam = [0.0] * self.n
        for j in others:
            lam[j] = pulp.value(Lam[j]) / t_star

        w_plus = [
            max(0.0, sum(lam[j] * self.inputs[j][i] for j in range(self.n))
                - self.inputs[k][i])
            for i in range(self.m)
        ]
        w_minus = [
            max(0.0, self.outputs[k][r]
                - sum(lam[j] * self.outputs[j][r] for j in range(self.n)))
            for r in range(self.s)
        ]
        return {
            "sigma": self._super_sbm_score(w_plus, w_minus, x_proxy, y_proxy),
            "w_plus": w_plus,
            "w_minus": w_minus,
        }

    def _solve_modified_sbm(self, k: int, w_plus, w_minus) -> Dict:
        sets = self.sets
        x_proxy, y_proxy = self._proxies(k)
        n_c = len(sets["I+"]) + len(sets["R-"])
        n_e = len(sets["I''"]) + len(sets["R''"])
        others = [j for j in range(self.n) if j != k]

        prob = pulp.LpProblem(f"HSLS_Mod_{k}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=0)
        Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
        Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(self.m)]
        Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(self.s)]

        obj = t
        if n_c > 0:
            for i in sets["I+"]:
                obj -= Sm[i] / (n_c * x_proxy[i])
            for r in sets["R-"]:
                obj -= Sp[r] / (n_c * y_proxy[r])
        prob += obj

        norm = t
        if n_e > 0:
            for i in sets["I''"]:
                norm += Sm[i] / (n_e * x_proxy[i])
            for r in sets["R''"]:
                norm += Sp[r] / (n_e * y_proxy[r])
        prob += norm == 1

        for i in range(self.m):
            prob += (
                t * self.inputs[k][i] - Sm[i] + t * w_plus[i]
                == pulp.lpSum(Lam[j] * self.inputs[j][i] for j in others)
            )
        for r in range(self.s):
            prob += (
                t * self.outputs[k][r] + Sp[r] - t * w_minus[r]
                == pulp.lpSum(Lam[j] * self.outputs[j][r] for j in others)
            )
        add_rts(prob, Lam, others, t, self.rts)

        status = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[status] != "Optimal":
            raise RuntimeError(
                f"HSLS Modified SBM failed for DMU {k}: {pulp.LpStatus[status]}"
            )
        t_star = pulp.value(t)
        if t_star is None or t_star <= 1e-12:
            raise RuntimeError(f"Invalid t* for HSLS Modified SBM DMU {k}")
        return {
            "gamma": pulp.value(prob.objective),
            "s_minus": [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(self.m)],
            "s_plus": [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(self.s)],
        }

    def evaluate_dmu(self, k: int) -> Dict:
        s1 = self._solve_super_sbm(k)
        s2 = self._solve_modified_sbm(k, s1["w_plus"], s1["w_minus"])
        sigma, gamma = s1["sigma"], s2["gamma"]
        if sigma > 1 + self.tol:
            ddot = (sigma - 1.0) * gamma + 1.0
        else:
            ddot = gamma
        return {
            "dmu": self.names[k],
            "sigma": sigma,
            "gamma": gamma,
            "score": ddot,
            "s_minus": s2["s_minus"],
            "s_plus": s2["s_plus"],
            "feasible": True,
        }

    def evaluate_all(self) -> List[Dict]:
        results = []
        for k in range(self.n):
            try:
                results.append(self.evaluate_dmu(k))
            except Exception:
                results.append({
                    "dmu": self.names[k],
                    "sigma": None,
                    "gamma": None,
                    "score": None,
                    "s_minus": None,
                    "s_plus": None,
                    "feasible": False,
                })
        ranks = rank_by_score([
            r["score"] if r["score"] is not None else float("-inf")
            for r in results
        ])
        for r, rk in zip(results, ranks):
            r["rank"] = rk if r["feasible"] else None
        return results


# ===========================================================================
# IBP — Paramanik et al. (2023)
# ===========================================================================

class IBPModel:
    """Two-stage IBP-SuperSBM (Paramanik et al., 2023). Score = ddot_gamma Eq. (14)."""

    name = "IBP"

    def __init__(
        self,
        inputs: Sequence[Sequence[float]],
        outputs: Sequence[Sequence[float]],
        dmu_names: Optional[Sequence[str]] = None,
        rts: str = "VRS",
        tol: float = 1e-8,
    ):
        self.inputs = [list(row) for row in inputs]
        self.outputs = [list(row) for row in outputs]
        self.n = len(self.inputs)
        self.m = len(self.inputs[0])
        self.s = len(self.outputs[0])
        self.names = (
            list(dmu_names) if dmu_names is not None
            else [str(i + 1) for i in range(self.n)]
        )
        self.rts = rts.upper()
        self.tol = tol
        self.x_bar, self.y_bar, self.x_min, self.y_min = self._translate()

    @staticmethod
    def _second_smallest_nonzero(values: Sequence[float]) -> float:
        delta = min(values)
        nonzero = sorted({v for v in values if v != 0.0})
        if not nonzero:
            raise ValueError("No nonzero values for base point.")
        if delta == 0.0:
            return nonzero[0]
        if len(nonzero) < 2:
            raise ValueError("Need two distinct nonzero values for base point.")
        return nonzero[1]

    def _translate(self):
        x_min, y_min = [], []
        for i in range(self.m):
            col = [self.inputs[j][i] for j in range(self.n)]
            x_min.append(2.0 * min(col) - self._second_smallest_nonzero(col))
        for r in range(self.s):
            col = [self.outputs[j][r] for j in range(self.n)]
            y_min.append(2.0 * min(col) - self._second_smallest_nonzero(col))

        x_bar = [
            [self.inputs[j][i] - x_min[i] for i in range(self.m)]
            for j in range(self.n)
        ]
        y_bar = [
            [self.outputs[j][r] - y_min[r] for r in range(self.s)]
            for j in range(self.n)
        ]
        for j in range(self.n):
            if any(v <= 0 for v in x_bar[j]) or any(v <= 0 for v in y_bar[j]):
                raise ValueError(f"Nonpositive translated data at DMU index {j}")
        return x_bar, y_bar, x_min, y_min

    @staticmethod
    def _super_score(v_minus, v_plus, x_p, y_p) -> float:
        m, s = len(x_p), len(y_p)
        numer = 1.0 + (1.0 / m) * sum(v_minus[i] / x_p[i] for i in range(m))
        denom = 1.0 - (1.0 / s) * sum(v_plus[r] / y_p[r] for r in range(s))
        if denom <= 1e-12:
            raise RuntimeError("IBP-SuperSBM denominator nonpositive.")
        return numer / denom

    def _ibp_super_sbm(self, p: int) -> Dict:
        others = [j for j in range(self.n) if j != p]
        prob = pulp.LpProblem(f"IBP_Super_{p}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Vm = [pulp.LpVariable(f"Vm_{i}", lowBound=0) for i in range(self.m)]
        Vp = [pulp.LpVariable(f"Vp_{r}", lowBound=0) for r in range(self.s)]

        prob += t + (1.0 / self.m) * pulp.lpSum(
            Vm[i] / self.x_bar[p][i] for i in range(self.m)
        )
        prob += t - (1.0 / self.s) * pulp.lpSum(
            Vp[r] / self.y_bar[p][r] for r in range(self.s)
        ) == 1
        for i in range(self.m):
            prob += (
                pulp.lpSum(Lam[j] * self.x_bar[j][i] for j in others) - Vm[i]
                <= t * self.x_bar[p][i]
            )
        for r in range(self.s):
            prob += (
                pulp.lpSum(Lam[j] * self.y_bar[j][r] for j in others) + Vp[r]
                >= t * self.y_bar[p][r]
            )
            prob += Vp[r] <= t * self.y_bar[p][r]
        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"IBP-SuperSBM failed for DMU {p}: {pulp.LpStatus[st]}"
            )

        t_star = pulp.value(t)
        lam = [0.0] * self.n
        for j in others:
            lam[j] = pulp.value(Lam[j]) / t_star

        v_minus = [
            max(0.0, sum(lam[j] * self.x_bar[j][i] for j in others) - self.x_bar[p][i])
            for i in range(self.m)
        ]
        v_plus = []
        for r in range(self.s):
            vp = max(
                0.0,
                self.y_bar[p][r] - sum(lam[j] * self.y_bar[j][r] for j in others),
            )
            v_plus.append(min(vp, self.y_bar[p][r]))

        return {
            "gamma": self._super_score(
                v_minus, v_plus, self.x_bar[p], self.y_bar[p]
            ),
            "v_minus": v_minus,
            "v_plus": v_plus,
        }

    def _revised_ibp_sbm(self, p: int, v_minus, v_plus) -> Dict:
        others = [j for j in range(self.n) if j != p]
        prob = pulp.LpProblem(f"IBP_Rev_{p}", pulp.LpMinimize)
        t = pulp.LpVariable("t", lowBound=1e-12)
        Lam = {j: pulp.LpVariable(f"L_{j}", lowBound=0) for j in others}
        Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(self.m)]
        Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(self.s)]

        prob += t - (1.0 / self.m) * pulp.lpSum(
            Sm[i] / self.x_bar[p][i] for i in range(self.m)
        )
        prob += t + (1.0 / self.s) * pulp.lpSum(
            Sp[r] / self.y_bar[p][r] for r in range(self.s)
        ) == 1
        for i in range(self.m):
            prob += (
                pulp.lpSum(Lam[j] * self.x_bar[j][i] for j in others) + Sm[i]
                == t * (self.x_bar[p][i] + v_minus[i])
            )
        for r in range(self.s):
            prob += (
                pulp.lpSum(Lam[j] * self.y_bar[j][r] for j in others) - Sp[r]
                == t * (self.y_bar[p][r] - v_plus[r])
            )
        add_rts(prob, Lam, others, t, self.rts)

        st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
        if pulp.LpStatus[st] != "Optimal":
            raise RuntimeError(
                f"Revised IBP-SBM failed for DMU {p}: {pulp.LpStatus[st]}"
            )
        t_star = pulp.value(t)
        return {
            "eta_bar": pulp.value(prob.objective),
            "s_minus": [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(self.m)],
            "s_plus": [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(self.s)],
        }

    def evaluate_dmu(self, p: int) -> Dict:
        s1 = self._ibp_super_sbm(p)
        s2 = self._revised_ibp_sbm(p, s1["v_minus"], s1["v_plus"])
        gamma, eta_bar = s1["gamma"], s2["eta_bar"]
        if gamma > 1.0 + self.tol:
            ddot = (gamma - 1.0) * eta_bar + 1.0
        else:
            ddot = eta_bar
        return {
            "dmu": self.names[p],
            "gamma": gamma,
            "eta_bar": eta_bar,
            "score": ddot,
            "s_minus": s2["s_minus"],
            "s_plus": s2["s_plus"],
            "feasible": True,
        }

    def evaluate_all(self) -> List[Dict]:
        results = []
        for k in range(self.n):
            try:
                results.append(self.evaluate_dmu(k))
            except Exception:
                results.append({
                    "dmu": self.names[k],
                    "gamma": None,
                    "eta_bar": None,
                    "score": None,
                    "s_minus": None,
                    "s_plus": None,
                    "feasible": False,
                })
        ranks = rank_by_score([
            r["score"] if r["score"] is not None else float("-inf")
            for r in results
        ])
        for r, rk in zip(results, ranks):
            r["rank"] = rk if r["feasible"] else None
        return results


# ===========================================================================
# Comparison
# ===========================================================================

def compare_models_one_rts(
    names: Sequence[str],
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    rts: str,
) -> Tuple[List[Dict], Dict[str, Dict[str, float]], Dict[str, List[Dict]]]:
    lyhs = LYHSModel(inputs, outputs, dmu_names=names, rts=rts).evaluate_all()
    hsls = HSLSModel(inputs, outputs, dmu_names=names, rts=rts).evaluate_all()
    ibp = IBPModel(inputs, outputs, dmu_names=names, rts=rts).evaluate_all()

    rows = []
    for i, name in enumerate(names):
        rows.append({
            "DMU": name,
            "RTS": rts,
            "LYHS_score": lyhs[i]["score"],
            "LYHS_rank": lyhs[i]["rank"],
            "HSLS_score": hsls[i]["score"],
            "HSLS_rank": hsls[i]["rank"],
            "IBP_score": ibp[i]["score"],
            "IBP_rank": ibp[i]["rank"],
        })

    metrics = {
        "LYHS": score_metrics([r["LYHS_score"] for r in rows]),
        "HSLS": score_metrics([r["HSLS_score"] for r in rows]),
        "IBP": score_metrics([r["IBP_score"] for r in rows]),
    }
    model_results = {"LYHS": lyhs, "HSLS": hsls, "IBP": ibp}
    return rows, metrics, model_results


# ===========================================================================
# Fig. D.2 / D.3 — IBP-SBM vs BP-SBM AIRR / AOIR (MSBM skipped)
# ===========================================================================

FIG_D_MODELS = ("IBP-SBM", "BP-SBM (PT=0.001)", "BP-SBM (PT=0.999)")


def translate_bp(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    pt: float,
) -> Tuple[List[List[float]], List[List[float]], List[float], List[float]]:
    """
    Tone et al. (2020) theoretical base point — Eq. (4).
    Paper uses PT = tau = gamma (= sigma = mu when needed).
      xmin_i = 0                 if delta_i > 0
               -pt               if delta_i == 0
               delta_i*(1+pt)    if delta_i < 0
      ymin_r analogous with omega_r.
    """
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])
    if pt <= 0:
        raise ValueError("Perturbation term PT must be positive.")
    x_min, y_min = [], []
    for i in range(m):
        delta = min(inputs[j][i] for j in range(n))
        if delta > 0:
            x_min.append(0.0)
        elif delta == 0:
            x_min.append(-pt)
        else:
            x_min.append(delta * (1.0 + pt))
    for r in range(s):
        omega = min(outputs[j][r] for j in range(n))
        if omega > 0:
            y_min.append(0.0)
        elif omega == 0:
            y_min.append(-pt)
        else:
            y_min.append(omega * (1.0 + pt))

    x_bar = [[inputs[j][i] - x_min[i] for i in range(m)] for j in range(n)]
    y_bar = [[outputs[j][r] - y_min[r] for r in range(s)] for j in range(n)]
    for j in range(n):
        if any(v <= 1e-15 for v in x_bar[j]) or any(v <= 1e-15 for v in y_bar[j]):
            raise ValueError(
                f"Nonpositive BP-translated data at DMU {j} with PT={pt}"
            )
    return x_bar, y_bar, x_min, y_min


def translate_ibp(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Tuple[List[List[float]], List[List[float]], List[float], List[float]]:
    """Paramanik et al. (2023) IBP base point — Eq. (8)."""
    n, m, s = len(inputs), len(inputs[0]), len(outputs[0])

    def second_smallest_nonzero(values: Sequence[float]) -> float:
        delta = min(values)
        nonzero = sorted({v for v in values if v != 0.0})
        if not nonzero:
            raise ValueError("No nonzero values for base point.")
        if delta == 0.0:
            return nonzero[0]
        if len(nonzero) < 2:
            raise ValueError("Need two distinct nonzero values for base point.")
        return nonzero[1]

    x_min, y_min = [], []
    for i in range(m):
        col = [inputs[j][i] for j in range(n)]
        x_min.append(2.0 * min(col) - second_smallest_nonzero(col))
    for r in range(s):
        col = [outputs[j][r] for j in range(n)]
        y_min.append(2.0 * min(col) - second_smallest_nonzero(col))

    x_bar = [[inputs[j][i] - x_min[i] for i in range(m)] for j in range(n)]
    y_bar = [[outputs[j][r] - y_min[r] for r in range(s)] for j in range(n)]
    for j in range(n):
        if any(v <= 0 for v in x_bar[j]) or any(v <= 0 for v in y_bar[j]):
            raise ValueError(f"Nonpositive IBP-translated data at DMU {j}")
    return x_bar, y_bar, x_min, y_min


def solve_sbm_on_translated(
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
    p: int,
    rts: str = "VRS",
) -> Dict:
    """
    Standard SBM on translated positive data (BP-SBM Eq. 5 / IBP-SBM Eq. 9 LP).
    Returns efficiency and stage-1 improvement slacks s-, s+.
    """
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    prob = pulp.LpProblem(f"SBM_trans_{p}_{rts}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=1e-12)
    Lam = [pulp.LpVariable(f"L_{j}", lowBound=0) for j in range(n)]
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    prob += t - (1.0 / m) * pulp.lpSum(Sm[i] / x_bar[p][i] for i in range(m))
    prob += t + (1.0 / s) * pulp.lpSum(Sp[r] / y_bar[p][r] for r in range(s)) == 1
    for i in range(m):
        prob += (
            pulp.lpSum(Lam[j] * x_bar[j][i] for j in range(n)) + Sm[i]
            == t * x_bar[p][i]
        )
    for r in range(s):
        prob += (
            pulp.lpSum(Lam[j] * y_bar[j][r] for j in range(n)) - Sp[r]
            == t * y_bar[p][r]
        )
    add_rts(prob, Lam, range(n), t, rts)

    st = prob.solve(pulp.PULP_CBC_CMD(msg=False))
    if pulp.LpStatus[st] != "Optimal":
        raise RuntimeError(
            f"Translated SBM failed for DMU {p} under {rts}: {pulp.LpStatus[st]}"
        )
    t_star = pulp.value(t)
    return {
        "eta": pulp.value(prob.objective),
        "s_minus": [max(0.0, pulp.value(Sm[i]) / t_star) for i in range(m)],
        "s_plus": [max(0.0, pulp.value(Sp[r]) / t_star) for r in range(s)],
    }


def evaluate_efficiency_all(
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
    rts: str,
) -> List[Dict]:
    return [solve_sbm_on_translated(x_bar, y_bar, p, rts=rts) for p in range(len(x_bar))]


def compute_airr_aoir(
    results: Sequence[Dict],
    x_bar: Sequence[Sequence[float]],
    y_bar: Sequence[Sequence[float]],
) -> Tuple[List[float], List[float]]:
    """
    AIRR / AOIR (%) (Tone et al., 2020; Paramanik et al., 2023):
      AIRR_i = 100 * sum_j s_ij^- / sum_j xbar_ij
      AOIR_r = 100 * sum_j s_rj^+ / sum_j ybar_rj
    Slacks and denominators are in the translated positive space used by
    IBP-SBM / BP-SBM (so rates match Fig. D.2 / D.3).
    """
    n, m, s = len(x_bar), len(x_bar[0]), len(y_bar[0])
    airr = []
    for i in range(m):
        numer = sum(max(0.0, res["s_minus"][i]) for res in results)
        denom = sum(x_bar[j][i] for j in range(n))
        airr.append(100.0 * numer / denom if denom > 1e-12 else float("nan"))
    aoir = []
    for r in range(s):
        numer = sum(max(0.0, res["s_plus"][r]) for res in results)
        denom = sum(y_bar[j][r] for j in range(n))
        aoir.append(100.0 * numer / denom if denom > 1e-12 else float("nan"))
    return airr, aoir


def run_airr_aoir_ibp_bp(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    rts_list: Sequence[str] = RTS_LIST,
) -> Tuple[
    Dict[str, Dict[str, List[float]]],
    Dict[str, Dict[str, List[float]]],
]:
    """
    Compute AIRR/AOIR for Fig. D.2 / D.3 models:
      IBP-SBM, BP-SBM (PT=0.001), BP-SBM (PT=0.999).  (MSBM skipped)
    """
    x_ibp, y_ibp, _, _ = translate_ibp(inputs, outputs)
    x_bp001, y_bp001, _, _ = translate_bp(inputs, outputs, pt=0.001)
    x_bp999, y_bp999, _, _ = translate_bp(inputs, outputs, pt=0.999)

    datasets = {
        "IBP-SBM": (x_ibp, y_ibp),
        "BP-SBM (PT=0.001)": (x_bp001, y_bp001),
        "BP-SBM (PT=0.999)": (x_bp999, y_bp999),
    }

    airr_by_rts: Dict[str, Dict[str, List[float]]] = {}
    aoir_by_rts: Dict[str, Dict[str, List[float]]] = {}
    for rts in rts_list:
        airr_by_rts[rts] = {}
        aoir_by_rts[rts] = {}
        for name, (xb, yb) in datasets.items():
            res = evaluate_efficiency_all(xb, yb, rts)
            airr, aoir = compute_airr_aoir(res, xb, yb)
            airr_by_rts[rts][name] = airr
            aoir_by_rts[rts][name] = aoir
    return airr_by_rts, aoir_by_rts


def plot_fig_d2_airr(
    airr_by_rts: Dict[str, Dict[str, List[float]]],
    in_cols: Sequence[str],
    rts_list: Sequence[str],
    out_path: Path,
    models: Sequence[str] = FIG_D_MODELS,
) -> Path:
    """Fig. D.2: AIRR (%) — IBP-SBM vs BP-SBM under different RTS."""
    import matplotlib.pyplot as plt
    import numpy as np

    colors = {
        "IBP-SBM": "#54A24B",
        "BP-SBM (PT=0.001)": "#4C78A8",
        "BP-SBM (PT=0.999)": "#F58518",
    }
    labels = []
    xpos = []
    gap = 1.0
    pos = 0.0
    for rts in rts_list:
        for c in in_cols:
            labels.append(f"{rts}\n{c}")
            xpos.append(pos)
            pos += 1.0
        pos += gap

    x = np.array(xpos)
    n_m = len(models)
    width = 0.8 / n_m
    fig, ax = plt.subplots(figsize=(max(9, len(labels) * 0.75), 5.5))
    for i, model in enumerate(models):
        vals = []
        for rts in rts_list:
            vals.extend(airr_by_rts[rts][model])
        ax.bar(
            x + (i - (n_m - 1) / 2) * width,
            vals,
            width,
            label=model,
            color=colors.get(model, f"C{i}"),
            edgecolor="white",
            linewidth=0.4,
        )

    ax.set_ylabel("AIRR (%)")
    ax.set_title(
        "Fig. D.2: AIRR (%) — IBP-SBM vs BP-SBM under different RTS"
    )
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.legend(frameon=False, fontsize=8)
    ax.set_ylim(bottom=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    out_path = Path(out_path)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_path


def plot_fig_d3_aoir(
    aoir_by_rts: Dict[str, Dict[str, List[float]]],
    out_cols: Sequence[str],
    rts_list: Sequence[str],
    out_path: Path,
    models: Sequence[str] = FIG_D_MODELS,
) -> Path:
    """Fig. D.3: AOIR (%) — IBP-SBM vs BP-SBM under different RTS."""
    import matplotlib.pyplot as plt
    import numpy as np

    colors = {
        "IBP-SBM": "#54A24B",
        "BP-SBM (PT=0.001)": "#4C78A8",
        "BP-SBM (PT=0.999)": "#F58518",
    }
    labels = []
    xpos = []
    gap = 1.0
    pos = 0.0
    for rts in rts_list:
        for c in out_cols:
            labels.append(f"{rts}\n{c}")
            xpos.append(pos)
            pos += 1.0
        pos += gap

    x = np.array(xpos)
    n_m = len(models)
    width = 0.8 / n_m
    fig, ax = plt.subplots(figsize=(max(9, len(labels) * 0.55), 5.5))
    for i, model in enumerate(models):
        vals = []
        for rts in rts_list:
            vals.extend(aoir_by_rts[rts][model])
        ax.bar(
            x + (i - (n_m - 1) / 2) * width,
            vals,
            width,
            label=model,
            color=colors.get(model, f"C{i}"),
            edgecolor="white",
            linewidth=0.4,
        )

    ax.set_ylabel("AOIR (%)")
    ax.set_title(
        "Fig. D.3: AOIR (%) — IBP-SBM vs BP-SBM under different RTS"
    )
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.legend(frameon=False, fontsize=8)
    ax.set_ylim(bottom=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    out_path = Path(out_path)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_path


def write_airr_aoir_csv(
    path: Path,
    airr_by_rts: Dict[str, Dict[str, List[float]]],
    aoir_by_rts: Dict[str, Dict[str, List[float]]],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    rts_list: Sequence[str],
    models: Sequence[str] = FIG_D_MODELS,
) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Type", "RTS", "Variable", *models])
        for rts in rts_list:
            for i, col in enumerate(in_cols):
                w.writerow([
                    "AIRR",
                    rts,
                    col,
                    *[f"{airr_by_rts[rts][m][i]:.6f}" for m in models],
                ])
        for rts in rts_list:
            for r, col in enumerate(out_cols):
                w.writerow([
                    "AOIR",
                    rts,
                    col,
                    *[f"{aoir_by_rts[rts][m][r]:.6f}" for m in models],
                ])


def _print_airr_aoir_tables(
    airr_by_rts: Dict[str, Dict[str, List[float]]],
    aoir_by_rts: Dict[str, Dict[str, List[float]]],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    rts_list: Sequence[str],
    models: Sequence[str] = FIG_D_MODELS,
) -> None:
    print("=" * 88)
    print("Fig. D.2 / D.3 — AIRR / AOIR: IBP-SBM vs BP-SBM (MSBM skipped)")
    print("=" * 88)
    for rts in rts_list:
        print(f"\n[{rts}] AIRR (%)")
        print(f"  {'Var':<8}" + "".join(f"{m:>22}" for m in models))
        for i, col in enumerate(in_cols):
            print(
                f"  {col:<8}"
                + "".join(f"{airr_by_rts[rts][m][i]:22.4f}" for m in models)
            )
        print(f"[{rts}] AOIR (%)")
        print(f"  {'Var':<8}" + "".join(f"{m:>22}" for m in models))
        for r, col in enumerate(out_cols):
            print(
                f"  {col:<8}"
                + "".join(f"{aoir_by_rts[rts][m][r]:22.4f}" for m in models)
            )


def _print_score_table(rows: List[Dict], rts: str) -> None:
    print("=" * 96)
    print(f"Comparison under {rts}: LYHS | HSLS | IBP")
    print("=" * 96)
    print(
        f"{'DMU':>6} "
        f"{'LYHS':>14} {'Rk':>4} "
        f"{'HSLS':>14} {'Rk':>4} "
        f"{'IBP':>14} {'Rk':>4}"
    )
    print("-" * 96)
    for row in rows:
        print(
            f"{row['DMU']:>6} "
            f"{_fmt_score(row['LYHS_score']):>14} {_fmt_rank(row['LYHS_rank'])} "
            f"{_fmt_score(row['HSLS_score']):>14} {_fmt_rank(row['HSLS_rank'])} "
            f"{_fmt_score(row['IBP_score']):>14} {_fmt_rank(row['IBP_rank'])}"
        )
    print("-" * 96)


def _print_metrics(metrics: Dict[str, Dict[str, float]], rts: str) -> None:
    print(f"SDS / DS / Entropy under {rts}")
    print(f"{'Measure':<10} {'LYHS':>12} {'HSLS':>12} {'IBP':>12}")
    print("-" * 56)
    for key in ("SDS", "DS", "Entropy"):
        print(
            f"{key:<10} "
            f"{metrics['LYHS'][key]:12.6f} "
            f"{metrics['HSLS'][key]:12.6f} "
            f"{metrics['IBP'][key]:12.6f}"
        )
    print("-" * 56)


# ===========================================================================
# Sensitivity analysis (Table 4 style — leave-one-out DMU deletion)
# ===========================================================================

MODEL_CLASSES = {
    "LYHS": LYHSModel,
    "HSLS": HSLSModel,
    "IBP": IBPModel,
}


def _score_cell(v) -> str:
    if v is None:
        return "N/A"
    if isinstance(v, float) and not math.isfinite(v):
        return "Infeasible"
    return f"{v:.4f}"


def sensitivity_one_model(
    model_name: str,
    names: Sequence[str],
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    rts: str,
    original_scores: Sequence[Optional[float]],
) -> List[Dict]:
    """
    Build Table-4-style sensitivity rows for one model under one RTS.
    Row 0: Original. Rows 1..n: delete DMU i (that column = N/A).
    """
    Model = MODEL_CLASSES[model_name]
    n = len(names)
    rows = [{
        "case": "Original",
        "deleted": "",
        "scores": list(original_scores),
    }]

    for del_i in range(n):
        keep = [j for j in range(n) if j != del_i]
        sub_names = [names[j] for j in keep]
        sub_in = [inputs[j] for j in keep]
        sub_out = [outputs[j] for j in keep]
        try:
            results = Model(
                sub_in, sub_out, dmu_names=sub_names, rts=rts
            ).evaluate_all()
            score_map = {r["dmu"]: r["score"] for r in results}
        except Exception:
            score_map = {}

        scores: List[Optional[float]] = []
        for j, name in enumerate(names):
            if j == del_i:
                scores.append(None)  # N/A — deleted DMU
            else:
                scores.append(score_map.get(name))
        rows.append({
            "case": f"Delete_{names[del_i]}",
            "deleted": names[del_i],
            "scores": scores,
        })
    return rows


def avg_abs_pct_change(
    original: Sequence[Optional[float]],
    current: Sequence[Optional[float]],
) -> Optional[float]:
    """Mean |pct change| vs original over DMUs that are scored in both rows."""
    changes = []
    for o, c in zip(original, current):
        if o is None or c is None:
            continue
        if not (math.isfinite(o) and math.isfinite(c)):
            continue
        if abs(o) < 1e-12:
            continue
        changes.append(abs(c - o) / abs(o) * 100.0)
    if not changes:
        return None
    return sum(changes) / len(changes)


def run_sensitivity_analysis(
    names: Sequence[str],
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    original_by_rts: Dict[str, List[Dict]],
    rts_list: Sequence[str] = RTS_LIST,
    models: Sequence[str] = ("LYHS", "HSLS", "IBP"),
) -> Dict[str, Dict[str, List[Dict]]]:
    """
    Returns sens[rts][model] = list of case rows
      each row: {case, deleted, scores: [.. aligned to names ..]}
    """
    sens: Dict[str, Dict[str, List[Dict]]] = {}
    for rts in rts_list:
        sens[rts] = {}
        orig_rows = original_by_rts[rts]
        for model in models:
            key = f"{model}_score"
            original_scores = [r[key] for r in orig_rows]
            print(f"  Sensitivity [{rts}] {model}: Original + {len(names)} deletions...")
            sens[rts][model] = sensitivity_one_model(
                model, names, inputs, outputs, rts, original_scores
            )
    return sens


def _print_sensitivity_table(
    names: Sequence[str],
    case_rows: List[Dict],
    rts: str,
    model: str,
) -> None:
    # Wide table: Case | DMU scores...
    col_w = 8
    header = f"{'Case':<14}" + "".join(f"{nm:>{col_w}}" for nm in names)
    print("=" * max(96, len(header)))
    print(f"Sensitivity analysis (Table 4 style) - {model} under {rts}")
    print("=" * max(96, len(header)))
    print(header)
    print("-" * max(96, len(header)))
    for row in case_rows:
        cells = "".join(f"{_score_cell(v):>{col_w}}" for v in row["scores"])
        print(f"{row['case']:<14}{cells}")
    print("-" * max(96, len(header)))
    print("N/A = deleted DMU")


def _print_sensitivity_avg_change(
    sens: Dict[str, Dict[str, List[Dict]]],
    rts_list: Sequence[str],
    models: Sequence[str] = ("LYHS", "HSLS", "IBP"),
) -> None:
    """Average |% change| over leave-one-out cases (like Fig. 1 summary)."""
    print("=" * 72)
    print("Sensitivity: average |% change| vs Original (over deletion cases)")
    print("=" * 72)
    print(f"{'RTS':<6} {'LYHS':>12} {'HSLS':>12} {'IBP':>12}")
    print("-" * 72)
    for rts in rts_list:
        avgs = {}
        for model in models:
            _, data = case_avg_pct_by_model(sens, rts, models)
            vals = [v for v in data[model] if math.isfinite(v)]
            avgs[model] = sum(vals) / len(vals) if vals else float("nan")
        print(
            f"{rts:<6} "
            f"{avgs['LYHS']:12.4f} "
            f"{avgs['HSLS']:12.4f} "
            f"{avgs['IBP']:12.4f}"
        )
    print("-" * 72)
    print("Lower average |% change| => more stable / less sensitive")


def case_avg_pct_by_model(
    sens: Dict[str, Dict[str, List[Dict]]],
    rts: str,
    models: Sequence[str] = ("LYHS", "HSLS", "IBP"),
) -> Tuple[List[str], Dict[str, List[float]]]:
    """
    Per deletion case, average |% change| vs Original for each model.
    Returns (case_names, model -> list aligned with deletion cases).
    """
    case_names = [r["case"] for r in sens[rts][models[0]][1:]]
    out: Dict[str, List[float]] = {m: [] for m in models}
    for model in models:
        cases = sens[rts][model]
        original = cases[0]["scores"]
        by_case = {r["case"]: r["scores"] for r in cases[1:]}
        for cname in case_names:
            a = avg_abs_pct_change(original, by_case[cname])
            out[model].append(a if a is not None else float("nan"))
    return case_names, out


def plot_fig1_sensitivity(
    sens: Dict[str, Dict[str, List[Dict]]],
    rts: str,
    out_path: Path,
    models: Sequence[str] = ("LYHS", "HSLS", "IBP"),
) -> Path:
    """
    Fig. 1 style: grouped bars of average |% change| in super-efficiency
    scores for LYHS, HSLS, and IBP across leave-one-out cases.
    """
    import matplotlib.pyplot as plt
    import numpy as np

    case_names, data = case_avg_pct_by_model(sens, rts, models)
    case_labels = [c.replace("Delete_", "") for c in case_names]
    n_cases = len(case_labels)
    x = np.arange(n_cases)
    width = 0.25
    colors = {"LYHS": "#4C78A8", "HSLS": "#F58518", "IBP": "#54A24B"}

    fig, ax = plt.subplots(figsize=(max(10, n_cases * 0.45), 5.5))
    for i, model in enumerate(models):
        ax.bar(
            x + (i - 1) * width,
            data[model],
            width,
            label=model,
            color=colors[model],
            edgecolor="white",
            linewidth=0.4,
        )

    ax.set_xlabel("Sensitivity case (deleted DMU)")
    ax.set_ylabel("Average |percentage change| (%)")
    ax.set_title(
        f"Fig. 1 style: average |% change| in super-efficiency scores ({rts})"
    )
    ax.set_xticks(x)
    ax.set_xticklabels(case_labels, rotation=45, ha="right", fontsize=8)
    ax.legend(frameon=False)
    ax.set_ylim(bottom=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    out_path = Path(out_path)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_path


def plot_fig1_summary(
    sens: Dict[str, Dict[str, List[Dict]]],
    rts_list: Sequence[str],
    out_path: Path,
    models: Sequence[str] = ("LYHS", "HSLS", "IBP"),
) -> Path:
    """
    Summary bar chart: overall mean |% change| across deletion cases,
    one group per RTS (3 model bars each) — compact Fig. 1 summary.
    """
    import matplotlib.pyplot as plt
    import numpy as np

    colors = {"LYHS": "#4C78A8", "HSLS": "#F58518", "IBP": "#54A24B"}
    x = np.arange(len(rts_list))
    width = 0.25

    fig, ax = plt.subplots(figsize=(8, 5))
    for i, model in enumerate(models):
        means = []
        for rts in rts_list:
            _, data = case_avg_pct_by_model(sens, rts, models)
            vals = [v for v in data[model] if math.isfinite(v)]
            means.append(sum(vals) / len(vals) if vals else float("nan"))
        ax.bar(
            x + (i - 1) * width,
            means,
            width,
            label=model,
            color=colors[model],
            edgecolor="white",
            linewidth=0.4,
        )

    ax.set_xlabel("RTS")
    ax.set_ylabel("Average |percentage change| (%)")
    ax.set_title(
        "Fig. 1 style: mean |% change| over deletion cases by RTS"
    )
    ax.set_xticks(x)
    ax.set_xticklabels(list(rts_list))
    ax.legend(frameon=False)
    ax.set_ylim(bottom=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    out_path = Path(out_path)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_path


def plot_all_fig1(
    sens: Dict[str, Dict[str, List[Dict]]],
    out_dir: Path,
    rts_list: Sequence[str] = RTS_LIST,
) -> List[Path]:
    out_dir = Path(out_dir)
    paths = []
    models = ("LYHS", "HSLS", "IBP")

    # Data table behind Fig. 1
    pct_csv = out_dir / "fig1_sensitivity_pct_change.csv"
    with pct_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["RTS", "Case", *models])
        for rts in rts_list:
            case_names, data = case_avg_pct_by_model(sens, rts, models)
            for i, cname in enumerate(case_names):
                writer.writerow([
                    rts,
                    cname,
                    *[
                        f"{data[m][i]:.6f}" if math.isfinite(data[m][i]) else ""
                        for m in models
                    ],
                ])
    print(f"Fig. 1 data CSV written: {pct_csv}")

    for rts in rts_list:
        p = plot_fig1_sensitivity(
            sens, rts, out_dir / f"fig1_sensitivity_pct_change_{rts}.png"
        )
        paths.append(p)
        print(f"Fig. 1 chart written: {p}")
    p_sum = plot_fig1_summary(
        sens, rts_list, out_dir / "fig1_sensitivity_pct_change_summary.png"
    )
    paths.append(p_sum)
    print(f"Fig. 1 summary chart written: {p_sum}")
    return paths


def load_sensitivity_csv(path: Path) -> Tuple[
    List[str], Dict[str, Dict[str, List[Dict]]]
]:
    """Reload sensitivity matrix from CSV into sens[rts][model] structure."""
    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError(f"Empty sensitivity CSV: {path}")
        meta = {"RTS", "Model", "Case", "Deleted_DMU"}
        dmu_cols = [c for c in reader.fieldnames if c not in meta]
        rows = list(reader)

    def parse_cell(s: str) -> Optional[float]:
        if s in ("N/A", "Infeasible", ""):
            return None
        return float(s)

    sens: Dict[str, Dict[str, List[Dict]]] = {}
    for row in rows:
        rts, model = row["RTS"], row["Model"]
        sens.setdefault(rts, {}).setdefault(model, []).append({
            "case": row["Case"],
            "deleted": row["Deleted_DMU"],
            "scores": [parse_cell(row[c]) for c in dmu_cols],
        })
    return dmu_cols, sens


def write_sensitivity_csv(
    path: Path,
    names: Sequence[str],
    sens: Dict[str, Dict[str, List[Dict]]],
    rts_list: Sequence[str],
    models: Sequence[str] = ("LYHS", "HSLS", "IBP"),
) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["RTS", "Model", "Case", "Deleted_DMU", *names])
        for rts in rts_list:
            for model in models:
                for row in sens[rts][model]:
                    writer.writerow([
                        rts,
                        model,
                        row["case"],
                        row["deleted"],
                        *[_score_cell(v) for v in row["scores"]],
                    ])


def compare_models(
    names: Sequence[str],
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
    out_dir: Optional[Path] = None,
    rts_list: Sequence[str] = RTS_LIST,
    run_sensitivity: bool = True,
) -> Dict[str, List[Dict]]:
    all_rows: Dict[str, List[Dict]] = {}
    all_metrics: Dict[str, Dict[str, Dict[str, float]]] = {}
    models = ("LYHS", "HSLS", "IBP")

    print("Scores: LYHS=theta*(Eq.12)  HSLS=ddot_sigma(Eq.12)  IBP=ddot_gamma(Eq.14)")
    print(f"RTS conditions: {', '.join(rts_list)}")
    print()

    for rts in rts_list:
        rows, metrics, _model_results = compare_models_one_rts(
            names, inputs, outputs, rts
        )
        all_rows[rts] = rows
        all_metrics[rts] = metrics
        _print_score_table(rows, rts)
        _print_metrics(metrics, rts)
        print()

    # Summary metrics across RTS
    print("=" * 72)
    print("SDS / DS / Entropy summary across RTS")
    print("=" * 72)
    print(
        f"{'RTS':<6} {'Measure':<10} "
        f"{'LYHS':>12} {'HSLS':>12} {'IBP':>12}"
    )
    print("-" * 72)
    for rts in rts_list:
        for key in ("SDS", "DS", "Entropy"):
            print(
                f"{rts:<6} {key:<10} "
                f"{all_metrics[rts]['LYHS'][key]:12.6f} "
                f"{all_metrics[rts]['HSLS'][key]:12.6f} "
                f"{all_metrics[rts]['IBP'][key]:12.6f}"
            )
        print("-" * 72)
    print("Higher SDS/DS => more discrimination; lower Entropy => more reliable")

    # Fig. D.2 / D.3: IBP-SBM vs BP-SBM (not LYHS/HSLS/IBP-super)
    print()
    airr_by_rts, aoir_by_rts = run_airr_aoir_ibp_bp(
        inputs, outputs, rts_list=rts_list
    )
    _print_airr_aoir_tables(
        airr_by_rts, aoir_by_rts, in_cols, out_cols, rts_list
    )

    if out_dir is not None:
        out_dir = Path(out_dir)
        fig_d2 = plot_fig_d2_airr(
            airr_by_rts, in_cols, rts_list, out_dir / "fig_d2_airr.png"
        )
        fig_d3 = plot_fig_d3_aoir(
            aoir_by_rts, out_cols, rts_list, out_dir / "fig_d3_aoir.png"
        )
        airr_csv = out_dir / "results_compare_lyhs_hsls_ibp_v4_airr_aoir.csv"
        write_airr_aoir_csv(
            airr_csv, airr_by_rts, aoir_by_rts, in_cols, out_cols, rts_list
        )
        print(f"\nFig. D.2 chart written: {fig_d2}")
        print(f"Fig. D.3 chart written: {fig_d3}")
        print(f"AIRR/AOIR CSV written: {airr_csv}")

    sens = None
    if run_sensitivity:
        print()
        print("=" * 72)
        print("Sensitivity analysis (leave-one-out DMU deletion)")
        print("=" * 72)
        sens = run_sensitivity_analysis(
            names, inputs, outputs, all_rows, rts_list=rts_list
        )
        # Print full tables for VRS (like paper Table 4); all RTS go to CSV
        for model in models:
            if "VRS" in sens:
                _print_sensitivity_table(names, sens["VRS"][model], "VRS", model)
                print()
        _print_sensitivity_avg_change(sens, rts_list)
        if out_dir is not None:
            plot_all_fig1(sens, Path(out_dir), rts_list=rts_list)

    if out_dir is not None:
        out_dir = Path(out_dir)
        scores_csv = out_dir / "results_compare_lyhs_hsls_ibp_v4.csv"
        metrics_csv = out_dir / "results_compare_lyhs_hsls_ibp_v4_metrics.csv"

        with scores_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "RTS", "DMU",
                    "LYHS_score", "LYHS_rank",
                    "HSLS_score", "HSLS_rank",
                    "IBP_score", "IBP_rank",
                ],
            )
            writer.writeheader()
            for rts in rts_list:
                for row in all_rows[rts]:
                    writer.writerow({
                        "RTS": rts,
                        "DMU": row["DMU"],
                        "LYHS_score": (
                            f"{row['LYHS_score']:.8f}"
                            if row["LYHS_score"] is not None else "Infeasible"
                        ),
                        "LYHS_rank": row["LYHS_rank"] if row["LYHS_rank"] is not None else "",
                        "HSLS_score": (
                            f"{row['HSLS_score']:.8f}"
                            if row["HSLS_score"] is not None else "Infeasible"
                        ),
                        "HSLS_rank": row["HSLS_rank"] if row["HSLS_rank"] is not None else "",
                        "IBP_score": (
                            f"{row['IBP_score']:.8f}"
                            if row["IBP_score"] is not None else "Infeasible"
                        ),
                        "IBP_rank": row["IBP_rank"] if row["IBP_rank"] is not None else "",
                    })

        with metrics_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["RTS", "Measure", "LYHS", "HSLS", "IBP"])
            for rts in rts_list:
                for key in ("SDS", "DS", "Entropy"):
                    writer.writerow([
                        rts,
                        key,
                        f"{all_metrics[rts]['LYHS'][key]:.8f}",
                        f"{all_metrics[rts]['HSLS'][key]:.8f}",
                        f"{all_metrics[rts]['IBP'][key]:.8f}",
                    ])

        print(f"\nCSV written: {scores_csv}")
        print(f"Metrics CSV written: {metrics_csv}")

        if sens is not None:
            sens_csv = out_dir / "results_compare_lyhs_hsls_ibp_v4_sensitivity.csv"
            write_sensitivity_csv(sens_csv, names, sens, rts_list)
            print(f"Sensitivity CSV written: {sens_csv}")

    return all_rows


def main():
    import sys

    out_dir = Path(__file__).resolve().parent
    # Fast path: regenerate Fig. 1 from existing sensitivity CSV
    #   python 37_compare_lyhs_hsls_ibp_v4.py --plot-only
    if "--plot-only" in sys.argv:
        sens_csv = out_dir / "results_compare_lyhs_hsls_ibp_v4_sensitivity.csv"
        if not sens_csv.exists():
            raise FileNotFoundError(
                f"Missing {sens_csv}; run full comparison first."
            )
        _, sens = load_sensitivity_csv(sens_csv)
        rts_list = [r for r in RTS_LIST if r in sens]
        plot_all_fig1(sens, out_dir, rts_list=rts_list)
        return

    # Prefer data1.csv (Table D.10); fall back to data.csv
    data_path = out_dir / "data1.csv"
    if not data_path.exists():
        data_path = out_dir / "data.csv"
    if not data_path.exists():
        raise FileNotFoundError("Missing data1.csv or data.csv")

    names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
    print(f"Data: {data_path}")
    print(f"DMUs: {len(names)} | inputs: {in_cols} | outputs: {out_cols}")
    print()

    # Fast path: only Fig. D.2 / D.3 (IBP-SBM vs BP-SBM)
    #   python 37_compare_lyhs_hsls_ibp_v4.py --fig-d-only
    if "--fig-d-only" in sys.argv:
        airr_by_rts, aoir_by_rts = run_airr_aoir_ibp_bp(inputs, outputs)
        _print_airr_aoir_tables(
            airr_by_rts, aoir_by_rts, in_cols, out_cols, RTS_LIST
        )
        fig_d2 = plot_fig_d2_airr(
            airr_by_rts, in_cols, RTS_LIST, out_dir / "fig_d2_airr.png"
        )
        fig_d3 = plot_fig_d3_aoir(
            aoir_by_rts, out_cols, RTS_LIST, out_dir / "fig_d3_aoir.png"
        )
        airr_csv = out_dir / "results_compare_lyhs_hsls_ibp_v4_airr_aoir.csv"
        write_airr_aoir_csv(
            airr_csv, airr_by_rts, aoir_by_rts, in_cols, out_cols, RTS_LIST
        )
        print(f"\nFig. D.2 chart written: {fig_d2}")
        print(f"Fig. D.3 chart written: {fig_d3}")
        print(f"AIRR/AOIR CSV written: {airr_csv}")
        return

    # Skip long leave-one-out with --no-sensitivity
    run_sens = "--no-sensitivity" not in sys.argv
    compare_models(
        names,
        inputs,
        outputs,
        in_cols,
        out_cols,
        out_dir=out_dir,
        run_sensitivity=run_sens,
    )


if __name__ == "__main__":
    main()
