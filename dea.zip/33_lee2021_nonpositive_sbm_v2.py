"""
Nonpositive SBM & Super-SBM (Lee, Omega 2021)
Implements models (8), (9), (10) and composite indices (11), (12).
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import pulp


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

def classify_io(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
) -> Dict[str, List[int]]:
    """Classify inputs/outputs into index sets used by Lee (2021)."""
    m = len(inputs[0])
    s = len(outputs[0])
    n = len(inputs)

    I_plus = [i for i in range(m) if all(inputs[j][i] > 0 for j in range(n))]
    I_minus = [i for i in range(m) if all(inputs[j][i] < 0 for j in range(n))]
    R_minus = [r for r in range(s) if all(outputs[j][r] < 0 for j in range(n))]
    R_plus = [r for r in range(s) if all(outputs[j][r] > 0 for j in range(n))]

    I = list(range(m))
    R = list(range(s))
    I_pp = [i for i in I if i not in I_plus]       # I''
    I_p = [i for i in I if i not in I_minus]       # I'
    R_pp = [r for r in R if r not in R_minus]     # R''
    R_p = [r for r in R if r not in R_plus]       # R'

    return {
        "I": I,
        "R": R,
        "I+": I_plus,
        "I-": I_minus,
        "I''": I_pp,
        "I'": I_p,
        "R-": R_minus,
        "R+": R_plus,
        "R''": R_pp,
        "R'": R_p,
    }


def zero_proxy(values: Sequence[float], k: int) -> float:
    """Eq. (7): |value| or nearest nonzero absolute value if zero."""
    if values[k] != 0:
        return abs(values[k])
    nonzero = [abs(v) for v in values if v != 0]
    if not nonzero:
        raise ValueError("All values are zero; cannot form proxy denominator.")
    return min(nonzero)


def proxies_for_dmu(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
) -> Tuple[List[float], List[float]]:
    m = len(inputs[0])
    s = len(outputs[0])
    n = len(inputs)
    x_proxy = [zero_proxy([inputs[j][i] for j in range(n)], k) for i in range(m)]
    y_proxy = [zero_proxy([outputs[j][r] for j in range(n)], k) for r in range(s)]
    return x_proxy, y_proxy


def _super_sbm_score(
    w_plus: Sequence[float],
    w_minus: Sequence[float],
    x_proxy: Sequence[float],
    y_proxy: Sequence[float],
    sets: Dict[str, List[int]],
) -> float:
    """Evaluate Nonpositive Super-SBM objective from slacks (model 9)."""
    n_e = len(sets["I'"]) + len(sets["R'"])
    n_c = len(sets["I-"]) + len(sets["R+"])

    numer = 1.0
    if n_e > 0:
        for i in sets["I'"]:
            numer += w_plus[i] / (n_e * x_proxy[i])
        for r in sets["R'"]:
            numer += w_minus[r] / (n_e * y_proxy[r])

    denom = 1.0
    if n_c > 0:
        for i in sets["I-"]:
            denom -= w_plus[i] / (n_c * x_proxy[i])
        for r in sets["R+"]:
            denom -= w_minus[r] / (n_c * y_proxy[r])

    if denom <= 1e-12:
        raise RuntimeError("Super-SBM denominator is nonpositive.")
    return numer / denom


# ---------------------------------------------------------------------------
# Model (8): Nonpositive SBM
# ---------------------------------------------------------------------------

def solve_nonpositive_sbm(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
    sets: Optional[Dict[str, List[int]]] = None,
    msg: bool = False,
) -> Dict:
    """Solve Nonpositive SBM model (8) for DMU k (0-based)."""
    sets = sets or classify_io(inputs, outputs)
    n = len(inputs)
    m = len(inputs[0])
    s = len(outputs[0])
    x_proxy, y_proxy = proxies_for_dmu(inputs, outputs, k)

    n_c = len(sets["I+"]) + len(sets["R-"])
    n_e = len(sets["I''"]) + len(sets["R''"])

    prob = pulp.LpProblem(f"Nonpositive_SBM_DMU{k}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=0)
    Lam = [pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in range(n)]
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    # Objective: linearized (1 - contraction) / (1 + expansion)
    obj = t
    if n_c > 0:
        for i in sets["I+"]:
            obj -= Sm[i] / (n_c * x_proxy[i])
        for r in sets["R-"]:
            obj -= Sp[r] / (n_c * y_proxy[r])
    prob += obj

    # Normalization: t * (1 + expansion) = 1
    norm = t
    if n_e > 0:
        for i in sets["I''"]:
            norm += Sm[i] / (n_e * x_proxy[i])
        for r in sets["R''"]:
            norm += Sp[r] / (n_e * y_proxy[r])
    prob += norm == 1, "normalization"

    for i in range(m):
        prob += (
            t * inputs[k][i] - Sm[i]
            == pulp.lpSum(Lam[j] * inputs[j][i] for j in range(n)),
            f"input_{i}",
        )
    for r in range(s):
        prob += (
            t * outputs[k][r] + Sp[r]
            == pulp.lpSum(Lam[j] * outputs[j][r] for j in range(n)),
            f"output_{r}",
        )
    prob += pulp.lpSum(Lam) == t, "vrs"

    status = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(f"Nonpositive SBM infeasible/nonoptimal for DMU {k}: {pulp.LpStatus[status]}")

    t_star = pulp.value(t)
    if t_star is None or t_star <= 1e-12:
        raise RuntimeError(f"Invalid t* for Nonpositive SBM DMU {k}")

    s_minus = [pulp.value(Sm[i]) / t_star for i in range(m)]
    s_plus = [pulp.value(Sp[r]) / t_star for r in range(s)]
    lam = [pulp.value(Lam[j]) / t_star for j in range(n)]
    rho = pulp.value(prob.objective)

    proj_x = [inputs[k][i] - s_minus[i] for i in range(m)]
    proj_y = [outputs[k][r] + s_plus[r] for r in range(s)]

    return {
        "rho": rho,
        "s_minus": s_minus,
        "s_plus": s_plus,
        "lambda": lam,
        "projection_x": proj_x,
        "projection_y": proj_y,
        "t": t_star,
    }


# ---------------------------------------------------------------------------
# Model (9): Nonpositive Super-SBM
# ---------------------------------------------------------------------------

def solve_nonpositive_super_sbm(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
    sets: Optional[Dict[str, List[int]]] = None,
    msg: bool = False,
) -> Dict:
    """Solve Nonpositive Super-SBM model (9) for DMU k (0-based)."""
    sets = sets or classify_io(inputs, outputs)
    n = len(inputs)
    m = len(inputs[0])
    s = len(outputs[0])
    x_proxy, y_proxy = proxies_for_dmu(inputs, outputs, k)

    n_e = len(sets["I'"]) + len(sets["R'"])   # numerator (expansion-type)
    n_c = len(sets["I-"]) + len(sets["R+"])   # denominator (contraction-type)

    others = [j for j in range(n) if j != k]

    prob = pulp.LpProblem(f"Nonpositive_SuperSBM_DMU{k}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=0)
    Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
    Wp = [pulp.LpVariable(f"Wp_{i}", lowBound=0) for i in range(m)]
    Wm = [pulp.LpVariable(f"Wm_{r}", lowBound=0) for r in range(s)]

    obj = t
    if n_e > 0:
        for i in sets["I'"]:
            obj += Wp[i] / (n_e * x_proxy[i])
        for r in sets["R'"]:
            obj += Wm[r] / (n_e * y_proxy[r])
    prob += obj

    # t * (1 - contraction) = 1
    norm = t
    if n_c > 0:
        for i in sets["I-"]:
            norm -= Wp[i] / (n_c * x_proxy[i])
        for r in sets["R+"]:
            norm -= Wm[r] / (n_c * y_proxy[r])
    prob += norm == 1, "normalization"

    for i in range(m):
        prob += (
            t * inputs[k][i]
            >= pulp.lpSum(Lam[j] * inputs[j][i] for j in others) - Wp[i],
            f"input_{i}",
        )
    for r in range(s):
        prob += (
            t * outputs[k][r]
            <= pulp.lpSum(Lam[j] * outputs[j][r] for j in others) + Wm[r],
            f"output_{r}",
        )
    prob += pulp.lpSum(Lam[j] for j in others) == t, "vrs"

    # Keep contraction ratios < 1
    for r in sets["R+"]:
        prob += t * y_proxy[r] >= Wm[r], f"bound_y_{r}"
    for i in sets["I-"]:
        prob += t * x_proxy[i] >= Wp[i], f"bound_x_{i}"

    status = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(
            f"Nonpositive Super-SBM infeasible/nonoptimal for DMU {k}: {pulp.LpStatus[status]}"
        )

    t_star = pulp.value(t)
    if t_star is None or t_star <= 1e-12:
        raise RuntimeError(f"Invalid t* for Nonpositive Super-SBM DMU {k}")

    lam = [0.0] * n
    for j in others:
        lam[j] = pulp.value(Lam[j]) / t_star

    # Recompute slacks from lambda so stage-2 equalities stay feasible
    # under floating-point / CBC tolerance noise.
    w_plus = []
    for i in range(m):
        ref = sum(lam[j] * inputs[j][i] for j in range(n))
        w_plus.append(max(0.0, ref - inputs[k][i]))
    w_minus = []
    for r in range(s):
        ref = sum(lam[j] * outputs[j][r] for j in range(n))
        w_minus.append(max(0.0, outputs[k][r] - ref))

    sigma = _super_sbm_score(w_plus, w_minus, x_proxy, y_proxy, sets)

    # Projection of (9): (x + w+, y - w-)
    proj_x = [inputs[k][i] + w_plus[i] for i in range(m)]
    proj_y = [outputs[k][r] - w_minus[r] for r in range(s)]

    return {
        "sigma": sigma,
        "w_plus": w_plus,
        "w_minus": w_minus,
        "lambda": lam,
        "projection_x": proj_x,
        "projection_y": proj_y,
        "t": t_star,
    }


# ---------------------------------------------------------------------------
# Model (10): Modified Nonpositive SBM
# ---------------------------------------------------------------------------

def solve_modified_nonpositive_sbm(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
    w_plus: Sequence[float],
    w_minus: Sequence[float],
    sets: Optional[Dict[str, List[int]]] = None,
    msg: bool = False,
) -> Dict:
    """Solve Modified Nonpositive SBM model (10) for DMU k (0-based)."""
    sets = sets or classify_io(inputs, outputs)
    n = len(inputs)
    m = len(inputs[0])
    s = len(outputs[0])
    x_proxy, y_proxy = proxies_for_dmu(inputs, outputs, k)

    n_c = len(sets["I+"]) + len(sets["R-"])
    n_e = len(sets["I''"]) + len(sets["R''"])
    others = [j for j in range(n) if j != k]

    prob = pulp.LpProblem(f"Modified_Nonpositive_SBM_DMU{k}", pulp.LpMinimize)
    t = pulp.LpVariable("t", lowBound=0)
    Lam = {j: pulp.LpVariable(f"Lam_{j}", lowBound=0) for j in others}
    Sm = [pulp.LpVariable(f"Sm_{i}", lowBound=0) for i in range(m)]
    Sp = [pulp.LpVariable(f"Sp_{r}", lowBound=0) for r in range(s)]

    obj = t
    if n_c > 0:
        for i in sets["I+"]:
            obj -= Sm[i] / (n_c * x_proxy[i])
        for r in sets["R-"]:
            obj -= Sp[r] / (n_c * y_proxy[r])
    prob += obj

    norm = t
    if n_e > 0:
        for i in sets["I''"]:
            norm += Sm[i] / (n_e * x_proxy[i])
        for r in sets["R''"]:
            norm += Sp[r] / (n_e * y_proxy[r])
    prob += norm == 1, "normalization"

    for i in range(m):
        prob += (
            t * inputs[k][i] - Sm[i] + t * w_plus[i]
            == pulp.lpSum(Lam[j] * inputs[j][i] for j in others),
            f"input_{i}",
        )
    for r in range(s):
        prob += (
            t * outputs[k][r] + Sp[r] - t * w_minus[r]
            == pulp.lpSum(Lam[j] * outputs[j][r] for j in others),
            f"output_{r}",
        )
    prob += pulp.lpSum(Lam[j] for j in others) == t, "vrs"

    status = prob.solve(pulp.PULP_CBC_CMD(msg=msg))
    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(
            f"Modified Nonpositive SBM infeasible/nonoptimal for DMU {k}: {pulp.LpStatus[status]}"
        )

    t_star = pulp.value(t)
    if t_star is None or t_star <= 1e-12:
        raise RuntimeError(f"Invalid t* for Modified Nonpositive SBM DMU {k}")

    s_minus = [pulp.value(Sm[i]) / t_star for i in range(m)]
    s_plus = [pulp.value(Sp[r]) / t_star for r in range(s)]
    lam = [0.0] * n
    for j in others:
        lam[j] = pulp.value(Lam[j]) / t_star
    gamma = pulp.value(prob.objective)

    # Pareto-efficient projection: (x - s- + w+, y + s+ - w-)
    proj_x = [inputs[k][i] - s_minus[i] + w_plus[i] for i in range(m)]
    proj_y = [outputs[k][r] + s_plus[r] - w_minus[r] for r in range(s)]

    return {
        "gamma": gamma,
        "s_minus": s_minus,
        "s_plus": s_plus,
        "lambda": lam,
        "projection_x": proj_x,
        "projection_y": proj_y,
        "t": t_star,
    }


# ---------------------------------------------------------------------------
# Two-stage evaluation + indices (11), (12)
# ---------------------------------------------------------------------------

def evaluate_dmu(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    k: int,
    sets: Optional[Dict[str, List[int]]] = None,
    tol: float = 1e-8,
    msg: bool = False,
) -> Dict:
    """
    Two-stage procedure:
      Stage 1: Nonpositive Super-SBM (9) -> sigma*
      Stage 2: Modified Nonpositive SBM (10) -> gamma*
      Eq. (11): hat_sigma
      Eq. (12): ddot_sigma (composite)
    """
    sets = sets or classify_io(inputs, outputs)
    stage1 = solve_nonpositive_super_sbm(inputs, outputs, k, sets=sets, msg=msg)
    stage2 = solve_modified_nonpositive_sbm(
        inputs,
        outputs,
        k,
        w_plus=stage1["w_plus"],
        w_minus=stage1["w_minus"],
        sets=sets,
        msg=msg,
    )

    sigma = stage1["sigma"]
    gamma = stage2["gamma"]

    # Eq. (11)
    if sigma > 1 + tol:
        hat_sigma = sigma
    else:
        hat_sigma = gamma

    # Eq. (12)
    if sigma > 1 + tol:
        ddot_sigma = (sigma - 1.0) * gamma + 1.0
    else:
        ddot_sigma = gamma

    return {
        "sigma": sigma,
        "gamma": gamma,
        "hat_sigma": hat_sigma,      # Eq. (11)
        "ddot_sigma": ddot_sigma,    # Eq. (12)
        "w_plus": stage1["w_plus"],
        "w_minus": stage1["w_minus"],
        "s_minus": stage2["s_minus"],
        "s_plus": stage2["s_plus"],
        "projection_x": stage2["projection_x"],
        "projection_y": stage2["projection_y"],
        "stage1_projection_x": stage1["projection_x"],
        "stage1_projection_y": stage1["projection_y"],
    }


def evaluate_all(
    inputs: Sequence[Sequence[float]],
    outputs: Sequence[Sequence[float]],
    dmu_names: Optional[Sequence[str]] = None,
    msg: bool = False,
) -> List[Dict]:
    sets = classify_io(inputs, outputs)
    n = len(inputs)
    names = list(dmu_names) if dmu_names is not None else [str(i + 1) for i in range(n)]
    results = []
    for k in range(n):
        res = evaluate_dmu(inputs, outputs, k, sets=sets, msg=msg)
        res["dmu"] = names[k]
        res["index"] = k
        results.append(res)
    return results


# ---------------------------------------------------------------------------
# Table 3 data & Table 4 comparison
# ---------------------------------------------------------------------------

TABLE3_DATA = [
    # DMU, X1, X2, Y1, Y2, Y3
    (1, 1.03, -0.05, 0.56, -0.09, -0.44),
    (2, 1.75, -0.17, 0.74, -0.24, -0.31),
    (3, 1.44, -0.56, 1.37, -0.35, -0.21),
    (4, 10.8, -0.22, 5.61, -0.98, -3.79),
    (5, 1.3, -0.07, 0.49, -1.08, -0.34),
    (6, 1.98, -0.1, 1.61, -0.44, -0.34),
    (7, 0.97, -0.17, 0.82, -0.08, -0.43),
    (8, 9.82, -2.32, 5.61, -1.42, -1.94),
    (9, 1.59, 0.0, 0.52, 0.0, -0.37),
    (10, 5.96, -0.15, 2.14, -0.52, -0.18),
    (11, 1.29, -0.11, 0.57, 0.0, -0.24),
    (12, 2.38, -0.25, 0.57, -0.67, -0.43),
    (13, 10.3, -0.16, 9.56, -0.58, 0.0),
]

# Table 4 reference values
TABLE4_REF = {
    1: {"eq11": 0.530314, "eq12": 0.530314},
    2: {"eq11": 0.480311, "eq12": 0.480311},
    3: {"eq11": 1.322352, "eq12": 1.265718},
    4: {"eq11": 0.295132, "eq12": 0.295132},
    5: {"eq11": 0.340657, "eq12": 0.340657},
    6: {"eq11": 0.378464, "eq12": 0.378464},
    7: {"eq11": 1.108571, "eq12": 1.099308},
    8: {"eq11": 1.211970, "eq12": 1.092635},
    9: {"eq11": 0.488196, "eq12": 0.488196},
    10: {"eq11": 0.266927, "eq12": 0.266927},
    11: {"eq11": 1.332151, "eq12": 1.31336},
    12: {"eq11": 0.317077, "eq12": 0.317077},
    13: {"eq11": 5.592645, "eq12": 3.602763},
}


def load_table3():
    names = [str(row[0]) for row in TABLE3_DATA]
    inputs = [[row[1], row[2]] for row in TABLE3_DATA]
    outputs = [[row[3], row[4], row[5]] for row in TABLE3_DATA]
    return names, inputs, outputs


def load_csv(
    path: str,
    input_cols: Optional[Sequence[str]] = None,
    output_cols: Optional[Sequence[str]] = None,
    dmu_col: str = "DMU",
):
    """
    Load DEA data from CSV.
    Default: columns starting with 'x'/'X' are inputs, 'y'/'Y' are outputs.
    """
    import csv
    from pathlib import Path

    path = Path(path)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"No header found in {path}")
        fields = list(reader.fieldnames)
        rows = list(reader)

    if input_cols is None:
        input_cols = [c for c in fields if c.lower().startswith("x")]
    if output_cols is None:
        output_cols = [c for c in fields if c.lower().startswith("y")]
    if not input_cols or not output_cols:
        raise ValueError("Could not detect input/output columns.")

    names = [row[dmu_col] for row in rows]
    inputs = [[float(row[c]) for c in input_cols] for row in rows]
    outputs = [[float(row[c]) for c in output_cols] for row in rows]
    return names, inputs, outputs, list(input_cols), list(output_cols)


def write_results_csv(
    path: str,
    results: Sequence[Dict],
    ranks11,
    ranks12,
    in_cols: Sequence[str],
    out_cols: Sequence[str],
) -> None:
    import csv
    from pathlib import Path

    path = Path(path)
    header = [
        "DMU",
        "sigma_star",
        "gamma_star",
        "eq11_hat_sigma",
        "eq12_ddot_sigma",
        "rank_eq11",
        "rank_eq12",
    ]
    for c in in_cols:
        header += [f"w_plus_{c}", f"s_minus_{c}", f"proj1_{c}", f"proj_{c}"]
    for c in out_cols:
        header += [f"w_minus_{c}", f"s_plus_{c}", f"proj1_{c}", f"proj_{c}"]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for res, r11, r12 in zip(results, ranks11, ranks12):
            row = [
                res["dmu"],
                f"{res['sigma']:.8f}",
                f"{res['gamma']:.8f}",
                f"{res['hat_sigma']:.8f}",
                f"{res['ddot_sigma']:.8f}",
                r11,
                r12,
            ]
            m = len(in_cols)
            s = len(out_cols)
            for i in range(m):
                row += [
                    f"{_clean_slack(res['w_plus'][i]):.8f}",
                    f"{_clean_slack(res['s_minus'][i]):.8f}",
                    f"{res['stage1_projection_x'][i]:.8f}",
                    f"{res['projection_x'][i]:.8f}",
                ]
            for r in range(s):
                row += [
                    f"{_clean_slack(res['w_minus'][r]):.8f}",
                    f"{_clean_slack(res['s_plus'][r]):.8f}",
                    f"{res['stage1_projection_y'][r]:.8f}",
                    f"{res['projection_y'][r]:.8f}",
                ]
            writer.writerow(row)


def _fmt_vec(vals: Sequence[float], nd: int = 4) -> str:
    cleaned = [0.0 if abs(v) < 1e-8 else v for v in vals]
    return "[" + ", ".join(f"{v:.{nd}f}" for v in cleaned) + "]"


def _clean_slack(v: float, tol: float = 1e-8) -> float:
    return 0.0 if abs(v) < tol else v


def print_slacks_and_projections(
    results: Sequence[Dict],
    in_cols: Sequence[str],
    out_cols: Sequence[str],
) -> None:
    print("\nSlacks and projections")
    print(
        "  w+ / w- : Super-SBM (9) input savings / output surpluses\n"
        "  s- / s+ : Modified SBM (10) input / output slacks\n"
        "  proj1   : stage-1 projection (x+w+, y-w-)\n"
        "  proj    : Pareto-efficient projection (x-s-+w+, y+s+-w-)"
    )
    print("=" * 100)
    for res in results:
        w_plus = [_clean_slack(v) for v in res["w_plus"]]
        w_minus = [_clean_slack(v) for v in res["w_minus"]]
        s_minus = [_clean_slack(v) for v in res["s_minus"]]
        s_plus = [_clean_slack(v) for v in res["s_plus"]]
        print(f"\nDMU {res['dmu']}  |  sigma*={res['sigma']:.6f}  gamma*={res['gamma']:.6f}")
        print(f"  inputs  {list(in_cols)}")
        print(f"    w+     {_fmt_vec(w_plus)}")
        print(f"    s-     {_fmt_vec(s_minus)}")
        print(f"    proj1  {_fmt_vec(res['stage1_projection_x'])}")
        print(f"    proj   {_fmt_vec(res['projection_x'])}")
        print(f"  outputs {list(out_cols)}")
        print(f"    w-     {_fmt_vec(w_minus)}")
        print(f"    s+     {_fmt_vec(s_plus)}")
        print(f"    proj1  {_fmt_vec(res['stage1_projection_y'])}")
        print(f"    proj   {_fmt_vec(res['projection_y'])}")
    print("=" * 100)


def main():
    from pathlib import Path

    data_path = Path(__file__).resolve().parent / "data.csv"
    out_path = Path(__file__).resolve().parent / "results_data.csv"

    names, inputs, outputs, in_cols, out_cols = load_csv(str(data_path))
    sets = classify_io(inputs, outputs)

    print(f"Data: {data_path}")
    print(f"DMUs: {len(names)}")
    print(f"Inputs ({len(in_cols)}): {in_cols}")
    print(f"Outputs ({len(out_cols)}): {out_cols}")
    print("Index sets (Lee 2021 notation):")
    for key in ["I+", "I-", "I''", "I'", "R+", "R-", "R''", "R'"]:
        labels = in_cols if key.startswith("I") else out_cols
        print(f"  {key}: {[labels[i] for i in sets[key]]}")
    print()

    results = evaluate_all(inputs, outputs, dmu_names=names)

    order11 = sorted(range(len(results)), key=lambda i: -results[i]["hat_sigma"])
    order12 = sorted(range(len(results)), key=lambda i: -results[i]["ddot_sigma"])
    ranks11 = [0] * len(results)
    ranks12 = [0] * len(results)
    for rank, i in enumerate(order11, start=1):
        ranks11[i] = rank
    for rank, i in enumerate(order12, start=1):
        ranks12[i] = rank

    print(
        f"{'DMU':>5} {'sigma*':>12} {'gamma*':>12} "
        f"{'Eq(11)':>12} {'Eq(12)':>12} {'Rk11':>5} {'Rk12':>5}"
    )
    print("-" * 72)
    for res, r11, r12 in zip(results, ranks11, ranks12):
        print(
            f"{res['dmu']:>5} {res['sigma']:12.6f} {res['gamma']:12.6f} "
            f"{res['hat_sigma']:12.6f} {res['ddot_sigma']:12.6f} "
            f"{r11:5d} {r12:5d}"
        )
    print("-" * 72)

    print_slacks_and_projections(results, in_cols, out_cols)

    write_results_csv(str(out_path), results, ranks11, ranks12, in_cols, out_cols)
    print(f"Results written to: {out_path}")


if __name__ == "__main__":
    main()
